# Numerical and measurement contract

E013 addition: the explicitly requested tile comparison preserves every numerical rule below. Only the selected existing M128 K/N tile and associated thread count differ. Both choices share one freshly compiled library with unchanged corrected E006 device source/SASS. Use fresh matched controls, four-matrix complete cycles, seeds 3–6, capacity128, live W_hat buffers, no artificial flush, ten warmups/100 samples and two reversed series. Actual launch tracing and fresh numerical/memcheck/synccheck plus representative racecheck gate timing. Conditional held-out confirmation uses seeds 7–10 with the same method. Cross-tile output bits may differ through reduction order, but every output must pass the unchanged FP64 elementwise threshold. A 5% lower-latency gate is evaluated per shape in both primary and held-out series. No automatic dispatch, cuBLAS performance comparison or inference claim is added. Historical contracts remain intact.

## 1. Operation, layout, and quantization

Compute row-major `C[M,N] = A[M,K] * B[K,N]`. A and C use FP16 storage. Original W is FP16. Fused kernels accumulate with FP32 FMA and round the final result to FP16. The CPU reference accumulates in FP64. The study measures controlled kernels and baselines for LLM-like GEMM shapes, not end-to-end model inference.

For each column n and K-group g, quantize with the stored FP16 scale:

```text
s[g,n] = FP16(max(abs(W[k,n])) / 7), over valid k in group g
z[k,n] = clamp(nearbyint(FP32(W[k,n]) / FP32(s[g,n])), -7, 7)
          or 0 when the stored scale is zero
q[k,n] = z[k,n] + 8
W_hat[k,n] = FP16(FP32(q[k,n] - 8) * FP32(s[g,n]))
```

FP16 conversion uses round-to-nearest-even. `nearbyint` follows the host floating-point rounding mode, normally nearest-even. Do not change that environment silently. Valid weights have codes 1 through 15. Code 8 represents zero. Code 0 is unused for valid weights.

**FP16 reconstruction is required.** Round the FP32 product `(q-8)*s` to FP16 before promotion to FP32 for the fused multiply-add. Keeping the product in FP32 computes a different operation from the CPU reference, GPU dequantization, and pre-dequantized cuBLAS path. See H001 in [EXPERIMENTS.md](EXPERIMENTS.md).

Packed storage is `qweight[k8*N+n]`, a uint32 word containing eight consecutive K codes in nibble positions `4*j`, increasing with K. Adjacent columns occupy adjacent words. Allocate `ceil(K/8)*N` words. Scales use `scales[g*N+n]`, with `ceil(K/group)*N` FP16 elements. Words never cross group boundaries because group size is a multiple of eight.

Supported logical shapes have positive M, N, K and group, group divisible by eight, subject to available memory and index/launch limits. K may be below eight. Final words/groups may be partial and N may be odd. Unused tail nibbles are zero and must never be consumed. E001–E003 preserve the same packed layout and quantization group rules. Synthetic inputs are finite FP16 values. NaN/Inf quantization is not a specified interface.

### Launch mapping and row tiles

The selectors retain fixed mappings. Static shared bytes below are source-declared partial arrays, excluding any driver-reserved storage. Record actual compiled resources separately.

| Selector | Rows per block tile | Block | Grid | Static partial bytes/block |
|---|---:|---|---|---:|
| naive | 1 | 256 threads | `(ceil(N/256), M)` | 0 |
| inblock / inblock_specialized | 1 | `(32,8)` | `(ceil(N/32), M)` | 1024 |
| inblock_m2 | 2 | `(32,8)` | `(ceil(N/32), ceil(M/2))` | 2048 |
| inblock_m4 | 4 | `(32,8)` | `(ceil(N/32), ceil(M/4))` | 4096 |

E003's `inblock_m2` and `inblock_m4` reuse each loaded packed word, scale, and FP16-reconstructed weight across two or four independent row accumulators. Column lanes remain contiguous. Each of eight K slices visits packed words `[floor(W*y/8), floor(W*(y+1)/8))`, where `W=ceil(K/8)` and y is threadIdx.y. Per-row K traversal, FP32 FMA order, eight-partial summation order, and FP16 output conversion remain those of E002. Shared partials are `float partial[Rows][8][32]`. Rows never reduce into each other.

The row tile begins at `m=blockIdx.y*Rows`. Compile-time K-tail and M-tail variants are selected by `K%8` and `M%Rows`. When the final row tile is incomplete, invalid rows keep zero accumulators, skip activation reads, and skip output writes. Invalid N lanes and empty K slices also publish zero partials. Every thread reaches the block barrier. Valid rows retain their ordinary arithmetic order. M need not be divisible by two or four, and K may end in a partial word or group. K=136 with group=128 uses an aligned packed-word path despite its partial final group. These bounds specializations do not select between the two-row and four-row kernels automatically.

## 2. Reference and correctness

| Kernel | Operation and reference |
|---|---|
| naive/inblock/inblock_specialized/inblock_m2/inblock_m4 | Fused GEMM on W_hat, reconstructed-weight FP64 CPU GEMM reference |
| cublas | Original FP16 W, `CUBLAS_COMPUTE_32F`, original-weight FP64 reference |
| cublas_dq | Pre-dequantized W_hat already on device, same cuBLAS call, reconstructed-weight FP64 reference |
| dequant | Materialize FP16 W_hat, bitwise agreement with every CPU-reconstructed weight |
| unfused | GPU dequantization then cuBLAS, reconstructed-weight FP64 reference |

For every checked output require `abs(got-ref) <= 1e-3*abs(ref) + 1e-3*rms(ref)`. Got is FP16 output promoted to FP32. Ref is FP64, with RMS over checked reference elements. `rel_l2_err = norm(got-ref)/norm(ref)`. `rel_l2_vs_fp16` compares with the original-weight reference and includes quantization error for W_hat kernels. It is not the pass criterion. Never relax tolerance to accept changed reduction order.

Small cases check every row. Main sweeps use up to 64 deterministically sampled rows, with exact indices printed in the log, and every column of those rows. M=128 main FP64 comparisons therefore do not check every output row. Every W_hat element is checked bitwise when GPU dequantization runs. Do not use `--nocheck` for acceptance measurements. Stop on correctness/launcher errors and preserve diagnostics.

In addition to FP64 validation, `inblock_specialized` is compared bitwise against E001 `inblock`, and E003 `inblock_m2`/`inblock_m4` are each compared bitwise against E002 `inblock_specialized`. These untimed checks cover every M*N FP16 output, even when the FP64 reference samples rows. They run when the candidate is checked, without requiring its comparison selector in the timed list. Any mismatch stops the run before candidate timing. Full-output agreement with a retained kernel does not expand the sampled FP64 check to all rows.

## 3. Timing and comparisons

Use M={1,8,32,128}, K=N=4096, group=128, seed=1, 10 warmups, and at least 100 timed iterations. Compare naive/inblock/inblock_specialized/inblock_m2/inblock_m4 in the same executable, build, seed, node, and cache policy. Retain and record each kernel's defined launch mapping. Changing executable, flags, kernel, rank/thread count, placement, or topology requires rerunning every M point in the series.

E003 adds a separately identified supplemental M=5 point with the same K=N=4096, group=128, seed=1, 10 warmups, at least 100 timed iterations, and both cache policies. It tests incomplete two-row and four-row tiles at the main matrix dimensions. It does not replace or redefine the standard M={1,8,32,128} series. The current event-timing script runs all nine selectors at those four standard points and the supplemental point.

CUDA events surround one launch or the complete unfused pair. Allocations, host quantization, H2D copies, and flushing are outside the interval. Report median, min, max, and p90 in microseconds. Even-count median averages the middle pair. p90 uses sorted index `floor(0.9*(iters-1))`. E001 speedup is `naive median_us / inblock median_us`. E002 speedup is `inblock median_us / inblock_specialized median_us`. E003 evaluates each selector separately with `inblock_specialized median_us / inblock_m2 median_us` or `inblock_specialized median_us / inblock_m4 median_us`. Compare the same M and policy. E002 retains the E001 mapping and arithmetic order. E003 changes rows per tile while retaining each row's arithmetic order. Both experiments require full-output bitwise agreement with their retained comparison, checked outside timing in addition to the unchanged FP64 threshold. Within-run ranges do not establish between-run variability.

Record both application policies:

- Intended cold: a store kernel writes `2*L2` bytes on the same stream immediately before each start event. Historical L2=32 MiB gives a 64 MiB buffer. This does not demonstrate eviction of each input line and may affect later DRAM activity.
- Reused inputs: `--no-flush-l2`, repeated launches without application flushing. This does not guarantee permanent cache residency.

There is no flush between dequantization and GEMM in `unfused`, so W_hat may remain cached. Nsight `--cache-control all` flushes caches between replay passes and is a separate method. Profile separately from latency runs and query metrics on the target GPU. Profiler-replayed and event timings are not directly interchangeable.

## 4. Operation and byte models

GEMM-like TFLOP/s is `2*M*N*K / median_seconds / 1e12`, counting multiply and add separately. Dequant reports zero TFLOP/s. Define buffer sizes in bytes:

```text
|A| = 2*M*K                   |C| = 2*M*N
|Q| = 4*ceil(K/8)*N            |S| = 2*ceil(K/group)*N
|W| = |W_hat| = 2*K*N
```

`eff_gbps = logical_bytes / median_seconds / 1e9` uses the existing model below. It is not measured DRAM bandwidth and omits repeated cache accesses across output rows.

| Path | Existing logical_bytes model |
|---|---|
| naive/inblock/inblock_specialized/inblock_m2/inblock_m4 | `|A|+|C|+|Q|+|S|` |
| cublas/cublas_dq | `|A|+|C|+|W|` |
| dequant | `|Q|+|S|+|W_hat|` |
| unfused | `|A|+|C|+|Q|+|S|+|W_hat|` |

The unfused model counts W_hat once although it is written and then read. Preserve this historical CSV convention and identify it when interpreting `eff_gbps`. A model counting both logical transfers adds another `|W_hat|`, but neither model is measured DRAM traffic. A changed model must be separately labeled.

For K=N=4096 and group=128, Q=8 MiB, S=0.25 MiB, W_hat=32 MiB. The 8.25 MiB packed weight/scale set fits the observed 32 MiB L2. Use finite ceiling counts for tail shapes. If adding rooflines, recompute every coordinate/ceiling, distinguish primary full-machine from auxiliary roofs, and keep operation/ISA/clock/bandwidth assumptions consistent.

## 5. E004 external comparator and verified timing method

E004 selects released vLLM v0.33.0, exact source `4ba787ec9959e566d3b587a796dff07673324da5`, rather than the inspected moving main commit. The wheel's generated version file reports `g4ba787ec9`. Use dense `torch.ops._C.marlin_gemm`, FP16 A/C/scales and `uint4b8`, group=128, no bias/activation scale/global scale/zero-point tensor, `use_atomic_add=False`, `use_fp32_reduce=True`, `is_zp_float=False`. This is INT4 W4A16, not NVFP4, MXFP4, W4A4, W4A8 or MoE. Import only the released operator library and inspected pure source helpers, without importing a serving engine.

Existing packed `[K/8,N]` words are reinterpreted as int32 bits and passed to upstream `gptq_marlin_repack(...,num_bits=4,is_a_8bit=False)`. Offset codes are unchanged. The upstream helper reshapes logical weights into 16x16 tiles and permutes 1024-code chunks for Tensor Core fragments, then packs eight permuted codes per word. Output storage is `[K/16,2*N]` int32. Grouped scales retain all FP16 bits while each 64-element chunk is permuted by `[i+8*j for i in range(8) for j in range(8)]`. No logical matrix transpose or independent requantization is performed. CPU inversion must recover every code and scale bit, then reconstruct every original W_hat FP16 element. GPU dequantization of the project's original packed layout is independently bit-checked.

Source inspection finds exact FP16 integers q-8 followed by `__hmul2` of group scales before MMA. On sm_120 the grouped FP16 path uses FP32 MMA accumulation. `use_fp32_reduce=True` also preserves FP32 global partials, whereas false permits FP16 intermediate storage. Arithmetic order differs from retained scalar kernels, so compare Marlin to the reconstructed-weight FP64 reference at the unchanged threshold, not bitwise C agreement. Original-weight cuBLAS has its separate original-weight reference. E004's adapter checks all rows up to M=128, independently expanding verification for this experiment without changing old sampled claims.

Repack requires K%16=0 and N%64=0. Execution additionally requires valid configured K/N tiles and group divisibility. All requested 4096/11008 shapes satisfy the inspected source conditions and passed actual execution without padding. Avoid K=128 in grouped smoke tests: one scale row is interpreted as per-column quantization and scales after reduction. Use K=256 or larger. E004 does not extend Marlin with padding. Locks use 4*SMs zero-initialized int32 elements, reusable on ordered calls. Preallocate output. The operator still allocates FP32 C_tmp internally: `4*SMs*min(ceil(M/16)*16,64)*256` bytes, plus empty optional tensor wrappers. Record these allocations outside device timing and diagnose host dispatch gaps.

E004 adds a separately labeled common `graph_events` timing method for every selector. Capture store flush (when enabled), external CUDA start event, GEMM operation(s), and external stop event for each sample in a CUDA graph, then replay. Per-sample CUDA event intervals exclude store flushing, host dispatch, allocation, repacking and capture. The no-flush policy still omits application flushing and the store policy still writes exactly 2*runtime L2 bytes with the retained kernel. Event-node overhead and graph scheduling differ from historical E001–E003 application timings, so rerun every E004 comparator/shape and never combine old medians as denominators. A separately labeled eager-event diagnostic tests host-gap sensitivity. Graph replay timings remain distinct from cache-invalidated profiler replay. Record capture/setup costs separately. No tuning or external kernel modification is included.

E004's all-row screen exposed two original-weight cuBLAS errors under the legacy default handle math mode at M=128, K=N=4096. A bounded mode 0/16 ablation reproduced those errors and passed with `CUBLAS_MATH_DISALLOW_REDUCED_PRECISION_REDUCTION` (value 16), while retaining `CUBLAS_COMPUTE_32F`. The complete E004 comparison sets mode 16 explicitly for original/reconstructed/unfused cuBLAS and labels it in every result. This forces intermediate reductions to compute precision. The retained source and E001–E003 behavior remain unchanged. Do not splice the partial default-mode screen into the complete rerun or attribute all differences solely to precision rather than algorithm selection.


E004 validation is complete on c58 sm_120: all 384 screening rows, both 64-row repeats and both 12-row timing-method diagnostics pass at the unchanged threshold. Code and scale inversion recover every bit and source grouped reconstruction matches the FP16 contract. Traces/profiles establish actual Marlin selection. The all-row reference checks are specific to this new adapter and do not expand historical sampled checks. Repack first-use wall/event costs and capture/first-validation-call costs are saved separately. Setup event intervals can contain lazy initialization and host gaps and are not isolated repack-kernel throughput.

E004's three Nsight reports use cache-control none after 10 direct warmups and kernel replay, no application flushing and unlocked clocks. They are not the application graph-event sample series. Counters retain 2.4–2.5 MB DRAM reads, so neither complete residency nor a unique cold/warm classification is established. `profile_summary.csv` normalizes Kbyte/Mbyte to decimal bytes, retaining exact metric names. Tensor-pipe activity is not FLOP utilization. No roofline ceiling or classification was constructed.


## 6. E005 experimental launch policy and stopped gate

E005 uses the unchanged E004 FP16 reconstruction, dense uint4b8/G128 format, FP32 local/global reduction, atomic=False, no optional scales/bias/zero-points, exact lossless repacking and unchanged all-output FP64 condition. It does not alter retained kernels, cuBLAS settings or the official E004 wheel. The local build calls the original upstream dispatcher through a narrow typed C ABI. Only FP16/uint4b8/G128 kernel selections are instantiated. A preserves original selection/accounting. B/C activate only for sm_120, M<=8, the selected eight-row 128x128 tile,256 threads,four stages and those fixed numerical settings. Other selections, including small-N fallback, M16 and M64, retain original launch policy.

Reservation is device-derived opt-in block shared size for A, and opt-in/2-1024 for B/C, checked against 41984 B enabled spatial layout and actual CUDA two-block occupancy capacity. On the verified device A requests 101376 B with 36 CTAs, B 49664 B with 36, and C 49664 B with 72. The same compiled device entrypoint serves all three. Dynamic allocation is not the used footprint. Maximum occupancy is not achieved residency. C changes striped K partitioning, inter-block locks and global FP32 reduction order, so FP16 output-bit identity with A is not required. Fallback A/B/C output bits are checked outside timing.

The caller allocates4*SM zeroed int32 locks plus guards, and `SM*min(ceil(maxM/16)*16,64)*256` FP32 scratch elements plus guards for each validation invocation. At maxM<=8 this is 589824 scratch bytes on 36 SMs. A/B/C share these allocations. Explicit index proof bounds the 72-CTA rectangle's maximum exclusive accessed scratch byte at 580608 and its maximum lock index at 70. First reducers initialize scratch and last reducers reset locks. Ordered same-stream calls reuse storage with no per-call memset. Initial locks/scratch/output poisoning and guards are outside capture. Tests poison C before each graph replay and check every output, lock reset and guards afterward.

E005 did not reach performance measurement. Its prepared common-event plan preserves E004's explicit graph stream, per-sample external CUDA event nodes and both application cache policies, with device-required maintenance inside the operation. Required setup remains outside timing. `measure_arc.sh` requires successful validation and a matching binary hash, but the VALIDATED sentinel is absent. Correctness JSONL policy labels do not indicate that cache flushing or timing was performed when iters=0. No E005 samples/medians/p90 or profiler counter series exists.

External memcheck/synccheck pass for the recorded representative cases. Racecheck fails on A/B/C and reproduces in unchanged local A and isolated official wheel at main square M8. Source spatial bounds do not establish safe temporal B/reduction reuse. Passing numerical checks and other sanitizers do not justify ignoring this report. Preserve the failed gate and stop dependent performance/held-out profiling work. Any safety/build/body change requires a separately authorized resolution, a new matched denominator and the full required series.

## 7. E006 bounded corrected-body contract

E006 adds one block-wide barrier after the existing stripe-final async-group drain, before B/reduction overlay reuse. Only the fixed dense FP16/uint4b8/G128 family compiled by E005 is validated. All quantization, packing, FP16 reconstruction, FP32 accumulation/global reduction, shapes, tile/stage/thread selection, host A/B/C policy, guards and numerical tolerances are unchanged. Original E005 remains the unmodified diagnostic control. Separate matched source trees/libraries and the explicit barrier patch are preserved in E006. All A/B/C calls in corrected validation share one patched device entrypoint per specialization.

Every numerical output is checked against FP64 at the unchanged elementwise threshold. Full code/scale/reconstruction bit checks remain mandatory. Repeated direct calls and graph replays reuse workspace without per-call lock memset, poison output before each replay and assert lock reset/guards afterward. Corrected M16/64 fallback output bits agree among A/B/C. Cross-version output-bit equality is not a required acceptance condition, and no claim of original incorrect output is inferred from an access report.

The corrected body passes135 regular validation rows and 162 representative sanitizer rows on c58. Memcheck/racecheck/synccheck filter the local GEMM name `kns=e005_marlin`. Packing/fill kernels are outside that filter and packing results are independently lossless-checked. The source explanation is a cross-warp lifetime gap. Its terminal-unused-fragment observation is limited to the analyzed small-M specialization and does not exempt unsynchronized accesses generally. No exact official-wheel PC/source correspondence or general sanitizer limitation is established.

E006 has no performance method or released samples. All rows use warmup=iters=0 with one no-flush label, and strict checks are outside any timed interval. No cache-state classification, latency comparison or achieved-residency claim is possible from E006. E005's historical VALIDATED remains absent. E005-R1 below is the separately authorized performance continuation. Corrected candidates must never use original-body or official-wheel times as denominators.

## 8. E005-R1 corrected-body timing and evidence reuse

E005-R1 reuses the exact E006 corrected source/library and verified unchanged environment. Its own prerequisite checks all 113 E006 evidence/handoff hashes, four binaries, generated source/build inputs, bridge, benchmark helpers, dependency freeze and actual GPU UUID/driver/tool/runtime/rank/thread conditions before reusing135 numerical/162 sanitizer rows. Fresh small numerical/poisoned-replay/guard/lock checks and retained GPU checks precede timing. Every timed/profile call also validates all outputs outside timing. A changed binary or environment requires relevant renewed validation. Historical E005/E006 records and absent VALIDATED sentinels remain unchanged.

A36/101376 B, B36/49664 B and C72/49664 B share the corrected body and entrypoint. Only corrected A is a performance denominator. Primary square M1/8 seed 1 and fallback M16/64 have two independent balanced series, 10 warmups/100 graph-event samples per row and both application cache policies. Held-out M2/4 seed 2 covers square and both rectangles with the same conditions and no retuning. The unchanged primary criterion requires C >=5% lower no-flush median at both M points in both series,<=5% store-flush regression and no reproducible >5% fallback regression. Report B separately and retain sample variance, p90 and between-series differences. C fails the primary gain criterion. No numerical/sanitizer criterion is loosened and no automatic dispatch follows.

The E004 event/capture/flush method and unchanged E005 caller remain authoritative. Allocation, repacking, references, checks, capture and store flushing stay outside GEMM event intervals. Device-required partition/reduction/lock work stays inside. Raw timing samples and input hashes are retained. Both cache policies remain operational labels, without proven eviction or residency.

Three square M8 Nsight profiles select one corrected A/B/C launch after 10 direct warmups, with kernel replay13 passes, cache-control none and clock-control none. Metric query and units are preserved. CTA activity per active or elapsed SM cycle is measured separately from maximum occupancy capacity. Dynamic requested shared and allocated shared differ by 1024 B here. Tensor-pipe activity is not peak FLOP/s. Replay traffic/duration is not an application-event measurement or a guarantee of warm/cold inputs. The raw demangler omits namespaces, so same-report mangled exports verify the exact local specialization. No roofline or additional optimization is included.

## 9. E007 terminal-lookahead comparison contract

E007 changes only the analyzed small-M shared-to-register lookahead. Its corrected control is generated from preserved E006 source. The candidate omits `fetch_to_registers(k+1,pipe)` at the last subfragment when the current stripe has exactly one K tile remaining. Both A/B next-tile buffer0 fragments are unused at that point. Existing scales, async-copy/commit/wait operations and every barrier remain unchanged. The compile-time scope is FP16 A/C/scales, uint4b8,G128, 256 threads, one eight-row M block, 128Kx128N,four stages and non-floating zero-point mode. All other compiled device functions must retain exact SASS. Full-output FP16 bits must agree across matching control/candidate configuration/shape/seed in addition to the unchanged all-output FP64 tolerance.

Newly built binaries require fresh checks. Both bodies have matched small/main numerical matrices and the candidate has representative memcheck/racecheck/synccheck across A/B/C, row tails, zero operands, fallback and rectangles. Workspace guards, reused locks, output poisoning and graph replay remain mandatory. Spatial footprints, global scratch/lock bounds and host policy stay those of E005/E006. The E006 phase-entry barrier remains required in this experiment regardless of the skipped lookahead.

Performance isolates the body using host A36/101376 B for both libraries. Each matched body runs in a fresh process to avoid mixed-library symbol/profiling ambiguity. Two process-paired primary/fallback series reverse body order. Common E004 graph-event timing is unchanged, with 10 warmups/100 samples and both operational cache policies. Newly recorded corrected control medians are the only denominators. Held-out seed 2 M2/4 covers square and both rectangles after fixing the candidate. Full-output hashes are computed outside timing by an E005 `Case` subclass. No extra work is added to GEMM event intervals. C's rejected grid policy is not combined with this change.

The predeclared 5% primary gain and <=5% store-flush/fallback regression rules remain fixed. Shared-load metrics have warp-level scopes distinct from integer thread-instruction counters. Static load-site counts are not executed load counts. Register count and register allocation granularity must be reported separately. Targeted M8 control/candidate profiles use queried supported metrics, no profiler cache flush and unlocked clocks. Replay traffic/duration is separate from application graph-event latency. No roofline is introduced.

E007 completes with 270 regular numerical/162 sanitizer rows passing and 56 timing rows/5600 samples. It fails its primary latency target. Its two profiles use 7 replay passes. Predicate-inclusive issued LDS/LDSM counts remain unchanged, while `pred_on_any` LDS falls 1.931%. Total warp instructions rise 1.757%. Initial static reporting counted only unpredicated loads. Corrected reporting distinguishes 121 total static LDS/LDSM opcode sites, 70 always-false sites and 51 potentially active sites in each body, with eight newly conditional candidate sites. Measured checker/analyzer snapshots and initial derived JSON are preserved. This post-measurement reporting fix changes no benchmark code, raw sample, numerical tolerance or acceptance rule.

## 10. E008 complete-cycle weight reuse distance

E008 keeps corrected E006 A/C, M=4, both rectangles, G128, FP16 reconstruction and FP32 local/global reduction. Four independent packed/scales allocations use seeds 3–6 with one fixed seed-3 activation and separately recomputed full FP64 references. Their accessed prefix has1/2/4 matrices, while all four allocations remain alive. Storage intervals must be disjoint and packed/scale hashes distinct. Each matrix has independent output and guarded locks/scratch. Repeated calls rely on the existing kernel's first partial writer and final lock reset, with no extra per-call reset needed. Every required device operation stays in the complete-cycle timed interval. Poisoning, allocation, packing, references and checks remain outside.

The unchanged E004 graph-event timer receives a callback that invokes each active matrix once in fixed index order. It records external events only before/after a complete cycle, with no artificial flush between cycles or matrices. Ten complete-cycle warmups precede100 complete-cycle samples. Cycle median divided by matrix count is a derived amortized latency, not an independent sample or single-kernel latency. Graph event nodes and final-output checks remain explicit. Three direct and three poisoned complete-cycle graph replays precede every row. All outputs, lock reset and workspace guards are checked after timing too.

Two independent processes reverse shape, cycle-length and A/C traversal order, producing24 rows/2400 cycles/5600 timed GEMMs. Match generated and packed operand hashes across configurations and series. The predeclared meaningful-gain rule is at least5% lower C cycle median in each series per rectangle/count, using only fresh matching A medians. Require the single-matrix control before extending that rectangle's opportunity. Report mixed, subthreshold and reproducibly losing cases separately. No counters, inference execution, eviction guarantee, dispatch or partition change follows from this measurement. Earlier store-flush results remain separate historical evidence.

## 11. E009 compressed versus FP16 cyclic execution

Reuse E008's operands, M=4/G128, rectangles, independent seeds 3–6 and fixed activation. Keep unchanged E006 A as the only Marlin path. Pre-materialized cuBLAS reads the exact FP16 W_hat, and unfused uses bridge ID6 to reconstruct it into one guarded reusable FP16 buffer before every GEMM. CuBLAS uses FP16 input/output, CUBLAS_COMPUTE_32F and explicit checked math mode 16 as established in E004. Individual GPU reconstructions must match all W_hat bits, every active output uses its fixed full FP64 reference, and every path passes three direct and three poisoned graph cycles with guards/reused workspace checked. No original-weight cuBLAS comparator or tolerance change.

Complete-cycle graph events surround every operation, including unfused dequantization plus GEMM and required Marlin scratch/reduction/lock work. There is no artificial flush or per-matrix event. One reusable temporary is safe for sequential same-stream calls and is not pre-materialized outside timing as a substitute for unfused. All four packed/scales pairs in both layouts, four pre-materialized W_hat matrices, outputs and Marlin workspace remain live across methods/counts. Record live storage intervals and accessed prefixes separately. Library-managed cuBLAS workspace has no exposed size in this bridge and is excluded from explicit tensor totals, as are graphs/events/runtime storage. Logical bytes do not measure DRAM traffic or establish cache residency.

Two independent series rotate implementation order over six cells and reverse per-cell order plus shape/count traversal. Exactly 36 rows, 10 whole-cycle warmups/100 samples, 3600 cycle samples/8400 GEMMs. Preserve samples and outliers, p90 uses sorted index89 and amortized median is cycle median divided by count. Fresh matched comparator/Marlin is speedup, 100*(1-Marlin/comparator) is lower-latency gain. Meaningful advantage requiresat least 5% in both series separately per comparator/shape/count. Smaller gains, ties, losses and order disagreement remain reported. Compressed versus pre-materialized execution includes different kernels and footprints. Versus unfused compares whole implementations and does not isolate fusion. No full-inference, token-throughput, stable-tail or unique-bottleneck claim.

E009 completes all 36 timing rows on c4 after a separately verified node migration. c10 contributes validation/diagnostic history only. All shape/count/comparator pairs meet the fixed5% rule in both series. The complete numerical/sanitizer and source/binary gates pass before timing. Counter/roofline/fusion-only/inference claims remain outside the method. Final working-set totals, table, retained anomalies, reproduction commands and interpretation are in E009's experiment record.

## 12. E010 four-matrix batch crossover

E010 compares only corrected E006 A and pre-materialized FP16 W_hat cuBLAS at M=4,16,64,128, both rectangles and four distinct matrices per cycle. Preserve seeds 3–6, one common seed-3 activation, G128, FP16 reconstruction/storage, FP32 local/global accumulation, explicit cuBLAS mode 16 and the unchanged all-output FP64 threshold. Retain E009's graph-event timing, ten cycle warmups/100 samples, no artificial flush, complete required workspace handling and two independent reversed series. Each cycle has four GEMMs. Report median/4 only as a derived amortized value.

Allocate activation/output/reference capacity128 for all points. Execute and validate the first M rows. The deterministic generator uses separate activation and weight PRNG streams, so weight codes/scales/W_hat remain identical across capacity and M. Record full-capacity and active-prefix hashes separately. Assert inactive output rows retain their poisoned NaNs. Keep four compressed pairs, four FP16 W_hat matrices, four guarded outputs/workspaces and one shared activation alive across both methods. Omit unused project-layout copies and unfused temporary, which are present in E009. Thus fresh E010 measurements are required, and E009 medians are historical context only. Private cuBLAS/runtime/graph storage remains outside explicit tensor totals.

Use the original corrected A dispatcher at every M, not a forced M4 kernel. Record each dry-query resource plan and a separate untimed actual-call trace at each shape/M. Match demangled template arguments to the query and verify only the expected local Marlin kernel executes. Record grid, threads, M8 flag, M/K/N tile, stages, registers, shared reservation, workspace capacities and kernel identity. Repeated direct/poisoned graph cycles, locks, guards, exact roundtrip and relevant fresh sanitizer checks precede timing. A specialization transition alone does not establish the cause of a latency change.

An agreed winner requires the same strict median direction in both series. Adjacent initial points with opposite agreed winners bracket a crossover. Only then add one arithmetic midpoint per original bracket, with both shapes, complete validation and two reversed series. Ties/order disagreement are inconclusive. Report the >=5% Marlin lower-latency gate separately from a sign change. Stop if there is no bracket. No extrapolation above 128, automatic dispatch, counters, kernel change or subsequent optimization follows.

E010 completes all 32 timing rows without a sign-change bracket, so no midpoint is measured. Seven of eight practical 5% gates pass. K4096/N11008 at M128 retains only 2.166%/2.903% lower Marlin medians, below that gate. The transpose retains 15.203%/16.808%. Every initial point executes one traced Marlin kernel with matching queried attributes. M128 processes two 64-row tiles in one call. Final numerical and full four-matrix memcheck/synccheck pass. Racecheck uses one seed-3 representative matrix at every shape/M with matching operands/resources, three direct and three poisoned graph calls, and 0 hazards/errors/warnings. The original expensive composed racecheck is preserved as incomplete exit 143, not a pass. All full composed numerical/timing checks remain unchanged. No kernel, dispatch or tolerance change.

## 13. E011 endpoint profiling contract

E011 preserves E010 operands, capacity 128, four distinct matrices/seeds 3–6, nested activation prefixes, exact FP16 reconstruction, FP32 accumulation/reduction and cuBLAS mode 16. Only M4/M128 and the two original rectangles are profiled, corrected A versus pre-materialized W_hat cuBLAS. Full numerical output and resource/operand identities are compared with E010 before profiling. Unchanged same-environment sanitizer evidence is reused, not silently generalized.

Use application replay, strict grid/order matching, graph-node mode, profiler cache-control none, clock-control none and dynamic pipeline boost. Every pass repeats setup, ten direct complete cycles and the entire 100-cycle event-delimited graph. A start/stop window encloses graph replay, with deterministic launch skip/count selecting all kernels of operation 4 in cycle 100, using one-based positions. No flush or altered workspace reset is inserted. A separate tiny calibration verifies window counting. Trace all four direct operations and a complete graph cycle to prove operation coverage and stable selection. Per-kernel serialization/instrumentation, pass overhead, unlocked clocks and the target's fixed matrix position remain differences from application timing.

Fresh endpoint context uses the unchanged E010 complete-cycle timer in two independent reversed series, 16 rows/1600 cycle samples, ten warmups and 100 samples each. Historical E010 is not a timing denominator. Counter duration is separate from cycle/amortized latency. DRAM/L2 traffic includes all accesses, not identified weight-only traffic. Normalize exact counter units. Sum additive bytes/instructions/sequential kernel durations across a multi-kernel GEMM. Keep rates, resource attributes and utilization per kernel unless a weighting is explicitly justified. Tensor activity is not peak FLOP utilization, stalls are not disjoint wall-time fractions, resource limits are not achieved residency, and similar latencies do not prove a memory/compute crossover.

E011 completed with 33 queried metrics and 13 application passes per kernel. All eight cycle traces use one device/kernel stream; one selected cuBLAS operation contains two kernels and both are included. Per-kernel rates/resources remain separate. MiB is 2^20 bytes; instruction millions are 10^6. Application values are complete-cycle medians/4; profiler durations sum sequential kernel durations excluding gaps. Do not interpret their 1.13–6.69% difference as a kernel-phase decomposition. Source-derived partition/scratch requests are logical models including padded rows, not measured L2/DRAM traffic or reduction time. No numerical or dispatch contract changes follow from E011.

## 14. E012 source-PC diagnostic contract

E012 preserves the exact corrected A binary and E011 four-matrix workload at M4/M128 on both rectangles. Every application pass reruns setup, ten warmup cycles and the full 100-cycle graph, targeting operation four of the final cycle with skip 399/count 1. Cache/clock controls stay none, with strict matching and dynamic pipeline boost. Four software-patched instruction captures and two reversed four-case unpatched sampling series are separate diagnostic methods. Neither supplies a new production latency comparison.

`inst_executed` counts warp instructions ignoring instruction predicates, with unit `inst`. Sampling counters record PC/state samples or sampled warps, and diagnostics record bytes/passes/cycles. Exact API units and CSV values must agree. Join counts to every CLI-exported inline location by exact PC, deduplicate PCs and preserve conflicting/generic caller ownership as ambiguous. Single-source coverage is distinct from phase attribution. Do not use source labels to infer arithmetic execution on predicated-off paths or turn instruction shares into time fractions.

The sampling setting is fixed before collection: option 0/32 cycles, one pass, 33554432 B buffer. Gates require at least 1000 samples, no overflow or dropped bytes, at least 95% source coverage and no region-share change above 10 percentage points across series. All-ones PC samples remain in the declared denominator. All eight actual captures fail dropped-data quality and M128 additionally fails source coverage. Their shares are preserved with failed-quality flags, not accepted bottleneck evidence. Do not retune or change the denominator after seeing these results. Ambiguous instruction ownership is bounded before making a majority claim. No tolerance, packing, G128, accumulation or dispatcher change follows.

## 15. E014 separate full-model validation and timing

E014 leaves all GEMM rules unchanged. Its pinned dense Qwen2.5-1.5B model uses identical FP16 parameters/KV, tokenizer, enforced memory-efficient SDPA, causal semantics and greedy decoding across dynamic eager, static eager and static compiled paths. Batch size 1, context 128/2048, 64 fixed output tokens (one from prefill, 63 cached forwards), with EOS recorded but ignored for equal work. Full-model correctness is relative to same-precision dynamic A, not the GEMM FP64 reference or a model-quality evaluation.

For both primary/held-out passages require finite all-vocabulary logits at every output position, exact 64-token agreement, every logit `abs(delta) <= 0.03 + 0.01*abs(reference)`, and relative L2 <= 0.003. Check primary A against uncached full-prefix forwards at positions 0/63. No tolerance relaxation, token divergence or silent eager/attention fallback. Parameter/source/environment identity and actual compilation, graph breaks/recompilation/replay must be audited. Static versus dynamic masked capacity and bundled compiler fusion/scheduling limit attribution.

Timing would require three warmup requests, 20 raw requests/cell in two independent reversed process orders, synchronized wall-clock decode over 63 cached forwards, TTFT from tokenization to CPU-visible token 1, and E2E through final output copy/detokenization. Record load/setup/first-compiled-request costs separately. A transition/context requires >=5% lower decode median in both primary series, then confirmation in both held-out series; report all prefill/E2E/memory/context regressions. [Detailed boundaries and orders](EXPERIMENTS.md#e014-diagnostic-gate-and-fixed-comparison-criteria) remain predeclared.

**Observed stopping rule:** C2048 fails the elementwise gate (415 logits), so no comparison timing is released, including the passing subset. Matching greedy tokens and passing aggregate L2 do not override failure. Warmup/validation timings and profiler kernel counts cannot establish speedup. The original failed tensor was not retained; count/norm/max survive in logs. Preserve that limitation and stop rather than silently retrying or changing the contract.
