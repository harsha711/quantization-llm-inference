#!/usr/bin/env python3
"""Validate E011 operation coverage and fresh matched endpoint evidence."""
import argparse
import csv
import gzip
import hashlib
import importlib.util
import json
import math
import re
from pathlib import Path
import statistics

from plan import CYCLES, MS, NAMES, SHAPES, WARMUP, target

spec = importlib.util.spec_from_file_location('e010_analysis', Path(__file__).resolve().parents[1] / 'e010/analyze.py')
e010 = importlib.util.module_from_spec(spec)
spec.loader.exec_module(e010)


def raw(path):
    rows = list(csv.reader(path.open()))
    assert len(rows) >= 3 and all(len(row) == len(rows[0]) for row in rows)
    return dict(zip(rows[0], rows[1])), [dict(zip(rows[0], row)) for row in rows[2:]]


def number(row, key):
    value = float(row[key].replace(',', ''))
    assert math.isfinite(value), (key, row[key])
    return value


def kernel_identity(symbol):
    # shortcut: these cuBLAS templates have no nested arguments, extend if target traces introduce them.
    function, arguments = symbol.split('<', 1)
    arguments = arguments.split('>', 1)[0]
    assert '<' not in arguments
    arguments = re.sub(r'\btrue\b', '1', re.sub(r'\bfalse\b', '0', arguments))
    arguments = re.sub(r'\((?:bool|int|long|unsigned int)\)', '', arguments)
    return function.rsplit('::', 1)[-1].split()[-1], re.sub(r'\s+', '', arguments)


def matched(row, reference):
    assert row['body_sha256'] == reference['body_sha256'] == e010.e008.BODY
    assert row['cublas_math_mode'] == reference['cublas_math_mode'] == 16
    assert row['activation_prefix_sha256'] == reference['activation_prefix_sha256']
    assert (row['capacity'], row['matrices'], row['seeds'], row['group']) == (128, 4, [3, 4, 5, 6], 128)
    assert row['direct_cycles'] == row['poisoned_graph_cycles'] == 3
    assert len(row['allocations']) == len(row['validation']) == 4
    ranges = [row['allocations'][0]['activation_range']]
    for operand, old, check, old_check in zip(row['allocations'], reference['allocations'], row['validation'], reference['validation']):
        for key in ('operand_sha256', 'packed_sha256', 'scales_sha256', 'wh_sha256'):
            assert operand[key] == old[key], key
        assert operand['activation_range'] == row['allocations'][0]['activation_range']
        for key in ('packed', 'scales', 'wh', 'output', 'locks', 'scratch'):
            ranges.append(operand[key + '_range'])
        assert check['num_bad'] == 0 and check['checked'] == row['M'] * row['N']
        assert check['output_sha256'] == old_check['output_sha256']
    e010.e008.disjoint(ranges)
    assert len(row['resources']) == (4 if row['config'] == 'marlin' else 0)
    for current, old in zip(row['resources'], reference['resources']):
        assert {k: v for k, v in current.items() if k != 'kernel_address'} == {k: v for k, v in old.items() if k != 'kernel_address'}


def main(root, stage):
    def success(label):
        assert (root / (label + '.exit')).read_text().strip() == '0', label

    old = [json.loads(line) for line in (root / 'e010-validation-reference.jsonl').read_text().splitlines()]
    lookup = {(v['K'], v['N'], v['M'], v['config']): v for v in old}
    success('calibration')
    _, calibration = raw(root / 'ncu/calibration.csv')
    assert len(calibration) == 1 and 'add' in calibration[0]['Kernel Name'].lower(), calibration
    assert '--launch-skip 399 --launch-count 1' in (root / 'calibration.log').read_text()
    path = root / 'supported-metrics.txt'
    query = (path.read_text() if path.exists() else gzip.decompress(path.with_suffix('.txt.gz').read_bytes()).decode())
    query += (root / 'launch-metrics.txt').read_text()
    available = {line.split()[0] for line in query.splitlines() if line.strip()}
    metrics = Path(__file__).with_name('metrics.txt').read_text().splitlines()
    assert len(metrics) == len(set(metrics)) == 33
    assert all(metric in available for metric in metrics), set(metrics) - available
    assert (root / 'e010-handoff-check.log').read_text().count(': OK') == 153
    assert not (root / 'dependency-diff.txt').read_text()
    for label in ('identity', 'identity-validation', 'runtime', 'smoke', 'library-identity'):
        success(label)
    smoke = [json.loads(line) for line in (root / 'smoke.jsonl').read_text().splitlines()]
    assert len(smoke) == 4
    for row in smoke:
        e010.checked(row)
    assert (root / 'validation-library-check.log').read_text().count(': OK') == 6
    assert (root / 'validation-input-check.log').read_text().count(': OK') == 3
    traces = {}
    for k, n in SHAPES:
        for m in MS:
            for name in NAMES:
                tag = f'{name}_M{m}_K{k}_N{n}'
                success('trace_' + tag)
                row = json.loads((root / ('trace_' + tag + '.json')).read_text())
                assert (row['K'], row['N'], row['M'], row['config']) == (k, n, m, name)
                matched(row, lookup[k, n, m, name])
                plan = target(row['kernels_by_matrix'])
                assert all(row[key] == value for key, value in plan.items())
                assert row['cycle_kernels'] == row['kernels_by_matrix'][0] * 4
                for suffix, expected in [('target', row['kernels_by_matrix'][3]), ('cycle', row['cycle_kernels'])]:
                    trace = json.loads((root / f'trace_{tag}.{suffix}.trace.json').read_text())
                    assert [event['name'] for event in trace['traceEvents'] if event.get('cat') == 'kernel'] == expected
                if name == 'marlin':
                    assert plan['launch_count'] == 1
                    a = row['resources'][0]
                    assert e010.template_values(row['kernels_by_matrix'][3][0])[-8:] == [a['threads'], a['m_blocks'], a['thread_n']//16, a['thread_k']//16, a['m8'], a['stages'], 8, 0]
                traces[tag] = row
    if stage == 'validation':
        print('PASS: eight complete-operation traces, E010 operands/outputs/resources, profiler-window calibration, 33 supported metrics')
        return
    timings = []
    for series, shapes, ms in [(1, SHAPES, MS), (2, SHAPES[::-1], MS[::-1])]:
        success(f'series{series}')
        rows = [json.loads(line) for line in (root / f'series{series}.jsonl').read_text().splitlines()]
        assert [(v['K'], v['N'], v['M'], v['config'], v['order']) for v in rows] == e010.traversal(shapes, ms, series)
        for row in rows:
            e010.checked(row)
            matched(row, lookup[row['K'], row['N'], row['M'], row['config']])
            assert row['warmup'] == WARMUP and row['iters'] == CYCLES and row['series'] == series
            samples = row['samples_us']
            assert len(samples) == CYCLES and all(math.isfinite(x) and x > 0 for x in samples)
            assert row['median_us'] == statistics.median(samples)
            assert (row['min_us'], row['max_us'], row['p90_us']) == (min(samples), max(samples), sorted(samples)[89])
            assert row['post_timing_validation'] == row['validation']
        timings.extend(rows)
    comparisons = []
    for k, n in SHAPES:
        for m in MS:
            for series in (1, 2):
                pair = {v['config']: v for v in timings if (v['K'], v['N'], v['M'], v['series']) == (k, n, m, series)}
                a, b = pair['marlin']['median_us'], pair['cublas_dq']['median_us']
                comparisons.append(dict(K=k, N=n, M=m, series=series, marlin_cycle_us=a, cublas_cycle_us=b,
                                        speedup=b/a, marlin_gain_pct=100*(1-a/b)))
    with (root / 'comparisons.csv').open('w') as out:
        writer = csv.DictWriter(out, fieldnames=list(comparisons[0]))
        writer.writeheader()
        writer.writerows(comparisons)
    stats = [dict(K=v['K'], N=v['N'], M=v['M'], config=v['config'], series=v['series'],
                  median_us=v['median_us'], p90_us=v['p90_us'], min_us=v['min_us'], max_us=v['max_us'],
                  stdev_us=statistics.stdev(v['samples_us'])) for v in timings]
    with (root / 'sample-statistics.csv').open('w') as out:
        writer = csv.DictWriter(out, fieldnames=list(stats[0]))
        writer.writeheader()
        writer.writerows(stats)
    if stage == 'timing':
        print('PASS: 16 complete fresh endpoint timing rows/1600 cycle samples, profiles not assessed')
        return
    for label in ('measurement', 'final'):
        assert (root / f'{label}-input-check.log').read_text().count(': OK') == 3
        assert (root / f'{label}-library-check.log').read_text().count(': OK') == 6
    for label in ('identity-measurement', 'identity-final'):
        success(label)
    assert (root / 'final-e010-handoff-check.log').read_text().count(': OK') == 153
    tooling = (root / 'measurement-tooling.sha256').read_text().splitlines()
    assert (root / 'final-tooling-check.log').read_text().count(': OK') == len(tooling)
    repo = Path(__file__).resolve().parents[2]
    for line in tooling:
        digest, path = line.split(maxsplit=1)
        assert hashlib.sha256((repo / path).read_bytes()).hexdigest() == digest, path
    if (root / 'measurement-timeout-accounting.txt').exists():
        assert 'TIMEOUT' in (root / 'measurement-timeout-accounting.txt').read_text()
        success('identity-resume-profile')
        assert (root / 'resume-profile-library-check.log').read_text().count(': OK') == 6
        assert (root / 'resume-profile-input-check.log').read_text().count(': OK') == 3
        assert (root / 'resume-profile-tooling-check.log').read_text().count(': OK') == len(tooling)
        assert (root / 'profile_cublas_dq_M4_K11008_N4096.attempt1.log').exists()
    profiles = []
    for tag, trace in traces.items():
        success('profile_' + tag)
        text = (root / ('profile_' + tag + '.log')).read_text()
        passes = [json.loads(line.split('E011_PASS ', 1)[1]) for line in text.splitlines() if line.startswith('E011_PASS ')]
        assert passes, tag
        for required in ('--replay-mode application', '--app-replay-mode strict --app-replay-match grid',
                         '--profile-from-start off --graph-profiling node --cache-control none --clock-control none',
                         '--pipeline-boost-state dynamic',
                         f"--launch-skip {trace['launch_skip']} --launch-count {trace['launch_count']}"):
            assert required in text, (tag, required)
        for row in passes:
            assert tuple(row[key] for key in ('K', 'N', 'M', 'config')) == tuple(trace[key] for key in ('K', 'N', 'M', 'config'))
            assert (row['warmup'], row['graph_cycles'], row['policy'], row['replay'], row['cache_control'], row['clock_control']) == (10, 100, 'no_artificial_flush', 'application', 'none', 'none')
            matched(row, trace)
            assert row['post_profile_validation'] == row['validation']
        unit, values = raw(root / f'ncu/{tag}.csv')
        assert len(values) == trace['launch_count'], (tag, len(values))
        pass_counts = [int(number(value, 'profiler__replayer_passes')) for value in values]
        assert len(passes) == max(pass_counts), (tag, len(passes), pass_counts)
        kernels = []
        for i, value in enumerate(values):
            assert value['CC'] == '12.0'
            expected = trace['kernels_by_matrix'][3][i]
            if trace['config'] == 'marlin':
                assert e010.template_values(value['Kernel Name']) == e010.template_values(expected)
            else:
                assert kernel_identity(value['Kernel Name']) == kernel_identity(expected)
            normalized = {metric: number(value, metric) for metric in metrics}
            for metric in ('dram__bytes_op_read.sum', 'dram__bytes_op_write.sum', 'lts__t_bytes.sum'):
                assert unit[metric] == 'byte'
            assert unit['smsp__inst_executed.sum'] == unit['sm__inst_executed_pipe_tensor.sum'] == 'inst'
            if trace['config'] == 'marlin':
                for metric, attribute in [('launch__grid_size', 'grid'), ('launch__block_size', 'threads'),
                                          ('launch__registers_per_thread', 'registers'),
                                          ('launch__shared_mem_per_block_dynamic', 'dynamic_shared')]:
                    assert normalized[metric] == trace['resources'][0][attribute]
            assert unit['gpu__time_duration.sum'] == 'ns'
            normalized['duration_us'] = normalized['gpu__time_duration.sum']/1000
            kernels.append(dict(name=value['Kernel Name'], units={metric: unit[metric] for metric in metrics}, metrics=normalized))
        # Keep per-kernel utilization/resources. Sum only sequential, additive work.
        additive = ['duration_us', 'dram__bytes_op_read.sum', 'dram__bytes_op_write.sum', 'lts__t_bytes.sum',
                    'lts__t_sectors_op_read.sum', 'lts__t_sectors_op_write.sum',
                    'smsp__inst_executed_pipe_alu.sum', 'smsp__inst_executed_pipe_fma.sum',
                    'smsp__inst_executed.sum', 'sm__inst_executed_pipe_tensor.sum',
                    'l1tex__t_sectors_pipe_lsu_mem_local_op_ld.sum', 'l1tex__t_sectors_pipe_lsu_mem_local_op_st.sum']
        profiles.append(dict(K=trace['K'], N=trace['N'], M=trace['M'], config=trace['config'],
                             kernels=kernels, totals={metric: sum(kernel['metrics'][metric] for kernel in kernels) for metric in additive},
                             replay_passes_by_kernel=pass_counts, validated_application_executions=len(passes)))
    (root / 'profile-analysis.json').write_text(json.dumps(profiles, indent=2) + '\n')
    compact = []
    for profile in profiles:
        kernels, totals = profile['kernels'], profile['totals']
        pair = [v for v in timings if (v['K'], v['N'], v['M'], v['config']) == (profile['K'], profile['N'], profile['M'], profile['config'])]
        entry = {key: profile[key] for key in ('K', 'N', 'M', 'config')}
        entry.update(application_cycle_us_s1=pair[0]['median_us'], application_cycle_us_s2=pair[1]['median_us'],
                     application_amortized_us_s1=pair[0]['median_us']/4, application_amortized_us_s2=pair[1]['median_us']/4,
                     profiler_operation_us=totals['duration_us'], dram_read_bytes=totals['dram__bytes_op_read.sum'],
                     dram_write_bytes=totals['dram__bytes_op_write.sum'], l2_bytes=totals['lts__t_bytes.sum'],
                     warp_instructions=totals['smsp__inst_executed.sum'], tensor_instructions=totals['sm__inst_executed_pipe_tensor.sum'])
        for metric in ('sm__pipe_tensor_cycles_active.avg.pct_of_peak_sustained_elapsed',
                       'smsp__warps_eligible.avg.per_cycle_active', 'smsp__issue_active.avg.pct_of_peak_sustained_active',
                       'launch__registers_per_thread', 'launch__shared_mem_per_block_dynamic',
                       'l1tex__t_sectors_pipe_lsu_mem_local_op_ld.sum', 'l1tex__t_sectors_pipe_lsu_mem_local_op_st.sum'):
            entry[metric] = json.dumps([kernel['metrics'][metric] for kernel in kernels])
        compact.append(entry)
    with (root / 'endpoint-summary.csv').open('w') as out:
        writer = csv.DictWriter(out, fieldnames=list(compact[0]))
        writer.writeheader()
        writer.writerows(compact)
    table = [
        'Application values are cycle median/4 in us, series 1 / series 2. Profiler duration is the sum of selected sequential kernel durations, excluding gaps. Traffic and instructions cover the fixed seed 6 operation, not all four matrices. MiB means 2^20 bytes and instruction millions mean 10^6. Tensor activity and eligible warps remain per kernel, in GEMM/reduction order for the two-kernel operation. Percentages are not peak FLOP utilization.',
        '',
        '| K / N | M | Implementation | Application us/GEMM S1 / S2 | Profiler sum us | DRAM read / write MiB | L2 MiB | Warp inst M | Tensor active % | Eligible warps |',
        '|---|---:|---|---:|---:|---:|---:|---:|---:|---:|',
    ]
    for row in compact:
        tensor = ' / '.join(f'{v:.2f}' for v in json.loads(row['sm__pipe_tensor_cycles_active.avg.pct_of_peak_sustained_elapsed']))
        eligible = ' / '.join(f'{v:.2f}' for v in json.loads(row['smsp__warps_eligible.avg.per_cycle_active']))
        table.append(f"| {row['K']} / {row['N']} | {row['M']} | {'Marlin A' if row['config'] == 'marlin' else 'FP16 cuBLAS'} | "
                     f"{row['application_amortized_us_s1']:.3f} / {row['application_amortized_us_s2']:.3f} | {row['profiler_operation_us']:.3f} | "
                     f"{row['dram_read_bytes']/2**20:.3f} / {row['dram_write_bytes']/2**20:.3f} | {row['l2_bytes']/2**20:.3f} | "
                     f"{row['warp_instructions']/1e6:.3f} | {tensor} | {eligible} |")
    (root / 'endpoint-table.md').write_text('\n'.join(table) + '\n')
    print('PASS: 16 fresh endpoint timing rows/1600 complete-cycle samples and eight context-preserving complete-operation profiles')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('results', type=Path)
    parser.add_argument('--stage', choices=['validation', 'timing', 'complete'], default='complete')
    args = parser.parse_args()
    main(args.results, args.stage)
