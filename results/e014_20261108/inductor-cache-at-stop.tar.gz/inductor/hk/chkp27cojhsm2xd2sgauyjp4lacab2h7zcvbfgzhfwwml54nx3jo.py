# AOT ID: ['0_inference']
from ctypes import c_void_p, c_long, c_int
import torch
import math
import random
import os
import tempfile
from math import inf, nan
from cmath import nanj
from torch._inductor.hooks import run_intermediate_hooks
from torch._inductor.utils import maybe_profile
from torch._inductor.codegen.memory_planning import _align as align
from torch import device, empty_strided
from torch._inductor.async_compile import AsyncCompile
from torch._inductor.select_algorithm import extern_kernels
import triton
import triton.language as tl
from torch._inductor.runtime.triton_heuristics import start_graph, end_graph
from torch._C import _cuda_getCurrentRawStream as get_raw_stream

aten = torch.ops.aten
inductor_ops = torch.ops.inductor
_quantized = torch.ops._quantized
assert_size_stride = torch._C._dynamo.guards.assert_size_stride
assert_size_stride_grouped = torch._C._dynamo.guards.assert_size_stride_grouped
assert_alignment = torch._C._dynamo.guards.assert_alignment
empty_strided_cpu = torch._C._dynamo.guards._empty_strided_cpu
empty_strided_cpu_pinned = torch._C._dynamo.guards._empty_strided_cpu_pinned
empty_strided_cuda = torch._C._dynamo.guards._empty_strided_cuda
empty_strided_xpu = torch._C._dynamo.guards._empty_strided_xpu
empty_strided_mtia = torch._C._dynamo.guards._empty_strided_mtia
reinterpret_tensor = torch._C._dynamo.guards._reinterpret_tensor
alloc_from_pool = torch.ops.inductor._alloc_from_pool
async_compile = AsyncCompile()
empty_strided_p2p = torch._C._distributed_c10d._SymmetricMemory.empty_strided_p2p
from torch._C._dynamo.guards import copy_if_misaligned
from torch._C import _cuda_getCurrentRawStream as get_raw_stream
from torch._inductor.runtime.runtime_utils import assert_tensor_metadata



# kernel path: /home/hpuvvad/csc548-w4a16-e014-c4-20261108/cache/inductor/b6/cb6qnvfrjanruepdkudetw5z6gpuh57t7ng6ztehxtrjhnuzjzxu.py
# Topologically Sorted Source Nodes: [inputs_embeds, hidden_states, pow_1, variance, add, rsqrt, hidden_states_1, to_4, hidden_states_2], Original ATen: [aten.embedding, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   add => add
#   hidden_states => convert_element_type_3
#   hidden_states_1 => mul_3
#   hidden_states_2 => mul_4
#   inputs_embeds => embedding
#   pow_1 => pow_1
#   rsqrt => rsqrt
#   to_4 => convert_element_type_4
#   variance => mean
# Graph fragment:
#   %arg1_1 : Tensor "i64[1, 1][1, 1]cuda:0" = PlaceHolder[target=arg1_1]
#   %arg2_1 : Tensor "f16[151936, 1536][1536, 1]cuda:0" = PlaceHolder[target=arg2_1]
#   %arg5_1 : Tensor "f16[1536][1]cuda:0" = PlaceHolder[target=arg5_1]
#   %buf0 : Tensor "f32[1, 1, 1][1, 1, 1]cuda:0" = PlaceHolder[target=buf0]
#   %embedding : Tensor "f16[1, 1, 1536][1536, 1536, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.embedding.default](args = (%arg2_1, %arg1_1), kwargs = {})
#   %convert_element_type_3 : Tensor "f32[1, 1, 1536][1536, 1536, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%embedding, torch.float32), kwargs = {})
#   %pow_1 : Tensor "f32[1, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_3, 2), kwargs = {})
#   %mean : Tensor "f32[1, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_1, [-1], True), kwargs = {})
#   %add : Tensor "f32[1, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean, 1e-06), kwargs = {})
#   %rsqrt : Tensor "f32[1, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add,), kwargs = {})
#   %mul_3 : Tensor "f32[1, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_3, %rsqrt), kwargs = {})
#   %convert_element_type_4 : Tensor "f16[1, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_3, torch.float16), kwargs = {})
#   %mul_4 : Tensor "f16[1, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg5_1, %convert_element_type_4), kwargs = {})
#   return %buf0,%mul_4
triton_red_fused__to_copy_add_embedding_mean_mul_pow_rsqrt_0 = async_compile.triton('triton_red_fused__to_copy_add_embedding_mean_mul_pow_rsqrt_0', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 1, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i64', 'in_ptr1': '*fp16', 'in_ptr2': '*fp16', 'out_ptr1': '*fp16', 'xnumel': 'constexpr', 'r0_numel': 'i32', 'XBLOCK': 'constexpr', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=36, cc=120, major=12, regs_per_multiprocessor=65536, max_threads_per_multi_processor=1536, max_threads_per_block=1024, warp_size=32), 'constants': {'xnumel': 1}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy_add_embedding_mean_mul_pow_rsqrt_0', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 3, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'r0_': 9216}, 'backend_hash': '25ED88F5935B940EC1927250A0CAECF41F6A0D2252E814102945959BFC20A347', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused__to_copy_add_embedding_mean_mul_pow_rsqrt_0(in_ptr0, in_ptr1, in_ptr2, out_ptr1, xnumel, r0_numel, XBLOCK : tl.constexpr, R0_BLOCK : tl.constexpr):
    xnumel = 1
    r0_numel = 1536
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = tl.full([XBLOCK], True, tl.int1)[:, None]
    r0_base = tl.arange(0, R0_BLOCK)[None, :]
    rbase = r0_base
    tmp0 = tl.load(in_ptr0 + (0))
    tmp1 = tl.broadcast_to(tmp0, [1, 1])
    _tmp7 = tl.full([XBLOCK, R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tl.device_assert((0 <= tmp1) & (tmp1 < 151936), "index out of bounds: 0 <= tmp1 < 151936")
        tmp3 = tl.load(in_ptr1 + (r0_0 + 1536*tmp1), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp4 = tmp3.to(tl.float32)
        tmp5 = tmp4 * tmp4
        tmp6 = tl.broadcast_to(tmp5, [XBLOCK, R0_BLOCK])
        tmp8 = _tmp7 + tmp6
        _tmp7 = tl.where(r0_mask, tmp8, _tmp7)
    tmp7 = tl.sum(_tmp7, 1)[:, None]
    tmp10 = tl.load(in_ptr0 + (0))
    tmp11 = tl.broadcast_to(tmp10, [1, 1])
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp9 = tl.load(in_ptr2 + (r0_0), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tl.device_assert((0 <= tmp11) & (tmp11 < 151936), "index out of bounds: 0 <= tmp11 < 151936")
        tmp13 = tl.load(in_ptr1 + (r0_0 + 1536*tmp11), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp14 = tmp13.to(tl.float32)
        tmp15 = tl.full([1, 1], 1536.0, tl.float32)
        tmp16 = (tmp7 / tmp15)
        tmp17 = tl.full([1, 1], 1e-06, tl.float32)
        tmp18 = tmp16 + tmp17
        tmp19 = libdevice.rsqrt(tmp18)
        tmp20 = tmp14 * tmp19
        tmp21 = tmp20.to(tl.float32)
        tmp22 = tmp9 * tmp21
        tl.store(out_ptr1 + (tl.broadcast_to(r0_0, [XBLOCK, R0_BLOCK])), tmp22, r0_mask)
''', device_str='cuda')


# kernel path: /home/hpuvvad/csc548-w4a16-e014-c4-20261108/cache/inductor/5c/c5clq7gdbbthl7ivfgb7vlsjlbonkga2epqwibkifvuuj2eeyy5a.py
# Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, cos_3, sin_1, sin_2, sin_3, linear_1, view_2, key_states, mul_6, x2_1, neg_1, x1_1, cat_2, mul_7, k_embed, index_copy_], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.index_copy]
# Source node to ATen node mapping:
#   cat_2 => cat_1
#   cos_1 => cos
#   cos_2 => convert_element_type_1
#   cos_3 => unsqueeze_4
#   emb => clone, expand_3, unsqueeze_3, view_4
#   expand => expand
#   freqs => permute
#   getitem => unsqueeze, unsqueeze_1
#   getitem_1 => unsqueeze_2
#   index_copy_ => index_put
#   k_embed => add_2
#   key_states => permute_4
#   linear_1 => view_9
#   matmul => mul
#   mul_6 => mul_7
#   mul_7 => mul_8
#   neg_1 => neg_1
#   position_ids_expanded => convert_element_type
#   sin_1 => sin
#   sin_2 => convert_element_type_2
#   sin_3 => unsqueeze_5
#   view => view
#   view_2 => view_10
#   x1_1 => slice_3
#   x2_1 => slice_4
# Graph fragment:
#   %arg0_1 : Tensor "i64[1][1]cuda:0" = PlaceHolder[target=arg0_1]
#   %addmm_1 : Tensor "f16[1, 256][256, 1]cuda:0" = PlaceHolder[target=addmm_1]
#   %arg4_1 : Tensor "f32[64][1]cuda:0" = PlaceHolder[target=arg4_1]
#   %index_put : Tensor "f16[1, 2, 192, 128][49152, 24576, 128, 1]cuda:0" = PlaceHolder[target=index_put]
#   %unsqueeze : Tensor "f32[1, 64][64, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%arg4_1, 0), kwargs = {})
#   %unsqueeze_1 : Tensor "f32[1, 64, 1][64, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%unsqueeze, 2), kwargs = {})
#   %expand : Tensor "f32[1, 64, 1][64, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_1, [1, -1, 1]), kwargs = {})
#   %view : Tensor "i64[1, 1][1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%arg0_1, [1, 1]), kwargs = {})
#   %unsqueeze_2 : Tensor "i64[1, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%view, 1), kwargs = {})
#   %convert_element_type : Tensor "f32[1, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%unsqueeze_2, torch.float32), kwargs = {})
#   %mul : Tensor "f32[1, 64, 1][64, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%expand_1, %expand_2), kwargs = {})
#   %permute : Tensor "f32[1, 1, 64][64, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%mul, [0, 2, 1]), kwargs = {})
#   %unsqueeze_3 : Tensor "f32[1, 1, 1, 64][64, 1, 64, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%permute, 2), kwargs = {})
#   %expand_3 : Tensor "f32[1, 1, 2, 64][64, 1, 0, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_3, [1, 1, 2, 64]), kwargs = {})
#   %clone : Tensor "f32[1, 1, 2, 64][128, 128, 64, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%expand_3,), kwargs = {memory_format: torch.contiguous_format})
#   %view_4 : Tensor "f32[1, 1, 128][128, 128, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.reshape.default](args = (%clone, [1, 1, 128]), kwargs = {})
#   %cos : Tensor "f32[1, 1, 128][128, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.cos.default](args = (%view_4,), kwargs = {})
#   %convert_element_type_1 : Tensor "f16[1, 1, 128][128, 128, 1]cuda:0"[num_users=28] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%cos, torch.float16), kwargs = {})
#   %unsqueeze_4 : Tensor "f16[1, 1, 1, 128][128, 128, 128, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%convert_element_type_1, 1), kwargs = {})
#   %sin : Tensor "f32[1, 1, 128][128, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%view_4,), kwargs = {})
#   %convert_element_type_2 : Tensor "f16[1, 1, 128][128, 128, 1]cuda:0"[num_users=28] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%sin, torch.float16), kwargs = {})
#   %unsqueeze_5 : Tensor "f16[1, 1, 1, 128][128, 128, 128, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%convert_element_type_2, 1), kwargs = {})
#   %view_9 : Tensor "f16[1, 1, 256][256, 256, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%addmm_1, [1, 1, 256]), kwargs = {})
#   %view_10 : Tensor "f16[1, 1, 2, 128][256, 256, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_9, [1, 1, -1, 128]), kwargs = {})
#   %permute_4 : Tensor "f16[1, 2, 1, 128][256, 128, 256, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.permute.default](args = (%view_10, [0, 2, 1, 3]), kwargs = {})
#   %mul_7 : Tensor "f16[1, 2, 1, 128][256, 128, 256, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%permute_4, %unsqueeze_4), kwargs = {})
#   %slice_4 : Tensor "f16[1, 2, 1, 64][256, 128, 256, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%permute_4, 3, 64, 9223372036854775807), kwargs = {})
#   %neg_1 : Tensor "f16[1, 2, 1, 64][128, 64, 64, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%slice_4,), kwargs = {})
#   %slice_3 : Tensor "f16[1, 2, 1, 64][256, 128, 256, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%permute_4, 3, 0, 64), kwargs = {})
#   %cat_1 : Tensor "f16[1, 2, 1, 128][256, 128, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.cat.default](args = ([%neg_1, %slice_3], -1), kwargs = {})
#   %mul_8 : Tensor "f16[1, 2, 1, 128][256, 128, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%cat_1, %unsqueeze_5), kwargs = {})
#   %add_2 : Tensor "f16[1, 2, 1, 128][256, 128, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mul_7, %mul_8), kwargs = {})
#   %index_put : Tensor "f16[1, 2, 192, 128][49152, 24576, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.index_put_.default](args = (%arg12_1, [None, None, %arg0_1], %add_2), kwargs = {})
#   return %buf4
triton_poi_fused__to_copy_add_bmm_cat_expand_index_copy_mul_neg_slice_transpose_unsqueeze_view_1 = async_compile.triton('triton_poi_fused__to_copy_add_bmm_cat_expand_index_copy_mul_neg_slice_transpose_unsqueeze_view_1', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 256}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i64', 'in_ptr1': '*fp16', 'in_ptr2': '*fp32', 'out_ptr0': '*fp16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=36, cc=120, major=12, regs_per_multiprocessor=65536, max_threads_per_multi_processor=1536, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__to_copy_add_bmm_cat_expand_index_copy_mul_neg_slice_transpose_unsqueeze_view_1', 'mutated_arg_names': ['out_ptr0'], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 5, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 1792}, 'backend_hash': '25ED88F5935B940EC1927250A0CAECF41F6A0D2252E814102945959BFC20A347', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__to_copy_add_bmm_cat_expand_index_copy_mul_neg_slice_transpose_unsqueeze_view_1(in_ptr0, in_ptr1, in_ptr2, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 256
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x2 = xindex
    x0 = (xindex % 128)
    x1 = xindex // 128
    tmp0 = tl.load(in_ptr0 + (0))
    tmp1 = tl.broadcast_to(tmp0, [XBLOCK])
    tmp7 = tl.load(in_ptr1 + (x2), xmask).to(tl.float32)
    tmp8 = tl.load(in_ptr2 + ((x2 % 64)), xmask, eviction_policy='evict_last')
    tmp2 = (tl.full([XBLOCK], 192, tl.int32)).to(tl.int32)
    tmp3 = tmp1 + tmp2
    tmp4 = tmp1 < 0
    tmp5 = tl.where(tmp4, tmp3, tmp1)
    tl.device_assert((0 <= tmp5) & (tmp5 < 192), "index out of bounds: 0 <= tmp5 < 192")
    tmp9 = tmp1.to(tl.float32)
    tmp10 = tmp8 * tmp9
    tmp11 = tl_math.cos(tmp10)
    tmp12 = tmp11.to(tl.float32)
    tmp13 = tmp7 * tmp12
    tmp14 = (x0).to(tl.int32)
    tmp15 = tl.full([1], 0, tl.int64)
    tmp16 = tmp14 >= tmp15
    tmp17 = (x0).to(tl.int64)
    tmp18 = (tmp17).to(tl.int64)
    tmp19 = tl.full([1], 64, tl.int64)
    tmp20 = tmp18 < tmp19
    tmp21 = tl.load(in_ptr1 + (64 + 128*x1 + (x0)), tmp20 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp22 = -tmp21
    tmp23 = tl.full(tmp22.shape, 0.0, tmp22.dtype)
    tmp24 = tl.where(tmp20, tmp22, tmp23)
    tmp25 = tmp14 >= tmp19
    tmp26 = tl.full([1], 128, tl.int64)
    tmp27 = tmp14 < tmp26
    tmp28 = tl.load(in_ptr1 + (128*x1 + ((-64) + x0)), tmp25 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp29 = tl.where(tmp20, tmp24, tmp28)
    tmp30 = tl_math.sin(tmp10)
    tmp31 = tmp30.to(tl.float32)
    tmp32 = tmp29 * tmp31
    tmp33 = tmp13 + tmp32
    tl.store(out_ptr0 + (x0 + 128*tmp5 + 24576*x1), tmp33, xmask)
''', device_str='cuda')


# kernel path: /home/hpuvvad/csc548-w4a16-e014-c4-20261108/cache/inductor/xt/cxtltzwewd4p3psngqpzcy7uhpot3pw65itgoltrgwhefcyja2fu.py
# Topologically Sorted Source Nodes: [linear_2, view_3, value_states, index_copy__1], Original ATen: [aten.view, aten.transpose, aten.index_copy]
# Source node to ATen node mapping:
#   index_copy__1 => index_put_1
#   linear_2 => view_12
#   value_states => permute_6
#   view_3 => view_13
# Graph fragment:
#   %arg0_1 : Tensor "i64[1][1]cuda:0" = PlaceHolder[target=arg0_1]
#   %addmm_2 : Tensor "f16[1, 256][256, 1]cuda:0" = PlaceHolder[target=addmm_2]
#   %index_put_1 : Tensor "f16[1, 2, 192, 128][49152, 24576, 128, 1]cuda:0" = PlaceHolder[target=index_put_1]
#   %view_12 : Tensor "f16[1, 1, 256][256, 256, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%addmm_2, [1, 1, 256]), kwargs = {})
#   %view_13 : Tensor "f16[1, 1, 2, 128][256, 256, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_12, [1, 1, -1, 128]), kwargs = {})
#   %permute_6 : Tensor "f16[1, 2, 1, 128][256, 128, 256, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%view_13, [0, 2, 1, 3]), kwargs = {})
#   %index_put_1 : Tensor "f16[1, 2, 192, 128][49152, 24576, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.index_put_.default](args = (%arg13_1, [None, None, %arg0_1], %permute_6), kwargs = {})
#   return %buf6
triton_poi_fused_index_copy_transpose_view_2 = async_compile.triton('triton_poi_fused_index_copy_transpose_view_2', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 256}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i64', 'in_ptr1': '*fp16', 'out_ptr0': '*fp16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=36, cc=120, major=12, regs_per_multiprocessor=65536, max_threads_per_multi_processor=1536, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused_index_copy_transpose_view_2', 'mutated_arg_names': ['out_ptr0'], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 2, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 512}, 'backend_hash': '25ED88F5935B940EC1927250A0CAECF41F6A0D2252E814102945959BFC20A347', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused_index_copy_transpose_view_2(in_ptr0, in_ptr1, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 256
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x2 = xindex
    x0 = (xindex % 128)
    x1 = xindex // 128
    tmp0 = tl.load(in_ptr0 + (0))
    tmp1 = tl.broadcast_to(tmp0, [XBLOCK])
    tmp7 = tl.load(in_ptr1 + (x2), xmask).to(tl.float32)
    tmp2 = (tl.full([XBLOCK], 192, tl.int32)).to(tl.int32)
    tmp3 = tmp1 + tmp2
    tmp4 = tmp1 < 0
    tmp5 = tl.where(tmp4, tmp3, tmp1)
    tl.device_assert((0 <= tmp5) & (tmp5 < 192), "index out of bounds: 0 <= tmp5 < 192")
    tl.store(out_ptr0 + (x0 + 128*tmp5 + 24576*x1), tmp7, xmask)
''', device_str='cuda')


# kernel path: /home/hpuvvad/csc548-w4a16-e014-c4-20261108/cache/inductor/ye/cyetx3efts4uqwuxh4s72ctndr6eveeaqrqhvbnqz5jg2tjzsoja.py
# Topologically Sorted Source Nodes: [linear, view_1, query_states, getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, cos_3, mul_4, x2, neg, x1, cat_1, sin_1, sin_2, sin_3, mul_5, q_embed, key, value, attn_output], Original ATen: [aten.view, aten.transpose, aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.clone, aten._unsafe_view, aten._scaled_dot_product_efficient_attention]
# Source node to ATen node mapping:
#   attn_output => _scaled_dot_product_efficient_attention, expand_8
#   cat_1 => cat
#   cos_1 => cos
#   cos_2 => convert_element_type_1
#   cos_3 => unsqueeze_4
#   emb => clone, expand_3, unsqueeze_3, view_4
#   expand => expand
#   freqs => permute
#   getitem => unsqueeze, unsqueeze_1
#   getitem_1 => unsqueeze_2
#   key => clone_2, expand_5, unsqueeze_8, view_14
#   linear => view_6
#   matmul => mul
#   mul_4 => mul_5
#   mul_5 => mul_6
#   neg => neg
#   position_ids_expanded => convert_element_type
#   q_embed => add_1
#   query_states => permute_2
#   sin_1 => sin
#   sin_2 => convert_element_type_2
#   sin_3 => unsqueeze_5
#   value => clone_3, expand_7, unsqueeze_11, view_15
#   view => view
#   view_1 => view_7
#   x1 => slice_1
#   x2 => slice_2
# Graph fragment:
#   %addmm : Tensor "f16[1, 1536][1536, 1]cuda:0" = PlaceHolder[target=addmm]
#   %arg4_1 : Tensor "f32[64][1]cuda:0" = PlaceHolder[target=arg4_1]
#   %arg0_1 : Tensor "i64[1][1]cuda:0" = PlaceHolder[target=arg0_1]
#   %view_6 : Tensor "f16[1, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%addmm, [1, 1, 1536]), kwargs = {})
#   %view_7 : Tensor "f16[1, 1, 12, 128][1536, 1536, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_6, [1, 1, -1, 128]), kwargs = {})
#   %permute_2 : Tensor "f16[1, 12, 1, 128][1536, 128, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.permute.default](args = (%view_7, [0, 2, 1, 3]), kwargs = {})
#   %unsqueeze : Tensor "f32[1, 64][64, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%arg4_1, 0), kwargs = {})
#   %unsqueeze_1 : Tensor "f32[1, 64, 1][64, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%unsqueeze, 2), kwargs = {})
#   %expand : Tensor "f32[1, 64, 1][64, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_1, [1, -1, 1]), kwargs = {})
#   %view : Tensor "i64[1, 1][1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%arg0_1, [1, 1]), kwargs = {})
#   %unsqueeze_2 : Tensor "i64[1, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%view, 1), kwargs = {})
#   %convert_element_type : Tensor "f32[1, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%unsqueeze_2, torch.float32), kwargs = {})
#   %mul : Tensor "f32[1, 64, 1][64, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%expand_1, %expand_2), kwargs = {})
#   %permute : Tensor "f32[1, 1, 64][64, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%mul, [0, 2, 1]), kwargs = {})
#   %unsqueeze_3 : Tensor "f32[1, 1, 1, 64][64, 1, 64, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%permute, 2), kwargs = {})
#   %expand_3 : Tensor "f32[1, 1, 2, 64][64, 1, 0, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_3, [1, 1, 2, 64]), kwargs = {})
#   %clone : Tensor "f32[1, 1, 2, 64][128, 128, 64, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%expand_3,), kwargs = {memory_format: torch.contiguous_format})
#   %view_4 : Tensor "f32[1, 1, 128][128, 128, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.reshape.default](args = (%clone, [1, 1, 128]), kwargs = {})
#   %cos : Tensor "f32[1, 1, 128][128, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.cos.default](args = (%view_4,), kwargs = {})
#   %convert_element_type_1 : Tensor "f16[1, 1, 128][128, 128, 1]cuda:0"[num_users=28] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%cos, torch.float16), kwargs = {})
#   %unsqueeze_4 : Tensor "f16[1, 1, 1, 128][128, 128, 128, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%convert_element_type_1, 1), kwargs = {})
#   %mul_5 : Tensor "f16[1, 12, 1, 128][1536, 128, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%permute_2, %unsqueeze_4), kwargs = {})
#   %slice_2 : Tensor "f16[1, 12, 1, 64][1536, 128, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%permute_2, 3, 64, 9223372036854775807), kwargs = {})
#   %neg : Tensor "f16[1, 12, 1, 64][768, 64, 64, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%slice_2,), kwargs = {})
#   %slice_1 : Tensor "f16[1, 12, 1, 64][1536, 128, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%permute_2, 3, 0, 64), kwargs = {})
#   %cat : Tensor "f16[1, 12, 1, 128][1536, 128, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.cat.default](args = ([%neg, %slice_1], -1), kwargs = {})
#   %sin : Tensor "f32[1, 1, 128][128, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%view_4,), kwargs = {})
#   %convert_element_type_2 : Tensor "f16[1, 1, 128][128, 128, 1]cuda:0"[num_users=28] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%sin, torch.float16), kwargs = {})
#   %unsqueeze_5 : Tensor "f16[1, 1, 1, 128][128, 128, 128, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%convert_element_type_2, 1), kwargs = {})
#   %mul_6 : Tensor "f16[1, 12, 1, 128][1536, 128, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%cat, %unsqueeze_5), kwargs = {})
#   %add_1 : Tensor "f16[1, 12, 1, 128][1536, 128, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mul_5, %mul_6), kwargs = {})
#   %unsqueeze_8 : Tensor "f16[1, 2, 1, 192, 128][49152, 24576, 24576, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%index_put, 2), kwargs = {})
#   %expand_5 : Tensor "f16[1, 2, 6, 192, 128][49152, 24576, 0, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_8, [1, 2, 6, 192, 128]), kwargs = {})
#   %clone_2 : Tensor "f16[1, 2, 6, 192, 128][294912, 147456, 24576, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%expand_5,), kwargs = {memory_format: torch.contiguous_format})
#   %view_14 : Tensor "f16[1, 12, 192, 128][294912, 24576, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%clone_2, [1, 12, 192, 128]), kwargs = {})
#   %unsqueeze_11 : Tensor "f16[1, 2, 1, 192, 128][49152, 24576, 24576, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%index_put_1, 2), kwargs = {})
#   %expand_7 : Tensor "f16[1, 2, 6, 192, 128][49152, 24576, 0, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_11, [1, 2, 6, 192, 128]), kwargs = {})
#   %clone_3 : Tensor "f16[1, 2, 6, 192, 128][294912, 147456, 24576, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%expand_7,), kwargs = {memory_format: torch.contiguous_format})
#   %view_15 : Tensor "f16[1, 12, 192, 128][294912, 24576, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%clone_3, [1, 12, 192, 128]), kwargs = {})
#   %expand_8 : Tensor "f16[1, 12, 1, 192][192, 0, 192, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%arg3_1, [1, 12, 1, 192]), kwargs = {})
#   %_scaled_dot_product_efficient_attention : [num_users=1] = call_function[target=torch.ops.aten._scaled_dot_product_efficient_attention.default](args = (%add_1, %view_14, %view_15, %expand_8, False), kwargs = {scale: 0.08838834764831845})
#   return %buf7
triton_poi_fused__scaled_dot_product_efficient_attention__to_copy__unsafe_view_add_bmm_cat_clone_expand_mul_neg_slice_transpose_unsqueeze_view_3 = async_compile.triton('triton_poi_fused__scaled_dot_product_efficient_attention__to_copy__unsafe_view_add_bmm_cat_clone_expand_mul_neg_slice_transpose_unsqueeze_view_3', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 2048}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp16', 'in_ptr1': '*fp32', 'in_ptr2': '*i64', 'out_ptr0': '*fp16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=36, cc=120, major=12, regs_per_multiprocessor=65536, max_threads_per_multi_processor=1536, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__scaled_dot_product_efficient_attention__to_copy__unsafe_view_add_bmm_cat_clone_expand_mul_neg_slice_transpose_unsqueeze_view_3', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 5, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 15616}, 'backend_hash': '25ED88F5935B940EC1927250A0CAECF41F6A0D2252E814102945959BFC20A347', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__scaled_dot_product_efficient_attention__to_copy__unsafe_view_add_bmm_cat_clone_expand_mul_neg_slice_transpose_unsqueeze_view_3(in_ptr0, in_ptr1, in_ptr2, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 1536
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x2 = xindex
    x0 = (xindex % 128)
    x1 = xindex // 128
    tmp0 = tl.load(in_ptr0 + (x2), xmask).to(tl.float32)
    tmp1 = tl.load(in_ptr1 + ((x2 % 64)), xmask, eviction_policy='evict_last')
    tmp2 = tl.load(in_ptr2 + (0))
    tmp3 = tl.broadcast_to(tmp2, [XBLOCK])
    tmp4 = tmp3.to(tl.float32)
    tmp5 = tmp1 * tmp4
    tmp6 = tl_math.cos(tmp5)
    tmp7 = tmp6.to(tl.float32)
    tmp8 = tmp0 * tmp7
    tmp9 = (x0).to(tl.int32)
    tmp10 = tl.full([1], 0, tl.int64)
    tmp11 = tmp9 >= tmp10
    tmp12 = (x0).to(tl.int64)
    tmp13 = (tmp12).to(tl.int64)
    tmp14 = tl.full([1], 64, tl.int64)
    tmp15 = tmp13 < tmp14
    tmp16 = tl.load(in_ptr0 + (64 + 128*x1 + (x0)), tmp15 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp17 = -tmp16
    tmp18 = tl.full(tmp17.shape, 0.0, tmp17.dtype)
    tmp19 = tl.where(tmp15, tmp17, tmp18)
    tmp20 = tmp9 >= tmp14
    tmp21 = tl.full([1], 128, tl.int64)
    tmp22 = tmp9 < tmp21
    tmp23 = tl.load(in_ptr0 + (128*x1 + ((-64) + x0)), tmp20 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp24 = tl.where(tmp15, tmp19, tmp23)
    tmp25 = tl_math.sin(tmp5)
    tmp26 = tmp25.to(tl.float32)
    tmp27 = tmp24 * tmp26
    tmp28 = tmp8 + tmp27
    tl.store(out_ptr0 + (x2), tmp28, xmask)
''', device_str='cuda')


# kernel path: /home/hpuvvad/csc548-w4a16-e014-c4-20261108/cache/inductor/qq/cqqssyp2wvfvwvt5o2orhll65f64rdz5aqwjtsfggehptwtggtvw.py
# Topologically Sorted Source Nodes: [linear, view_1, query_states, getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, cos_3, mul_4, x2, neg, x1, cat_1, sin_1, sin_2, sin_3, mul_5, q_embed, key, value, attn_output], Original ATen: [aten.view, aten.transpose, aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.clone, aten._unsafe_view, aten._scaled_dot_product_efficient_attention]
# Source node to ATen node mapping:
#   attn_output => _scaled_dot_product_efficient_attention, expand_8
#   cat_1 => cat
#   cos_1 => cos
#   cos_2 => convert_element_type_1
#   cos_3 => unsqueeze_4
#   emb => clone, expand_3, unsqueeze_3, view_4
#   expand => expand
#   freqs => permute
#   getitem => unsqueeze, unsqueeze_1
#   getitem_1 => unsqueeze_2
#   key => clone_2, expand_5, unsqueeze_8, view_14
#   linear => view_6
#   matmul => mul
#   mul_4 => mul_5
#   mul_5 => mul_6
#   neg => neg
#   position_ids_expanded => convert_element_type
#   q_embed => add_1
#   query_states => permute_2
#   sin_1 => sin
#   sin_2 => convert_element_type_2
#   sin_3 => unsqueeze_5
#   value => clone_3, expand_7, unsqueeze_11, view_15
#   view => view
#   view_1 => view_7
#   x1 => slice_1
#   x2 => slice_2
# Graph fragment:
#   %buf4 : Tensor "f16[1, 2, 192, 128][49152, 24576, 128, 1]cuda:0" = PlaceHolder[target=buf4]
#   %view_6 : Tensor "f16[1, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%addmm, [1, 1, 1536]), kwargs = {})
#   %view_7 : Tensor "f16[1, 1, 12, 128][1536, 1536, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%view_6, [1, 1, -1, 128]), kwargs = {})
#   %permute_2 : Tensor "f16[1, 12, 1, 128][1536, 128, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.permute.default](args = (%view_7, [0, 2, 1, 3]), kwargs = {})
#   %unsqueeze : Tensor "f32[1, 64][64, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%arg4_1, 0), kwargs = {})
#   %unsqueeze_1 : Tensor "f32[1, 64, 1][64, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%unsqueeze, 2), kwargs = {})
#   %expand : Tensor "f32[1, 64, 1][64, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_1, [1, -1, 1]), kwargs = {})
#   %view : Tensor "i64[1, 1][1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%arg0_1, [1, 1]), kwargs = {})
#   %unsqueeze_2 : Tensor "i64[1, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%view, 1), kwargs = {})
#   %convert_element_type : Tensor "f32[1, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%unsqueeze_2, torch.float32), kwargs = {})
#   %mul : Tensor "f32[1, 64, 1][64, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%expand_1, %expand_2), kwargs = {})
#   %permute : Tensor "f32[1, 1, 64][64, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%mul, [0, 2, 1]), kwargs = {})
#   %unsqueeze_3 : Tensor "f32[1, 1, 1, 64][64, 1, 64, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%permute, 2), kwargs = {})
#   %expand_3 : Tensor "f32[1, 1, 2, 64][64, 1, 0, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_3, [1, 1, 2, 64]), kwargs = {})
#   %clone : Tensor "f32[1, 1, 2, 64][128, 128, 64, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%expand_3,), kwargs = {memory_format: torch.contiguous_format})
#   %view_4 : Tensor "f32[1, 1, 128][128, 128, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.reshape.default](args = (%clone, [1, 1, 128]), kwargs = {})
#   %cos : Tensor "f32[1, 1, 128][128, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.cos.default](args = (%view_4,), kwargs = {})
#   %convert_element_type_1 : Tensor "f16[1, 1, 128][128, 128, 1]cuda:0"[num_users=28] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%cos, torch.float16), kwargs = {})
#   %unsqueeze_4 : Tensor "f16[1, 1, 1, 128][128, 128, 128, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%convert_element_type_1, 1), kwargs = {})
#   %mul_5 : Tensor "f16[1, 12, 1, 128][1536, 128, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%permute_2, %unsqueeze_4), kwargs = {})
#   %slice_2 : Tensor "f16[1, 12, 1, 64][1536, 128, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%permute_2, 3, 64, 9223372036854775807), kwargs = {})
#   %neg : Tensor "f16[1, 12, 1, 64][768, 64, 64, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%slice_2,), kwargs = {})
#   %slice_1 : Tensor "f16[1, 12, 1, 64][1536, 128, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%permute_2, 3, 0, 64), kwargs = {})
#   %cat : Tensor "f16[1, 12, 1, 128][1536, 128, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.cat.default](args = ([%neg, %slice_1], -1), kwargs = {})
#   %sin : Tensor "f32[1, 1, 128][128, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sin.default](args = (%view_4,), kwargs = {})
#   %convert_element_type_2 : Tensor "f16[1, 1, 128][128, 128, 1]cuda:0"[num_users=28] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%sin, torch.float16), kwargs = {})
#   %unsqueeze_5 : Tensor "f16[1, 1, 1, 128][128, 128, 128, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%convert_element_type_2, 1), kwargs = {})
#   %mul_6 : Tensor "f16[1, 12, 1, 128][1536, 128, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%cat, %unsqueeze_5), kwargs = {})
#   %add_1 : Tensor "f16[1, 12, 1, 128][1536, 128, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mul_5, %mul_6), kwargs = {})
#   %unsqueeze_8 : Tensor "f16[1, 2, 1, 192, 128][49152, 24576, 24576, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%index_put, 2), kwargs = {})
#   %expand_5 : Tensor "f16[1, 2, 6, 192, 128][49152, 24576, 0, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_8, [1, 2, 6, 192, 128]), kwargs = {})
#   %clone_2 : Tensor "f16[1, 2, 6, 192, 128][294912, 147456, 24576, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%expand_5,), kwargs = {memory_format: torch.contiguous_format})
#   %view_14 : Tensor "f16[1, 12, 192, 128][294912, 24576, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%clone_2, [1, 12, 192, 128]), kwargs = {})
#   %unsqueeze_11 : Tensor "f16[1, 2, 1, 192, 128][49152, 24576, 24576, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%index_put_1, 2), kwargs = {})
#   %expand_7 : Tensor "f16[1, 2, 6, 192, 128][49152, 24576, 0, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_11, [1, 2, 6, 192, 128]), kwargs = {})
#   %clone_3 : Tensor "f16[1, 2, 6, 192, 128][294912, 147456, 24576, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%expand_7,), kwargs = {memory_format: torch.contiguous_format})
#   %view_15 : Tensor "f16[1, 12, 192, 128][294912, 24576, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%clone_3, [1, 12, 192, 128]), kwargs = {})
#   %expand_8 : Tensor "f16[1, 12, 1, 192][192, 0, 192, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%arg3_1, [1, 12, 1, 192]), kwargs = {})
#   %_scaled_dot_product_efficient_attention : [num_users=1] = call_function[target=torch.ops.aten._scaled_dot_product_efficient_attention.default](args = (%add_1, %view_14, %view_15, %expand_8, False), kwargs = {scale: 0.08838834764831845})
#   return %buf8
triton_poi_fused__scaled_dot_product_efficient_attention__to_copy__unsafe_view_add_bmm_cat_clone_expand_mul_neg_slice_transpose_unsqueeze_view_4 = async_compile.triton('triton_poi_fused__scaled_dot_product_efficient_attention__to_copy__unsafe_view_add_bmm_cat_clone_expand_mul_neg_slice_transpose_unsqueeze_view_4', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 524288}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp16', 'out_ptr0': '*fp16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=36, cc=120, major=12, regs_per_multiprocessor=65536, max_threads_per_multi_processor=1536, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__scaled_dot_product_efficient_attention__to_copy__unsafe_view_add_bmm_cat_clone_expand_mul_neg_slice_transpose_unsqueeze_view_4', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 1179648}, 'backend_hash': '25ED88F5935B940EC1927250A0CAECF41F6A0D2252E814102945959BFC20A347', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__scaled_dot_product_efficient_attention__to_copy__unsafe_view_add_bmm_cat_clone_expand_mul_neg_slice_transpose_unsqueeze_view_4(in_ptr0, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 294912
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = tl.full([XBLOCK], True, tl.int1)[:]
    x0 = (xindex % 24576)
    x1 = xindex // 24576
    x2 = xindex
    tmp0 = tl.load(in_ptr0 + (x0 + 24576*(x1 // 6)), None).to(tl.float32)
    tl.store(out_ptr0 + (x2), tmp0, None)
''', device_str='cuda')


# kernel path: /home/hpuvvad/csc548-w4a16-e014-c4-20261108/cache/inductor/en/cenmecbu6cp5jtri5wrtysceixjkt5qaoydmn6bcnqnd4bunr4p5.py
# Topologically Sorted Source Nodes: [inputs_embeds, attn_output_3, hidden_states_5, hidden_states_6, pow_2, variance_1, add_4, rsqrt_1, hidden_states_7, to_6, hidden_states_8], Original ATen: [aten.embedding, aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   add_4 => add_4
#   attn_output_3 => view_18
#   hidden_states_5 => add_3
#   hidden_states_6 => convert_element_type_16
#   hidden_states_7 => mul_9
#   hidden_states_8 => mul_10
#   inputs_embeds => embedding
#   pow_2 => pow_2
#   rsqrt_1 => rsqrt_1
#   to_6 => convert_element_type_17
#   variance_1 => mean_1
# Graph fragment:
#   %arg1_1 : Tensor "i64[1, 1][1, 1]cuda:0" = PlaceHolder[target=arg1_1]
#   %arg2_1 : Tensor "f16[151936, 1536][1536, 1]cuda:0" = PlaceHolder[target=arg2_1]
#   %mm : Tensor "f16[1, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm]
#   %arg15_1 : Tensor "f16[1536][1]cuda:0" = PlaceHolder[target=arg15_1]
#   %buf16 : Tensor "f32[1, 1, 1][1, 1, 1]cuda:0" = PlaceHolder[target=buf16]
#   %embedding : Tensor "f16[1, 1, 1536][1536, 1536, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.embedding.default](args = (%arg2_1, %arg1_1), kwargs = {})
#   %view_18 : Tensor "f16[1, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm, [1, 1, 1536]), kwargs = {})
#   %add_3 : Tensor "f16[1, 1, 1536][1536, 1536, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%embedding, %view_18), kwargs = {})
#   %convert_element_type_16 : Tensor "f32[1, 1, 1536][1536, 1536, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_3, torch.float32), kwargs = {})
#   %pow_2 : Tensor "f32[1, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_16, 2), kwargs = {})
#   %mean_1 : Tensor "f32[1, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_2, [-1], True), kwargs = {})
#   %add_4 : Tensor "f32[1, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_1, 1e-06), kwargs = {})
#   %rsqrt_1 : Tensor "f32[1, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_4,), kwargs = {})
#   %mul_9 : Tensor "f32[1, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_16, %rsqrt_1), kwargs = {})
#   %convert_element_type_17 : Tensor "f16[1, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_9, torch.float16), kwargs = {})
#   %mul_10 : Tensor "f16[1, 1, 1536][1536, 1536, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg15_1, %convert_element_type_17), kwargs = {})
#   return %buf16,%mul_10
triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_5 = async_compile.triton('triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_5', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 1, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i64', 'in_ptr1': '*fp16', 'in_ptr2': '*fp16', 'in_ptr3': '*fp16', 'out_ptr1': '*fp16', 'xnumel': 'constexpr', 'r0_numel': 'i32', 'XBLOCK': 'constexpr', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=36, cc=120, major=12, regs_per_multiprocessor=65536, max_threads_per_multi_processor=1536, max_threads_per_block=1024, warp_size=32), 'constants': {'xnumel': 1}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_5', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 5, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'r0_': 12288}, 'backend_hash': '25ED88F5935B940EC1927250A0CAECF41F6A0D2252E814102945959BFC20A347', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_5(in_ptr0, in_ptr1, in_ptr2, in_ptr3, out_ptr1, xnumel, r0_numel, XBLOCK : tl.constexpr, R0_BLOCK : tl.constexpr):
    xnumel = 1
    r0_numel = 1536
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = tl.full([XBLOCK], True, tl.int1)[:, None]
    r0_base = tl.arange(0, R0_BLOCK)[None, :]
    rbase = r0_base
    tmp0 = tl.load(in_ptr0 + (0))
    tmp1 = tl.broadcast_to(tmp0, [1, 1])
    _tmp9 = tl.full([XBLOCK, R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp4 = tl.load(in_ptr2 + (r0_0), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tl.device_assert((0 <= tmp1) & (tmp1 < 151936), "index out of bounds: 0 <= tmp1 < 151936")
        tmp3 = tl.load(in_ptr1 + (r0_0 + 1536*tmp1), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp5 = tmp3 + tmp4
        tmp6 = tmp5.to(tl.float32)
        tmp7 = tmp6 * tmp6
        tmp8 = tl.broadcast_to(tmp7, [XBLOCK, R0_BLOCK])
        tmp10 = _tmp9 + tmp8
        _tmp9 = tl.where(r0_mask, tmp10, _tmp9)
    tmp9 = tl.sum(_tmp9, 1)[:, None]
    tmp12 = tl.load(in_ptr0 + (0))
    tmp13 = tl.broadcast_to(tmp12, [1, 1])
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp11 = tl.load(in_ptr3 + (r0_0), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp16 = tl.load(in_ptr2 + (r0_0), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tl.device_assert((0 <= tmp13) & (tmp13 < 151936), "index out of bounds: 0 <= tmp13 < 151936")
        tmp15 = tl.load(in_ptr1 + (r0_0 + 1536*tmp13), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp17 = tmp15 + tmp16
        tmp18 = tmp17.to(tl.float32)
        tmp19 = tl.full([1, 1], 1536.0, tl.float32)
        tmp20 = (tmp9 / tmp19)
        tmp21 = tl.full([1, 1], 1e-06, tl.float32)
        tmp22 = tmp20 + tmp21
        tmp23 = libdevice.rsqrt(tmp22)
        tmp24 = tmp18 * tmp23
        tmp25 = tmp24.to(tl.float32)
        tmp26 = tmp11 * tmp25
        tl.store(out_ptr1 + (tl.broadcast_to(r0_0, [XBLOCK, R0_BLOCK])), tmp26, r0_mask)
''', device_str='cuda')


# kernel path: /home/hpuvvad/csc548-w4a16-e014-c4-20261108/cache/inductor/6z/c6zpyfrnwndk5uvxm7zqnwmxt75xig2ze6b2ofiunxrjha2lbwom.py
# Topologically Sorted Source Nodes: [linear_4, silu, linear_5, mul_10], Original ATen: [aten._unsafe_view, aten.silu, aten.mul]
# Source node to ATen node mapping:
#   linear_4 => view_20
#   linear_5 => view_22
#   mul_10 => mul_11
#   silu => add_5, convert_element_type_20, convert_element_type_21, div, exp, neg_2
# Graph fragment:
#   %mm_1 : Tensor "f16[1, 8960][8960, 1]cuda:0" = PlaceHolder[target=mm_1]
#   %mm_2 : Tensor "f16[1, 8960][8960, 1]cuda:0" = PlaceHolder[target=mm_2]
#   %view_20 : Tensor "f16[1, 1, 8960][8960, 8960, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_1, [1, 1, 8960]), kwargs = {})
#   %convert_element_type_20 : Tensor "f32[1, 1, 8960][8960, 8960, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_20, torch.float32), kwargs = {})
#   %neg_2 : Tensor "f32[1, 1, 8960][8960, 8960, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%convert_element_type_20,), kwargs = {})
#   %exp : Tensor "f32[1, 1, 8960][8960, 8960, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.exp.default](args = (%neg_2,), kwargs = {})
#   %add_5 : Tensor "f32[1, 1, 8960][8960, 8960, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%exp, 1), kwargs = {})
#   %div : Tensor "f32[1, 1, 8960][8960, 8960, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.div.Tensor](args = (%convert_element_type_20, %add_5), kwargs = {})
#   %convert_element_type_21 : Tensor "f16[1, 1, 8960][8960, 8960, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%div, torch.float16), kwargs = {})
#   %view_22 : Tensor "f16[1, 1, 8960][8960, 8960, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_2, [1, 1, 8960]), kwargs = {})
#   %mul_11 : Tensor "f16[1, 1, 8960][8960, 8960, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_21, %view_22), kwargs = {})
#   return %mul_11
triton_poi_fused__unsafe_view_mul_silu_6 = async_compile.triton('triton_poi_fused__unsafe_view_mul_silu_6', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 16384}, 
    filename=__file__,
    triton_meta={'signature': {'in_out_ptr0': '*fp16', 'in_ptr0': '*fp16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=36, cc=120, major=12, regs_per_multiprocessor=65536, max_threads_per_multi_processor=1536, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__unsafe_view_mul_silu_6', 'mutated_arg_names': ['in_out_ptr0'], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 2, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 71680}, 'backend_hash': '25ED88F5935B940EC1927250A0CAECF41F6A0D2252E814102945959BFC20A347', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__unsafe_view_mul_silu_6(in_out_ptr0, in_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 8960
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x0 = xindex
    tmp0 = tl.load(in_out_ptr0 + (x0), xmask).to(tl.float32)
    tmp8 = tl.load(in_ptr0 + (x0), xmask).to(tl.float32)
    tmp1 = tmp0.to(tl.float32)
    tmp2 = -tmp1
    tmp3 = libdevice.exp(tmp2)
    tmp4 = tl.full([1], 1.0, tl.float32)
    tmp5 = tmp3 + tmp4
    tmp6 = (tmp1 / tmp5)
    tmp7 = tmp6.to(tl.float32)
    tmp9 = tmp7 * tmp8
    tl.store(in_out_ptr0 + (x0), tmp9, xmask)
''', device_str='cuda')


# kernel path: /home/hpuvvad/csc548-w4a16-e014-c4-20261108/cache/inductor/cf/ccfhxxar43wg5f364fcffbffvipiarzdp44ugyrbeyecgudy4epx.py
# Topologically Sorted Source Nodes: [inputs_embeds, attn_output_3, hidden_states_5, down_proj, hidden_states_9, hidden_states_10, pow_3, variance_2, add_6, rsqrt_2, hidden_states_11, to_8, hidden_states_12], Original ATen: [aten.embedding, aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   add_6 => add_7
#   attn_output_3 => view_18
#   down_proj => view_24
#   hidden_states_10 => convert_element_type_26
#   hidden_states_11 => mul_12
#   hidden_states_12 => mul_13
#   hidden_states_5 => add_3
#   hidden_states_9 => add_6
#   inputs_embeds => embedding
#   pow_3 => pow_3
#   rsqrt_2 => rsqrt_2
#   to_8 => convert_element_type_27
#   variance_2 => mean_2
# Graph fragment:
#   %arg1_1 : Tensor "i64[1, 1][1, 1]cuda:0" = PlaceHolder[target=arg1_1]
#   %arg2_1 : Tensor "f16[151936, 1536][1536, 1]cuda:0" = PlaceHolder[target=arg2_1]
#   %mm : Tensor "f16[1, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm]
#   %mm_3 : Tensor "f16[1, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_3]
#   %arg19_1 : Tensor "f16[1536][1]cuda:0" = PlaceHolder[target=arg19_1]
#   %buf22 : Tensor "f32[1, 1, 1][1, 1, 1]cuda:0" = PlaceHolder[target=buf22]
#   %embedding : Tensor "f16[1, 1, 1536][1536, 1536, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.embedding.default](args = (%arg2_1, %arg1_1), kwargs = {})
#   %view_18 : Tensor "f16[1, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm, [1, 1, 1536]), kwargs = {})
#   %add_3 : Tensor "f16[1, 1, 1536][1536, 1536, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%embedding, %view_18), kwargs = {})
#   %view_24 : Tensor "f16[1, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_3, [1, 1, 1536]), kwargs = {})
#   %add_6 : Tensor "f16[1, 1, 1536][1536, 1536, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_3, %view_24), kwargs = {})
#   %convert_element_type_26 : Tensor "f32[1, 1, 1536][1536, 1536, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_6, torch.float32), kwargs = {})
#   %pow_3 : Tensor "f32[1, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_26, 2), kwargs = {})
#   %mean_2 : Tensor "f32[1, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_3, [-1], True), kwargs = {})
#   %add_7 : Tensor "f32[1, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_2, 1e-06), kwargs = {})
#   %rsqrt_2 : Tensor "f32[1, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_7,), kwargs = {})
#   %mul_12 : Tensor "f32[1, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_26, %rsqrt_2), kwargs = {})
#   %convert_element_type_27 : Tensor "f16[1, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_12, torch.float16), kwargs = {})
#   %mul_13 : Tensor "f16[1, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg19_1, %convert_element_type_27), kwargs = {})
#   return %buf22,%mul_13
triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_7 = async_compile.triton('triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_7', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 1, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i64', 'in_ptr1': '*fp16', 'in_ptr2': '*fp16', 'in_ptr3': '*fp16', 'in_ptr4': '*fp16', 'out_ptr1': '*fp16', 'xnumel': 'constexpr', 'r0_numel': 'i32', 'XBLOCK': 'constexpr', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=36, cc=120, major=12, regs_per_multiprocessor=65536, max_threads_per_multi_processor=1536, max_threads_per_block=1024, warp_size=32), 'constants': {'xnumel': 1}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_7', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 7, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'r0_': 15360}, 'backend_hash': '25ED88F5935B940EC1927250A0CAECF41F6A0D2252E814102945959BFC20A347', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_7(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, out_ptr1, xnumel, r0_numel, XBLOCK : tl.constexpr, R0_BLOCK : tl.constexpr):
    xnumel = 1
    r0_numel = 1536
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = tl.full([XBLOCK], True, tl.int1)[:, None]
    r0_base = tl.arange(0, R0_BLOCK)[None, :]
    rbase = r0_base
    tmp0 = tl.load(in_ptr0 + (0))
    tmp1 = tl.broadcast_to(tmp0, [1, 1])
    _tmp11 = tl.full([XBLOCK, R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp4 = tl.load(in_ptr2 + (r0_0), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp6 = tl.load(in_ptr3 + (r0_0), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tl.device_assert((0 <= tmp1) & (tmp1 < 151936), "index out of bounds: 0 <= tmp1 < 151936")
        tmp3 = tl.load(in_ptr1 + (r0_0 + 1536*tmp1), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp5 = tmp3 + tmp4
        tmp7 = tmp5 + tmp6
        tmp8 = tmp7.to(tl.float32)
        tmp9 = tmp8 * tmp8
        tmp10 = tl.broadcast_to(tmp9, [XBLOCK, R0_BLOCK])
        tmp12 = _tmp11 + tmp10
        _tmp11 = tl.where(r0_mask, tmp12, _tmp11)
    tmp11 = tl.sum(_tmp11, 1)[:, None]
    tmp14 = tl.load(in_ptr0 + (0))
    tmp15 = tl.broadcast_to(tmp14, [1, 1])
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp13 = tl.load(in_ptr4 + (r0_0), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp18 = tl.load(in_ptr2 + (r0_0), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp20 = tl.load(in_ptr3 + (r0_0), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tl.device_assert((0 <= tmp15) & (tmp15 < 151936), "index out of bounds: 0 <= tmp15 < 151936")
        tmp17 = tl.load(in_ptr1 + (r0_0 + 1536*tmp15), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp19 = tmp17 + tmp18
        tmp21 = tmp19 + tmp20
        tmp22 = tmp21.to(tl.float32)
        tmp23 = tl.full([1, 1], 1536.0, tl.float32)
        tmp24 = (tmp11 / tmp23)
        tmp25 = tl.full([1, 1], 1e-06, tl.float32)
        tmp26 = tmp24 + tmp25
        tmp27 = libdevice.rsqrt(tmp26)
        tmp28 = tmp22 * tmp27
        tmp29 = tmp28.to(tl.float32)
        tmp30 = tmp13 * tmp29
        tl.store(out_ptr1 + (tl.broadcast_to(r0_0, [XBLOCK, R0_BLOCK])), tmp30, r0_mask)
''', device_str='cuda')


# kernel path: /home/hpuvvad/csc548-w4a16-e014-c4-20261108/cache/inductor/kl/ckl5i5pwdgty3nzivd5vbxwnp4znilbj7lt6jpsb3sjnvdnt6dye.py
# Topologically Sorted Source Nodes: [inputs_embeds, attn_output_3, hidden_states_5, down_proj, hidden_states_9, attn_output_7, hidden_states_15, hidden_states_16, pow_4, variance_3, add_10, rsqrt_3, hidden_states_17, to_10, hidden_states_18], Original ATen: [aten.embedding, aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   add_10 => add_11
#   attn_output_3 => view_18
#   attn_output_7 => view_38
#   down_proj => view_24
#   hidden_states_15 => add_10
#   hidden_states_16 => convert_element_type_39
#   hidden_states_17 => mul_18
#   hidden_states_18 => mul_19
#   hidden_states_5 => add_3
#   hidden_states_9 => add_6
#   inputs_embeds => embedding
#   pow_4 => pow_4
#   rsqrt_3 => rsqrt_3
#   to_10 => convert_element_type_40
#   variance_3 => mean_3
# Graph fragment:
#   %arg1_1 : Tensor "i64[1, 1][1, 1]cuda:0" = PlaceHolder[target=arg1_1]
#   %arg2_1 : Tensor "f16[151936, 1536][1536, 1]cuda:0" = PlaceHolder[target=arg2_1]
#   %mm : Tensor "f16[1, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm]
#   %mm_3 : Tensor "f16[1, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_3]
#   %mm_4 : Tensor "f16[1, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_4]
#   %add_10 : Tensor "f16[1, 1, 1536][1536, 1536, 1]cuda:0" = PlaceHolder[target=add_10]
#   %arg29_1 : Tensor "f16[1536][1]cuda:0" = PlaceHolder[target=arg29_1]
#   %buf39 : Tensor "f32[1, 1, 1][1, 1, 1]cuda:0" = PlaceHolder[target=buf39]
#   %embedding : Tensor "f16[1, 1, 1536][1536, 1536, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.embedding.default](args = (%arg2_1, %arg1_1), kwargs = {})
#   %view_18 : Tensor "f16[1, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm, [1, 1, 1536]), kwargs = {})
#   %add_3 : Tensor "f16[1, 1, 1536][1536, 1536, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%embedding, %view_18), kwargs = {})
#   %view_24 : Tensor "f16[1, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_3, [1, 1, 1536]), kwargs = {})
#   %add_6 : Tensor "f16[1, 1, 1536][1536, 1536, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_3, %view_24), kwargs = {})
#   %view_38 : Tensor "f16[1, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_4, [1, 1, 1536]), kwargs = {})
#   %add_10 : Tensor "f16[1, 1, 1536][1536, 1536, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_6, %view_38), kwargs = {})
#   %convert_element_type_39 : Tensor "f32[1, 1, 1536][1536, 1536, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_10, torch.float32), kwargs = {})
#   %pow_4 : Tensor "f32[1, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_39, 2), kwargs = {})
#   %mean_3 : Tensor "f32[1, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_4, [-1], True), kwargs = {})
#   %add_11 : Tensor "f32[1, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_3, 1e-06), kwargs = {})
#   %rsqrt_3 : Tensor "f32[1, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_11,), kwargs = {})
#   %mul_18 : Tensor "f32[1, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_39, %rsqrt_3), kwargs = {})
#   %convert_element_type_40 : Tensor "f16[1, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_18, torch.float16), kwargs = {})
#   %mul_19 : Tensor "f16[1, 1, 1536][1536, 1536, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg29_1, %convert_element_type_40), kwargs = {})
#   return %add_10,%buf39,%mul_19
triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_8 = async_compile.triton('triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_8', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 1, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_out_ptr0': '*fp16', 'in_ptr0': '*i64', 'in_ptr1': '*fp16', 'in_ptr2': '*fp16', 'in_ptr3': '*fp16', 'in_ptr4': '*fp16', 'out_ptr1': '*fp16', 'xnumel': 'constexpr', 'r0_numel': 'i32', 'XBLOCK': 'constexpr', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=36, cc=120, major=12, regs_per_multiprocessor=65536, max_threads_per_multi_processor=1536, max_threads_per_block=1024, warp_size=32), 'constants': {'xnumel': 1}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]], (8,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_8', 'mutated_arg_names': ['in_out_ptr0'], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 6, 'num_store': 2, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'r0_': 24576}, 'backend_hash': '25ED88F5935B940EC1927250A0CAECF41F6A0D2252E814102945959BFC20A347', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_8(in_out_ptr0, in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, out_ptr1, xnumel, r0_numel, XBLOCK : tl.constexpr, R0_BLOCK : tl.constexpr):
    xnumel = 1
    r0_numel = 1536
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = tl.full([XBLOCK], True, tl.int1)[:, None]
    r0_base = tl.arange(0, R0_BLOCK)[None, :]
    rbase = r0_base
    tmp0 = tl.load(in_ptr0 + (0))
    tmp1 = tl.broadcast_to(tmp0, [1, 1])
    _tmp13 = tl.full([XBLOCK, R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp4 = tl.load(in_out_ptr0 + (r0_0), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp6 = tl.load(in_ptr2 + (r0_0), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp8 = tl.load(in_ptr3 + (r0_0), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tl.device_assert((0 <= tmp1) & (tmp1 < 151936), "index out of bounds: 0 <= tmp1 < 151936")
        tmp3 = tl.load(in_ptr1 + (r0_0 + 1536*tmp1), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp5 = tmp3 + tmp4
        tmp7 = tmp5 + tmp6
        tmp9 = tmp7 + tmp8
        tmp10 = tmp9.to(tl.float32)
        tmp11 = tmp10 * tmp10
        tmp12 = tl.broadcast_to(tmp11, [XBLOCK, R0_BLOCK])
        tmp14 = _tmp13 + tmp12
        _tmp13 = tl.where(r0_mask, tmp14, _tmp13)
        tl.store(in_out_ptr0 + (tl.broadcast_to(r0_0, [XBLOCK, R0_BLOCK])), tmp9, r0_mask)
    tmp13 = tl.sum(_tmp13, 1)[:, None]
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp15 = tl.load(in_ptr4 + (r0_0), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tl.debug_barrier()
        tmp16 = tl.load(in_out_ptr0 + (r0_0), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp17 = tmp16.to(tl.float32)
        tmp18 = tl.full([1, 1], 1536.0, tl.float32)
        tmp19 = (tmp13 / tmp18)
        tmp20 = tl.full([1, 1], 1e-06, tl.float32)
        tmp21 = tmp19 + tmp20
        tmp22 = libdevice.rsqrt(tmp21)
        tmp23 = tmp17 * tmp22
        tmp24 = tmp23.to(tl.float32)
        tmp25 = tmp15 * tmp24
        tl.store(out_ptr1 + (tl.broadcast_to(r0_0, [XBLOCK, R0_BLOCK])), tmp25, r0_mask)
''', device_str='cuda')


# kernel path: /home/hpuvvad/csc548-w4a16-e014-c4-20261108/cache/inductor/ge/cgejb4dtrrn6r7lr6d7ubiwookj7jfgpmndyqnlpkdpiw6zx4bzn.py
# Topologically Sorted Source Nodes: [down_proj_1, hidden_states_19, hidden_states_20, pow_5, variance_4, add_12, rsqrt_4, hidden_states_21, to_12, hidden_states_22], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   add_12 => add_14
#   down_proj_1 => view_44
#   hidden_states_19 => add_13
#   hidden_states_20 => convert_element_type_49
#   hidden_states_21 => mul_21
#   hidden_states_22 => mul_22
#   pow_5 => pow_5
#   rsqrt_4 => rsqrt_4
#   to_12 => convert_element_type_50
#   variance_4 => mean_4
# Graph fragment:
#   %add_10 : Tensor "f16[1, 1, 1536][1536, 1536, 1]cuda:0" = PlaceHolder[target=add_10]
#   %mm_7 : Tensor "f16[1, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_7]
#   %arg33_1 : Tensor "f16[1536][1]cuda:0" = PlaceHolder[target=arg33_1]
#   %buf45 : Tensor "f32[1, 1, 1][1, 1, 1]cuda:0" = PlaceHolder[target=buf45]
#   %view_44 : Tensor "f16[1, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_7, [1, 1, 1536]), kwargs = {})
#   %add_13 : Tensor "f16[1, 1, 1536][1536, 1536, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_10, %view_44), kwargs = {})
#   %convert_element_type_49 : Tensor "f32[1, 1, 1536][1536, 1536, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_13, torch.float32), kwargs = {})
#   %pow_5 : Tensor "f32[1, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_49, 2), kwargs = {})
#   %mean_4 : Tensor "f32[1, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_5, [-1], True), kwargs = {})
#   %add_14 : Tensor "f32[1, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_4, 1e-06), kwargs = {})
#   %rsqrt_4 : Tensor "f32[1, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_14,), kwargs = {})
#   %mul_21 : Tensor "f32[1, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_49, %rsqrt_4), kwargs = {})
#   %convert_element_type_50 : Tensor "f16[1, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_21, torch.float16), kwargs = {})
#   %mul_22 : Tensor "f16[1, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg33_1, %convert_element_type_50), kwargs = {})
#   return %buf45,%mul_22
triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_9 = async_compile.triton('triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_9', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 1, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp16', 'in_ptr1': '*fp16', 'in_ptr2': '*fp16', 'out_ptr1': '*fp16', 'xnumel': 'constexpr', 'r0_numel': 'i32', 'XBLOCK': 'constexpr', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=36, cc=120, major=12, regs_per_multiprocessor=65536, max_threads_per_multi_processor=1536, max_threads_per_block=1024, warp_size=32), 'constants': {'xnumel': 1}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_9', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 5, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'r0_': 15360}, 'backend_hash': '25ED88F5935B940EC1927250A0CAECF41F6A0D2252E814102945959BFC20A347', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_9(in_ptr0, in_ptr1, in_ptr2, out_ptr1, xnumel, r0_numel, XBLOCK : tl.constexpr, R0_BLOCK : tl.constexpr):
    xnumel = 1
    r0_numel = 1536
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = tl.full([XBLOCK], True, tl.int1)[:, None]
    r0_base = tl.arange(0, R0_BLOCK)[None, :]
    rbase = r0_base
    _tmp6 = tl.full([XBLOCK, R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp0 = tl.load(in_ptr0 + (r0_0), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp1 = tl.load(in_ptr1 + (r0_0), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp2 = tmp0 + tmp1
        tmp3 = tmp2.to(tl.float32)
        tmp4 = tmp3 * tmp3
        tmp5 = tl.broadcast_to(tmp4, [XBLOCK, R0_BLOCK])
        tmp7 = _tmp6 + tmp5
        _tmp6 = tl.where(r0_mask, tmp7, _tmp6)
    tmp6 = tl.sum(_tmp6, 1)[:, None]
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp8 = tl.load(in_ptr2 + (r0_0), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp9 = tl.load(in_ptr0 + (r0_0), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp10 = tl.load(in_ptr1 + (r0_0), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp11 = tmp9 + tmp10
        tmp12 = tmp11.to(tl.float32)
        tmp13 = tl.full([1, 1], 1536.0, tl.float32)
        tmp14 = (tmp6 / tmp13)
        tmp15 = tl.full([1, 1], 1e-06, tl.float32)
        tmp16 = tmp14 + tmp15
        tmp17 = libdevice.rsqrt(tmp16)
        tmp18 = tmp12 * tmp17
        tmp19 = tmp18.to(tl.float32)
        tmp20 = tmp8 * tmp19
        tl.store(out_ptr1 + (tl.broadcast_to(r0_0, [XBLOCK, R0_BLOCK])), tmp20, r0_mask)
''', device_str='cuda')


# kernel path: /home/hpuvvad/csc548-w4a16-e014-c4-20261108/cache/inductor/oo/cootgxuvlehs4gu5vjiudjup2xwtiidthl3soy3a6kv7v6ab43ig.py
# Topologically Sorted Source Nodes: [down_proj_1, hidden_states_19, attn_output_11, hidden_states_25, hidden_states_26, pow_6, variance_5, add_16, rsqrt_5, hidden_states_27, to_14, hidden_states_28], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   add_16 => add_18
#   attn_output_11 => view_58
#   down_proj_1 => view_44
#   hidden_states_19 => add_13
#   hidden_states_25 => add_17
#   hidden_states_26 => convert_element_type_62
#   hidden_states_27 => mul_27
#   hidden_states_28 => mul_28
#   pow_6 => pow_6
#   rsqrt_5 => rsqrt_5
#   to_14 => convert_element_type_63
#   variance_5 => mean_5
# Graph fragment:
#   %add_10 : Tensor "f16[1, 1, 1536][1536, 1536, 1]cuda:0" = PlaceHolder[target=add_10]
#   %mm_7 : Tensor "f16[1, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_7]
#   %mm_8 : Tensor "f16[1, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_8]
#   %arg43_1 : Tensor "f16[1536][1]cuda:0" = PlaceHolder[target=arg43_1]
#   %buf61 : Tensor "f32[1, 1, 1][1, 1, 1]cuda:0" = PlaceHolder[target=buf61]
#   %view_44 : Tensor "f16[1, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_7, [1, 1, 1536]), kwargs = {})
#   %add_13 : Tensor "f16[1, 1, 1536][1536, 1536, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_10, %view_44), kwargs = {})
#   %view_58 : Tensor "f16[1, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_8, [1, 1, 1536]), kwargs = {})
#   %add_17 : Tensor "f16[1, 1, 1536][1536, 1536, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_13, %view_58), kwargs = {})
#   %convert_element_type_62 : Tensor "f32[1, 1, 1536][1536, 1536, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_17, torch.float32), kwargs = {})
#   %pow_6 : Tensor "f32[1, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_62, 2), kwargs = {})
#   %mean_5 : Tensor "f32[1, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_6, [-1], True), kwargs = {})
#   %add_18 : Tensor "f32[1, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_5, 1e-06), kwargs = {})
#   %rsqrt_5 : Tensor "f32[1, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_18,), kwargs = {})
#   %mul_27 : Tensor "f32[1, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_62, %rsqrt_5), kwargs = {})
#   %convert_element_type_63 : Tensor "f16[1, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_27, torch.float16), kwargs = {})
#   %mul_28 : Tensor "f16[1, 1, 1536][1536, 1536, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg43_1, %convert_element_type_63), kwargs = {})
#   return %buf61,%mul_28
triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_10 = async_compile.triton('triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_10', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 1, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp16', 'in_ptr1': '*fp16', 'in_ptr2': '*fp16', 'in_ptr3': '*fp16', 'out_ptr1': '*fp16', 'xnumel': 'constexpr', 'r0_numel': 'i32', 'XBLOCK': 'constexpr', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=36, cc=120, major=12, regs_per_multiprocessor=65536, max_threads_per_multi_processor=1536, max_threads_per_block=1024, warp_size=32), 'constants': {'xnumel': 1}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_10', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 7, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'r0_': 18432}, 'backend_hash': '25ED88F5935B940EC1927250A0CAECF41F6A0D2252E814102945959BFC20A347', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_10(in_ptr0, in_ptr1, in_ptr2, in_ptr3, out_ptr1, xnumel, r0_numel, XBLOCK : tl.constexpr, R0_BLOCK : tl.constexpr):
    xnumel = 1
    r0_numel = 1536
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = tl.full([XBLOCK], True, tl.int1)[:, None]
    r0_base = tl.arange(0, R0_BLOCK)[None, :]
    rbase = r0_base
    _tmp8 = tl.full([XBLOCK, R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp0 = tl.load(in_ptr0 + (r0_0), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp1 = tl.load(in_ptr1 + (r0_0), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp3 = tl.load(in_ptr2 + (r0_0), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp2 = tmp0 + tmp1
        tmp4 = tmp2 + tmp3
        tmp5 = tmp4.to(tl.float32)
        tmp6 = tmp5 * tmp5
        tmp7 = tl.broadcast_to(tmp6, [XBLOCK, R0_BLOCK])
        tmp9 = _tmp8 + tmp7
        _tmp8 = tl.where(r0_mask, tmp9, _tmp8)
    tmp8 = tl.sum(_tmp8, 1)[:, None]
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp10 = tl.load(in_ptr3 + (r0_0), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp11 = tl.load(in_ptr0 + (r0_0), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp12 = tl.load(in_ptr1 + (r0_0), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp14 = tl.load(in_ptr2 + (r0_0), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp13 = tmp11 + tmp12
        tmp15 = tmp13 + tmp14
        tmp16 = tmp15.to(tl.float32)
        tmp17 = tl.full([1, 1], 1536.0, tl.float32)
        tmp18 = (tmp8 / tmp17)
        tmp19 = tl.full([1, 1], 1e-06, tl.float32)
        tmp20 = tmp18 + tmp19
        tmp21 = libdevice.rsqrt(tmp20)
        tmp22 = tmp16 * tmp21
        tmp23 = tmp22.to(tl.float32)
        tmp24 = tmp10 * tmp23
        tl.store(out_ptr1 + (tl.broadcast_to(r0_0, [XBLOCK, R0_BLOCK])), tmp24, r0_mask)
''', device_str='cuda')


# kernel path: /home/hpuvvad/csc548-w4a16-e014-c4-20261108/cache/inductor/jq/cjqw3cuneddu7gyvu5ngmhvzkt2jodttegrag27uidua5nln5wpp.py
# Topologically Sorted Source Nodes: [down_proj_1, hidden_states_19, attn_output_11, hidden_states_25, down_proj_2, hidden_states_29, hidden_states_30, pow_7, variance_6, add_18, rsqrt_6, hidden_states_31, to_16, hidden_states_32], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   add_18 => add_21
#   attn_output_11 => view_58
#   down_proj_1 => view_44
#   down_proj_2 => view_64
#   hidden_states_19 => add_13
#   hidden_states_25 => add_17
#   hidden_states_29 => add_20
#   hidden_states_30 => convert_element_type_72
#   hidden_states_31 => mul_30
#   hidden_states_32 => mul_31
#   pow_7 => pow_7
#   rsqrt_6 => rsqrt_6
#   to_16 => convert_element_type_73
#   variance_6 => mean_6
# Graph fragment:
#   %add_10 : Tensor "f16[1, 1, 1536][1536, 1536, 1]cuda:0" = PlaceHolder[target=add_10]
#   %mm_7 : Tensor "f16[1, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_7]
#   %mm_8 : Tensor "f16[1, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_8]
#   %mm_11 : Tensor "f16[1, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_11]
#   %arg47_1 : Tensor "f16[1536][1]cuda:0" = PlaceHolder[target=arg47_1]
#   %buf67 : Tensor "f32[1, 1, 1][1, 1, 1]cuda:0" = PlaceHolder[target=buf67]
#   %view_44 : Tensor "f16[1, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_7, [1, 1, 1536]), kwargs = {})
#   %add_13 : Tensor "f16[1, 1, 1536][1536, 1536, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_10, %view_44), kwargs = {})
#   %view_58 : Tensor "f16[1, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_8, [1, 1, 1536]), kwargs = {})
#   %add_17 : Tensor "f16[1, 1, 1536][1536, 1536, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_13, %view_58), kwargs = {})
#   %view_64 : Tensor "f16[1, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_11, [1, 1, 1536]), kwargs = {})
#   %add_20 : Tensor "f16[1, 1, 1536][1536, 1536, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_17, %view_64), kwargs = {})
#   %convert_element_type_72 : Tensor "f32[1, 1, 1536][1536, 1536, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_20, torch.float32), kwargs = {})
#   %pow_7 : Tensor "f32[1, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_72, 2), kwargs = {})
#   %mean_6 : Tensor "f32[1, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_7, [-1], True), kwargs = {})
#   %add_21 : Tensor "f32[1, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_6, 1e-06), kwargs = {})
#   %rsqrt_6 : Tensor "f32[1, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_21,), kwargs = {})
#   %mul_30 : Tensor "f32[1, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_72, %rsqrt_6), kwargs = {})
#   %convert_element_type_73 : Tensor "f16[1, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_30, torch.float16), kwargs = {})
#   %mul_31 : Tensor "f16[1, 1, 1536][1536, 1536, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg47_1, %convert_element_type_73), kwargs = {})
#   return %buf67,%mul_31
triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_11 = async_compile.triton('triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_11', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 1, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp16', 'in_ptr1': '*fp16', 'in_ptr2': '*fp16', 'in_ptr3': '*fp16', 'in_ptr4': '*fp16', 'out_ptr1': '*fp16', 'xnumel': 'constexpr', 'r0_numel': 'i32', 'XBLOCK': 'constexpr', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=36, cc=120, major=12, regs_per_multiprocessor=65536, max_threads_per_multi_processor=1536, max_threads_per_block=1024, warp_size=32), 'constants': {'xnumel': 1}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_11', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 9, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'r0_': 21504}, 'backend_hash': '25ED88F5935B940EC1927250A0CAECF41F6A0D2252E814102945959BFC20A347', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_11(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, out_ptr1, xnumel, r0_numel, XBLOCK : tl.constexpr, R0_BLOCK : tl.constexpr):
    xnumel = 1
    r0_numel = 1536
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = tl.full([XBLOCK], True, tl.int1)[:, None]
    r0_base = tl.arange(0, R0_BLOCK)[None, :]
    rbase = r0_base
    _tmp10 = tl.full([XBLOCK, R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp0 = tl.load(in_ptr0 + (r0_0), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp1 = tl.load(in_ptr1 + (r0_0), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp3 = tl.load(in_ptr2 + (r0_0), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp5 = tl.load(in_ptr3 + (r0_0), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp2 = tmp0 + tmp1
        tmp4 = tmp2 + tmp3
        tmp6 = tmp4 + tmp5
        tmp7 = tmp6.to(tl.float32)
        tmp8 = tmp7 * tmp7
        tmp9 = tl.broadcast_to(tmp8, [XBLOCK, R0_BLOCK])
        tmp11 = _tmp10 + tmp9
        _tmp10 = tl.where(r0_mask, tmp11, _tmp10)
    tmp10 = tl.sum(_tmp10, 1)[:, None]
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp12 = tl.load(in_ptr4 + (r0_0), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp13 = tl.load(in_ptr0 + (r0_0), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp14 = tl.load(in_ptr1 + (r0_0), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp16 = tl.load(in_ptr2 + (r0_0), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp18 = tl.load(in_ptr3 + (r0_0), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp15 = tmp13 + tmp14
        tmp17 = tmp15 + tmp16
        tmp19 = tmp17 + tmp18
        tmp20 = tmp19.to(tl.float32)
        tmp21 = tl.full([1, 1], 1536.0, tl.float32)
        tmp22 = (tmp10 / tmp21)
        tmp23 = tl.full([1, 1], 1e-06, tl.float32)
        tmp24 = tmp22 + tmp23
        tmp25 = libdevice.rsqrt(tmp24)
        tmp26 = tmp20 * tmp25
        tmp27 = tmp26.to(tl.float32)
        tmp28 = tmp12 * tmp27
        tl.store(out_ptr1 + (tl.broadcast_to(r0_0, [XBLOCK, R0_BLOCK])), tmp28, r0_mask)
''', device_str='cuda')


# kernel path: /home/hpuvvad/csc548-w4a16-e014-c4-20261108/cache/inductor/hq/chqb6bwye5auqbi4mxvc6nf7urc4o57kcwnkcosyfqvx6nnvyp7e.py
# Topologically Sorted Source Nodes: [down_proj_1, hidden_states_19, attn_output_11, hidden_states_25, down_proj_2, hidden_states_29, attn_output_15, hidden_states_35, hidden_states_36, pow_8, variance_7, add_22, rsqrt_7, hidden_states_37, to_18, hidden_states_38], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   add_22 => add_25
#   attn_output_11 => view_58
#   attn_output_15 => view_78
#   down_proj_1 => view_44
#   down_proj_2 => view_64
#   hidden_states_19 => add_13
#   hidden_states_25 => add_17
#   hidden_states_29 => add_20
#   hidden_states_35 => add_24
#   hidden_states_36 => convert_element_type_85
#   hidden_states_37 => mul_36
#   hidden_states_38 => mul_37
#   pow_8 => pow_8
#   rsqrt_7 => rsqrt_7
#   to_18 => convert_element_type_86
#   variance_7 => mean_7
# Graph fragment:
#   %add_10 : Tensor "f16[1, 1, 1536][1536, 1536, 1]cuda:0" = PlaceHolder[target=add_10]
#   %mm_7 : Tensor "f16[1, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_7]
#   %mm_8 : Tensor "f16[1, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_8]
#   %mm_11 : Tensor "f16[1, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_11]
#   %mm_12 : Tensor "f16[1, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_12]
#   %add_24 : Tensor "f16[1, 1, 1536][1536, 1536, 1]cuda:0" = PlaceHolder[target=add_24]
#   %arg57_1 : Tensor "f16[1536][1]cuda:0" = PlaceHolder[target=arg57_1]
#   %buf84 : Tensor "f32[1, 1, 1][1, 1, 1]cuda:0" = PlaceHolder[target=buf84]
#   %view_44 : Tensor "f16[1, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_7, [1, 1, 1536]), kwargs = {})
#   %add_13 : Tensor "f16[1, 1, 1536][1536, 1536, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_10, %view_44), kwargs = {})
#   %view_58 : Tensor "f16[1, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_8, [1, 1, 1536]), kwargs = {})
#   %add_17 : Tensor "f16[1, 1, 1536][1536, 1536, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_13, %view_58), kwargs = {})
#   %view_64 : Tensor "f16[1, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_11, [1, 1, 1536]), kwargs = {})
#   %add_20 : Tensor "f16[1, 1, 1536][1536, 1536, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_17, %view_64), kwargs = {})
#   %view_78 : Tensor "f16[1, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_12, [1, 1, 1536]), kwargs = {})
#   %add_24 : Tensor "f16[1, 1, 1536][1536, 1536, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_20, %view_78), kwargs = {})
#   %convert_element_type_85 : Tensor "f32[1, 1, 1536][1536, 1536, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_24, torch.float32), kwargs = {})
#   %pow_8 : Tensor "f32[1, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_85, 2), kwargs = {})
#   %mean_7 : Tensor "f32[1, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_8, [-1], True), kwargs = {})
#   %add_25 : Tensor "f32[1, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_7, 1e-06), kwargs = {})
#   %rsqrt_7 : Tensor "f32[1, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_25,), kwargs = {})
#   %mul_36 : Tensor "f32[1, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_85, %rsqrt_7), kwargs = {})
#   %convert_element_type_86 : Tensor "f16[1, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_36, torch.float16), kwargs = {})
#   %mul_37 : Tensor "f16[1, 1, 1536][1536, 1536, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg57_1, %convert_element_type_86), kwargs = {})
#   return %add_24,%buf84,%mul_37
triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_12 = async_compile.triton('triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_12', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 1, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_out_ptr0': '*fp16', 'in_ptr0': '*fp16', 'in_ptr1': '*fp16', 'in_ptr2': '*fp16', 'in_ptr3': '*fp16', 'in_ptr4': '*fp16', 'out_ptr1': '*fp16', 'xnumel': 'constexpr', 'r0_numel': 'i32', 'XBLOCK': 'constexpr', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=36, cc=120, major=12, regs_per_multiprocessor=65536, max_threads_per_multi_processor=1536, max_threads_per_block=1024, warp_size=32), 'constants': {'xnumel': 1}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]], (8,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_12', 'mutated_arg_names': ['in_out_ptr0'], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 7, 'num_store': 2, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'r0_': 30720}, 'backend_hash': '25ED88F5935B940EC1927250A0CAECF41F6A0D2252E814102945959BFC20A347', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_12(in_out_ptr0, in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, out_ptr1, xnumel, r0_numel, XBLOCK : tl.constexpr, R0_BLOCK : tl.constexpr):
    xnumel = 1
    r0_numel = 1536
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = tl.full([XBLOCK], True, tl.int1)[:, None]
    r0_base = tl.arange(0, R0_BLOCK)[None, :]
    rbase = r0_base
    _tmp12 = tl.full([XBLOCK, R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp0 = tl.load(in_out_ptr0 + (r0_0), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp1 = tl.load(in_ptr0 + (r0_0), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp3 = tl.load(in_ptr1 + (r0_0), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp5 = tl.load(in_ptr2 + (r0_0), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp7 = tl.load(in_ptr3 + (r0_0), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp2 = tmp0 + tmp1
        tmp4 = tmp2 + tmp3
        tmp6 = tmp4 + tmp5
        tmp8 = tmp6 + tmp7
        tmp9 = tmp8.to(tl.float32)
        tmp10 = tmp9 * tmp9
        tmp11 = tl.broadcast_to(tmp10, [XBLOCK, R0_BLOCK])
        tmp13 = _tmp12 + tmp11
        _tmp12 = tl.where(r0_mask, tmp13, _tmp12)
        tl.store(in_out_ptr0 + (tl.broadcast_to(r0_0, [XBLOCK, R0_BLOCK])), tmp8, r0_mask)
    tmp12 = tl.sum(_tmp12, 1)[:, None]
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp14 = tl.load(in_ptr4 + (r0_0), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tl.debug_barrier()
        tmp15 = tl.load(in_out_ptr0 + (r0_0), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp16 = tmp15.to(tl.float32)
        tmp17 = tl.full([1, 1], 1536.0, tl.float32)
        tmp18 = (tmp12 / tmp17)
        tmp19 = tl.full([1, 1], 1e-06, tl.float32)
        tmp20 = tmp18 + tmp19
        tmp21 = libdevice.rsqrt(tmp20)
        tmp22 = tmp16 * tmp21
        tmp23 = tmp22.to(tl.float32)
        tmp24 = tmp14 * tmp23
        tl.store(out_ptr1 + (tl.broadcast_to(r0_0, [XBLOCK, R0_BLOCK])), tmp24, r0_mask)
''', device_str='cuda')


# kernel path: /home/hpuvvad/csc548-w4a16-e014-c4-20261108/cache/inductor/cq/ccqr2vrn2iq333xn2zchsiv7j4pdvxuavadlexurzux3rf6z2uta.py
# Topologically Sorted Source Nodes: [down_proj_27, hidden_states_279, hidden_states_280, pow_57, variance_56, add_168, rsqrt_56, hidden_states_281, to_116, hidden_states_282], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   add_168 => add_196
#   down_proj_27 => view_564
#   hidden_states_279 => add_195
#   hidden_states_280 => convert_element_type_647
#   hidden_states_281 => mul_255
#   hidden_states_282 => mul_256
#   pow_57 => pow_57
#   rsqrt_56 => rsqrt_56
#   to_116 => convert_element_type_648
#   variance_56 => mean_56
# Graph fragment:
#   %add_192 : Tensor "f16[1, 1, 1536][1536, 1536, 1]cuda:0" = PlaceHolder[target=add_192]
#   %mm_111 : Tensor "f16[1, 1536][1536, 1]cuda:0" = PlaceHolder[target=mm_111]
#   %arg397_1 : Tensor "f16[1536][1]cuda:0" = PlaceHolder[target=arg397_1]
#   %buf630 : Tensor "f32[1, 1, 1][1, 1, 1]cuda:0" = PlaceHolder[target=buf630]
#   %view_564 : Tensor "f16[1, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_111, [1, 1, 1536]), kwargs = {})
#   %add_195 : Tensor "f16[1, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_192, %view_564), kwargs = {})
#   %convert_element_type_647 : Tensor "f32[1, 1, 1536][1536, 1536, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_195, torch.float32), kwargs = {})
#   %pow_57 : Tensor "f32[1, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_647, 2), kwargs = {})
#   %mean_56 : Tensor "f32[1, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_57, [-1], True), kwargs = {})
#   %add_196 : Tensor "f32[1, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_56, 1e-06), kwargs = {})
#   %rsqrt_56 : Tensor "f32[1, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_196,), kwargs = {})
#   %mul_255 : Tensor "f32[1, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_647, %rsqrt_56), kwargs = {})
#   %convert_element_type_648 : Tensor "f16[1, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_255, torch.float16), kwargs = {})
#   %mul_256 : Tensor "f16[1, 1, 1536][1536, 1536, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%arg397_1, %convert_element_type_648), kwargs = {})
#   return %buf630,%mul_256
triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_13 = async_compile.triton('triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_13', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 1, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_out_ptr0': '*fp16', 'in_ptr0': '*fp16', 'in_ptr1': '*fp16', 'xnumel': 'constexpr', 'r0_numel': 'i32', 'XBLOCK': 'constexpr', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=36, cc=120, major=12, regs_per_multiprocessor=65536, max_threads_per_multi_processor=1536, max_threads_per_block=1024, warp_size=32), 'constants': {'xnumel': 1}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_13', 'mutated_arg_names': ['in_out_ptr0'], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 5, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'r0_': 15360}, 'backend_hash': '25ED88F5935B940EC1927250A0CAECF41F6A0D2252E814102945959BFC20A347', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_13(in_out_ptr0, in_ptr0, in_ptr1, xnumel, r0_numel, XBLOCK : tl.constexpr, R0_BLOCK : tl.constexpr):
    xnumel = 1
    r0_numel = 1536
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = tl.full([XBLOCK], True, tl.int1)[:, None]
    r0_base = tl.arange(0, R0_BLOCK)[None, :]
    rbase = r0_base
    _tmp6 = tl.full([XBLOCK, R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp0 = tl.load(in_out_ptr0 + (r0_0), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp1 = tl.load(in_ptr0 + (r0_0), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp2 = tmp0 + tmp1
        tmp3 = tmp2.to(tl.float32)
        tmp4 = tmp3 * tmp3
        tmp5 = tl.broadcast_to(tmp4, [XBLOCK, R0_BLOCK])
        tmp7 = _tmp6 + tmp5
        _tmp6 = tl.where(r0_mask, tmp7, _tmp6)
    tmp6 = tl.sum(_tmp6, 1)[:, None]
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp8 = tl.load(in_ptr1 + (r0_0), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp9 = tl.load(in_out_ptr0 + (r0_0), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp10 = tl.load(in_ptr0 + (r0_0), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp11 = tmp9 + tmp10
        tmp12 = tmp11.to(tl.float32)
        tmp13 = tl.full([1, 1], 1536.0, tl.float32)
        tmp14 = (tmp6 / tmp13)
        tmp15 = tl.full([1, 1], 1e-06, tl.float32)
        tmp16 = tmp14 + tmp15
        tmp17 = libdevice.rsqrt(tmp16)
        tmp18 = tmp12 * tmp17
        tmp19 = tmp18.to(tl.float32)
        tmp20 = tmp8 * tmp19
        tl.store(in_out_ptr0 + (tl.broadcast_to(r0_0, [XBLOCK, R0_BLOCK])), tmp20, r0_mask)
''', device_str='cuda')


# kernel path: /home/hpuvvad/csc548-w4a16-e014-c4-20261108/cache/inductor/5f/c5fc3j5cwv52nlyhdubglf743y4xvgyhhqyduvnrhnsrqawptycr.py
# Topologically Sorted Source Nodes: [logits, logits_1, argmax], Original ATen: [aten._unsafe_view, aten.select, aten.argmax]
# Source node to ATen node mapping:
#   argmax => argmax
#   logits => view_566
#   logits_1 => select
# Graph fragment:
#   %mm_112 : Tensor "f16[1, 151936][151936, 1]cuda:0" = PlaceHolder[target=mm_112]
#   %view_566 : Tensor "f16[1, 1, 151936][151936, 151936, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%mm_112, [1, 1, 151936]), kwargs = {})
#   %select : Tensor "f16[1, 151936][151936, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.select.int](args = (%view_566, 1, 0), kwargs = {})
#   %argmax : Tensor "i64[1][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.argmax.default](args = (%select, -1), kwargs = {})
#   return %argmax
triton_red_fused__unsafe_view_argmax_select_14 = async_compile.triton('triton_red_fused__unsafe_view_argmax_select_14', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 1, 'r0_': 262144},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp16', 'out_ptr0': '*i64', 'xnumel': 'constexpr', 'r0_numel': 'i32', 'XBLOCK': 'constexpr', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=36, cc=120, major=12, regs_per_multiprocessor=65536, max_threads_per_multi_processor=1536, max_threads_per_block=1024, warp_size=32), 'constants': {'xnumel': 1}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__unsafe_view_argmax_select_14', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'r0_': 303872}, 'backend_hash': '25ED88F5935B940EC1927250A0CAECF41F6A0D2252E814102945959BFC20A347', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused__unsafe_view_argmax_select_14(in_ptr0, out_ptr0, xnumel, r0_numel, XBLOCK : tl.constexpr, R0_BLOCK : tl.constexpr):
    xnumel = 1
    r0_numel = 151936
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = tl.full([XBLOCK], True, tl.int1)[:, None]
    r0_base = tl.arange(0, R0_BLOCK)[None, :]
    rbase = r0_base
    _tmp2 = tl.full([XBLOCK, R0_BLOCK], float("-inf"), tl.float32)
    _tmp2_index = tl.full([XBLOCK, R0_BLOCK], 2147483647, tl.int32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp0 = tl.load(in_ptr0 + (r0_0), r0_mask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp1 = tl.broadcast_to(tmp0, [XBLOCK, R0_BLOCK])
        _tmp2_next, _tmp2_index_next = triton_helpers.maximum_with_index(
            _tmp2, _tmp2_index, tmp1, rindex
        )
        _tmp2 = tl.where(r0_mask, _tmp2_next, _tmp2)
        _tmp2_index = tl.where(r0_mask, _tmp2_index_next, _tmp2_index)
    tmp2_val, tmp2_idx = triton_helpers.max_with_index(_tmp2, _tmp2_index, 1)
    tmp2 = tmp2_idx[:, None]
    tl.store(out_ptr0 + (tl.full([1, 1], 0, tl.int32).broadcast_to(XBLOCK, 1)), tmp2, None)
''', device_str='cuda')

def partition_0(args):
    arg1_1, arg2_1, arg5_1, arg7_1, arg6_1, arg9_1, arg8_1, arg0_1, arg4_1, arg12_1, arg11_1, arg10_1, arg13_1, arg3_1, arg14_1, arg15_1, arg16_1, arg17_1, arg18_1, arg19_1, arg21_1, arg20_1, arg23_1, arg22_1, arg26_1, arg25_1, arg24_1, arg27_1, arg28_1, arg29_1, arg30_1, arg31_1, arg32_1, arg33_1, arg35_1, arg34_1, arg37_1, arg36_1, arg40_1, arg39_1, arg38_1, arg41_1, arg42_1, arg43_1, arg44_1, arg45_1, arg46_1, arg47_1, arg49_1, arg48_1, arg51_1, arg50_1, arg54_1, arg53_1, arg52_1, arg55_1, arg56_1, arg57_1, arg58_1, arg59_1, arg60_1, arg61_1, arg63_1, arg62_1, arg65_1, arg64_1, arg68_1, arg67_1, arg66_1, arg69_1, arg70_1, arg71_1, arg72_1, arg73_1, arg74_1, arg75_1, arg77_1, arg76_1, arg79_1, arg78_1, arg82_1, arg81_1, arg80_1, arg83_1, arg84_1, arg85_1, arg86_1, arg87_1, arg88_1, arg89_1, arg91_1, arg90_1, arg93_1, arg92_1, arg96_1, arg95_1, arg94_1, arg97_1, arg98_1, arg99_1, arg100_1, arg101_1, arg102_1, arg103_1, arg105_1, arg104_1, arg107_1, arg106_1, arg110_1, arg109_1, arg108_1, arg111_1, arg112_1, arg113_1, arg114_1, arg115_1, arg116_1, arg117_1, arg119_1, arg118_1, arg121_1, arg120_1, arg124_1, arg123_1, arg122_1, arg125_1, arg126_1, arg127_1, arg128_1, arg129_1, arg130_1, arg131_1, arg133_1, arg132_1, arg135_1, arg134_1, arg138_1, arg137_1, arg136_1, arg139_1, arg140_1, arg141_1, arg142_1, arg143_1, arg144_1, arg145_1, arg147_1, arg146_1, arg149_1, arg148_1, arg152_1, arg151_1, arg150_1, arg153_1, arg154_1, arg155_1, arg156_1, arg157_1, arg158_1, arg159_1, arg161_1, arg160_1, arg163_1, arg162_1, arg166_1, arg165_1, arg164_1, arg167_1, arg168_1, arg169_1, arg170_1, arg171_1, arg172_1, arg173_1, arg175_1, arg174_1, arg177_1, arg176_1, arg180_1, arg179_1, arg178_1, arg181_1, arg182_1, arg183_1, arg184_1, arg185_1, arg186_1, arg187_1, arg189_1, arg188_1, arg191_1, arg190_1, arg194_1, arg193_1, arg192_1, arg195_1, arg196_1, arg197_1, arg198_1, arg199_1, arg200_1, arg201_1, arg203_1, arg202_1, arg205_1, arg204_1, arg208_1, arg207_1, arg206_1, arg209_1, arg210_1, arg211_1, arg212_1, arg213_1, arg214_1, arg215_1, arg217_1, arg216_1, arg219_1, arg218_1, arg222_1, arg221_1, arg220_1, arg223_1, arg224_1, arg225_1, arg226_1, arg227_1, arg228_1, arg229_1, arg231_1, arg230_1, arg233_1, arg232_1, arg236_1, arg235_1, arg234_1, arg237_1, arg238_1, arg239_1, arg240_1, arg241_1, arg242_1, arg243_1, arg245_1, arg244_1, arg247_1, arg246_1, arg250_1, arg249_1, arg248_1, arg251_1, arg252_1, arg253_1, arg254_1, arg255_1, arg256_1, arg257_1, arg259_1, arg258_1, arg261_1, arg260_1, arg264_1, arg263_1, arg262_1, arg265_1, arg266_1, arg267_1, arg268_1, arg269_1, arg270_1, arg271_1, arg273_1, arg272_1, arg275_1, arg274_1, arg278_1, arg277_1, arg276_1, arg279_1, arg280_1, arg281_1, arg282_1, arg283_1, arg284_1, arg285_1, arg287_1, arg286_1, arg289_1, arg288_1, arg292_1, arg291_1, arg290_1, arg293_1, arg294_1, arg295_1, arg296_1, arg297_1, arg298_1, arg299_1, arg301_1, arg300_1, arg303_1, arg302_1, arg306_1, arg305_1, arg304_1, arg307_1, arg308_1, arg309_1, arg310_1, arg311_1, arg312_1, arg313_1, arg315_1, arg314_1, arg317_1, arg316_1, arg320_1, arg319_1, arg318_1, arg321_1, arg322_1, arg323_1, arg324_1, arg325_1, arg326_1, arg327_1, arg329_1, arg328_1, arg331_1, arg330_1, arg334_1, arg333_1, arg332_1, arg335_1, arg336_1, arg337_1, arg338_1, arg339_1, arg340_1, arg341_1, arg343_1, arg342_1, arg345_1, arg344_1, arg348_1, arg347_1, arg346_1, arg349_1, arg350_1, arg351_1, arg352_1, arg353_1, arg354_1, arg355_1, arg357_1, arg356_1, arg359_1, arg358_1, arg362_1, arg361_1, arg360_1, arg363_1, arg364_1, arg365_1, arg366_1, arg367_1, arg368_1, arg369_1, arg371_1, arg370_1, arg373_1, arg372_1, arg376_1, arg375_1, arg374_1, arg377_1, arg378_1, arg379_1, arg380_1, arg381_1, arg382_1, arg383_1, arg385_1, arg384_1, arg387_1, arg386_1, arg390_1, arg389_1, arg388_1, arg391_1, arg392_1, arg393_1, arg394_1, arg395_1, arg396_1, arg397_1 = args
    args.clear()
    with torch.cuda._DeviceGuard(0):
        torch.cuda.set_device(0)
        arg1_1 = copy_if_misaligned(arg1_1)
        buf1 = empty_strided_cuda((1, 1, 1536), (1536, 1536, 1), torch.float16)
        # Topologically Sorted Source Nodes: [inputs_embeds, hidden_states, pow_1, variance, add, rsqrt, hidden_states_1, to_4, hidden_states_2], Original ATen: [aten.embedding, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy_add_embedding_mean_mul_pow_rsqrt_0.run(arg1_1, arg2_1, arg5_1, buf1, 1, 1536, stream=raw_stream0)
        del arg5_1
        buf2 = empty_strided_cuda((1, 1536), (1536, 1), torch.float16)
        # Topologically Sorted Source Nodes: [inputs_embeds, hidden_states, pow_1, variance, add, rsqrt, hidden_states_1, to_4, hidden_states_2, linear], Original ATen: [aten.embedding, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.view, aten.t, aten.addmm]
        extern_kernels.addmm(arg7_1, reinterpret_tensor(buf1, (1, 1536), (0, 1), 0), reinterpret_tensor(arg6_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf2)
        del arg6_1
        del arg7_1
        buf3 = empty_strided_cuda((1, 256), (256, 1), torch.float16)
        # Topologically Sorted Source Nodes: [linear_1], Original ATen: [aten.view, aten.t, aten.addmm]
        extern_kernels.addmm(arg9_1, reinterpret_tensor(buf1, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg8_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf3)
        del arg8_1
        del arg9_1
        arg0_1 = copy_if_misaligned(arg0_1)
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, cos_3, sin_1, sin_2, sin_3, linear_1, view_2, key_states, mul_6, x2_1, neg_1, x1_1, cat_2, mul_7, k_embed, index_copy_], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_bmm_cat_expand_index_copy_mul_neg_slice_transpose_unsqueeze_view_1.run(arg0_1, buf3, arg4_1, arg12_1, 256, stream=raw_stream0)
        buf5 = buf3; del buf3  # reuse
        # Topologically Sorted Source Nodes: [linear_2], Original ATen: [aten.view, aten.t, aten.addmm]
        extern_kernels.addmm(arg11_1, reinterpret_tensor(buf1, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg10_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf5)
        del arg10_1
        del arg11_1
        # Topologically Sorted Source Nodes: [linear_2, view_3, value_states, index_copy__1], Original ATen: [aten.view, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_index_copy_transpose_view_2.run(arg0_1, buf5, arg13_1, 256, stream=raw_stream0)
        buf7 = reinterpret_tensor(buf1, (1, 12, 1, 128), (1536, 128, 128, 1), 0); del buf1  # reuse
        # Topologically Sorted Source Nodes: [linear, view_1, query_states, getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, cos_3, mul_4, x2, neg, x1, cat_1, sin_1, sin_2, sin_3, mul_5, q_embed, key, value, attn_output], Original ATen: [aten.view, aten.transpose, aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.clone, aten._unsafe_view, aten._scaled_dot_product_efficient_attention]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_efficient_attention__to_copy__unsafe_view_add_bmm_cat_clone_expand_mul_neg_slice_transpose_unsqueeze_view_3.run(buf2, arg4_1, arg0_1, buf7, 1536, stream=raw_stream0)
        buf8 = empty_strided_cuda((1, 12, 192, 128), (294912, 24576, 128, 1), torch.float16)
        # Topologically Sorted Source Nodes: [linear, view_1, query_states, getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, cos_3, mul_4, x2, neg, x1, cat_1, sin_1, sin_2, sin_3, mul_5, q_embed, key, value, attn_output], Original ATen: [aten.view, aten.transpose, aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.clone, aten._unsafe_view, aten._scaled_dot_product_efficient_attention]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_efficient_attention__to_copy__unsafe_view_add_bmm_cat_clone_expand_mul_neg_slice_transpose_unsqueeze_view_4.run(arg12_1, buf8, 294912, stream=raw_stream0)
        del arg12_1
        buf9 = empty_strided_cuda((1, 12, 192, 128), (294912, 24576, 128, 1), torch.float16)
        # Topologically Sorted Source Nodes: [linear, view_1, query_states, getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, cos_3, mul_4, x2, neg, x1, cat_1, sin_1, sin_2, sin_3, mul_5, q_embed, key, value, attn_output], Original ATen: [aten.view, aten.transpose, aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.clone, aten._unsafe_view, aten._scaled_dot_product_efficient_attention]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_efficient_attention__to_copy__unsafe_view_add_bmm_cat_clone_expand_mul_neg_slice_transpose_unsqueeze_view_4.run(arg13_1, buf9, 294912, stream=raw_stream0)
        del arg13_1
        arg3_1 = copy_if_misaligned(arg3_1)
        # Topologically Sorted Source Nodes: [linear, view_1, query_states, getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, cos_3, mul_4, x2, neg, x1, cat_1, sin_1, sin_2, sin_3, mul_5, q_embed, key, value, attn_output], Original ATen: [aten.view, aten.transpose, aten.unsqueeze, aten.expand, aten._to_copy, aten.bmm, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.clone, aten._unsafe_view, aten._scaled_dot_product_efficient_attention]
        buf10 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf7, buf8, buf9, reinterpret_tensor(arg3_1, (1, 12, 1, 192), (192, 0, 192, 1), 0), False, scale=0.08838834764831845)
        del buf8
        buf11 = buf10[0]
        assert_tensor_metadata(buf11, (1, 12, 1, 128), (1536, 128, 1536, 1), torch.float16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
        assert_alignment(buf11, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
        del buf10
        buf15 = reinterpret_tensor(buf7, (1, 1536), (1536, 1), 0); del buf7  # reuse
        # Topologically Sorted Source Nodes: [transpose_4, reshape_2, attn_output_3], Original ATen: [aten.transpose, aten.view, aten.t, aten.mm]
        extern_kernels.mm(reinterpret_tensor(buf11, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg14_1, (1536, 1536), (1, 1536), 0), out=buf15)
        del arg14_1
        buf17 = reinterpret_tensor(buf11, (1, 1, 1536), (1536, 1536, 1), 0); del buf11  # reuse
        # Topologically Sorted Source Nodes: [inputs_embeds, attn_output_3, hidden_states_5, hidden_states_6, pow_2, variance_1, add_4, rsqrt_1, hidden_states_7, to_6, hidden_states_8], Original ATen: [aten.embedding, aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_5.run(arg1_1, arg2_1, buf15, arg15_1, buf17, 1, 1536, stream=raw_stream0)
        del arg15_1
        buf18 = empty_strided_cuda((1, 8960), (8960, 1), torch.float16)
        # Topologically Sorted Source Nodes: [linear_4], Original ATen: [aten.view, aten.t, aten.mm]
        extern_kernels.mm(reinterpret_tensor(buf17, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg16_1, (1536, 8960), (1, 1536), 0), out=buf18)
        del arg16_1
        buf19 = empty_strided_cuda((1, 8960), (8960, 1), torch.float16)
        # Topologically Sorted Source Nodes: [linear_5], Original ATen: [aten.view, aten.t, aten.mm]
        extern_kernels.mm(reinterpret_tensor(buf17, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg17_1, (1536, 8960), (1, 1536), 0), out=buf19)
        del arg17_1
        buf20 = reinterpret_tensor(buf18, (1, 1, 8960), (8960, 8960, 1), 0); del buf18  # reuse
        # Topologically Sorted Source Nodes: [linear_4, silu, linear_5, mul_10], Original ATen: [aten._unsafe_view, aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_mul_silu_6.run(buf20, buf19, 8960, stream=raw_stream0)
        del buf19
        buf21 = reinterpret_tensor(buf17, (1, 1536), (1536, 1), 0); del buf17  # reuse
        # Topologically Sorted Source Nodes: [linear_4, silu, linear_5, mul_10, down_proj], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
        extern_kernels.mm(reinterpret_tensor(buf20, (1, 8960), (0, 1), 0), reinterpret_tensor(arg18_1, (8960, 1536), (1, 8960), 0), out=buf21)
        del arg18_1
        del buf20
        buf23 = reinterpret_tensor(buf2, (1, 1, 1536), (1536, 1536, 1), 0); del buf2  # reuse
        # Topologically Sorted Source Nodes: [inputs_embeds, attn_output_3, hidden_states_5, down_proj, hidden_states_9, hidden_states_10, pow_3, variance_2, add_6, rsqrt_2, hidden_states_11, to_8, hidden_states_12], Original ATen: [aten.embedding, aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_7.run(arg1_1, arg2_1, buf15, buf21, arg19_1, buf23, 1, 1536, stream=raw_stream0)
        del arg19_1
        buf24 = empty_strided_cuda((1, 1536), (1536, 1), torch.float16)
        # Topologically Sorted Source Nodes: [linear_7], Original ATen: [aten.view, aten.t, aten.addmm]
        extern_kernels.addmm(arg21_1, reinterpret_tensor(buf23, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg20_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf24)
        del arg20_1
        del arg21_1
        buf25 = buf5; del buf5  # reuse
        # Topologically Sorted Source Nodes: [linear_8], Original ATen: [aten.view, aten.t, aten.addmm]
        extern_kernels.addmm(arg23_1, reinterpret_tensor(buf23, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg22_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf25)
        del arg22_1
        del arg23_1
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, cos_4, sin_4, linear_8, view_5, key_states_1, mul_15, x2_3, neg_3, x1_3, cat_4, mul_16, k_embed_1, index_copy__2], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_bmm_cat_expand_index_copy_mul_neg_slice_transpose_unsqueeze_view_1.run(arg0_1, buf25, arg4_1, arg26_1, 256, stream=raw_stream0)
        buf27 = buf25; del buf25  # reuse
        # Topologically Sorted Source Nodes: [linear_9], Original ATen: [aten.view, aten.t, aten.addmm]
        extern_kernels.addmm(arg25_1, reinterpret_tensor(buf23, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg24_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf27)
        del arg24_1
        del arg25_1
        # Topologically Sorted Source Nodes: [linear_9, view_6, value_states_1, index_copy__3], Original ATen: [aten.view, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_index_copy_transpose_view_2.run(arg0_1, buf27, arg27_1, 256, stream=raw_stream0)
        buf29 = reinterpret_tensor(buf23, (1, 12, 1, 128), (1536, 128, 128, 1), 0); del buf23  # reuse
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, linear_7, view_4, query_states_1, cos_4, mul_13, x2_2, neg_2, x1_2, cat_3, sin_4, mul_14, q_embed_1, key_1, value_1, attn_output_4], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.clone, aten._unsafe_view, aten._scaled_dot_product_efficient_attention]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_efficient_attention__to_copy__unsafe_view_add_bmm_cat_clone_expand_mul_neg_slice_transpose_unsqueeze_view_3.run(buf24, arg4_1, arg0_1, buf29, 1536, stream=raw_stream0)
        buf30 = buf9; del buf9  # reuse
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, linear_7, view_4, query_states_1, cos_4, mul_13, x2_2, neg_2, x1_2, cat_3, sin_4, mul_14, q_embed_1, key_1, value_1, attn_output_4], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.clone, aten._unsafe_view, aten._scaled_dot_product_efficient_attention]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_efficient_attention__to_copy__unsafe_view_add_bmm_cat_clone_expand_mul_neg_slice_transpose_unsqueeze_view_4.run(arg26_1, buf30, 294912, stream=raw_stream0)
        del arg26_1
        buf31 = empty_strided_cuda((1, 12, 192, 128), (294912, 24576, 128, 1), torch.float16)
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, linear_7, view_4, query_states_1, cos_4, mul_13, x2_2, neg_2, x1_2, cat_3, sin_4, mul_14, q_embed_1, key_1, value_1, attn_output_4], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.clone, aten._unsafe_view, aten._scaled_dot_product_efficient_attention]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_efficient_attention__to_copy__unsafe_view_add_bmm_cat_clone_expand_mul_neg_slice_transpose_unsqueeze_view_4.run(arg27_1, buf31, 294912, stream=raw_stream0)
        del arg27_1
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, linear_7, view_4, query_states_1, cos_4, mul_13, x2_2, neg_2, x1_2, cat_3, sin_4, mul_14, q_embed_1, key_1, value_1, attn_output_4], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.clone, aten._unsafe_view, aten._scaled_dot_product_efficient_attention]
        buf32 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf29, buf30, buf31, reinterpret_tensor(arg3_1, (1, 12, 1, 192), (192, 0, 192, 1), 0), False, scale=0.08838834764831845)
        del buf30
        buf33 = buf32[0]
        assert_tensor_metadata(buf33, (1, 12, 1, 128), (1536, 128, 1536, 1), torch.float16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
        assert_alignment(buf33, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
        del buf32
        buf37 = reinterpret_tensor(buf29, (1, 1536), (1536, 1), 0); del buf29  # reuse
        # Topologically Sorted Source Nodes: [transpose_8, reshape_5, attn_output_7], Original ATen: [aten.transpose, aten.view, aten.t, aten.mm]
        extern_kernels.mm(reinterpret_tensor(buf33, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg28_1, (1536, 1536), (1, 1536), 0), out=buf37)
        del arg28_1
        buf38 = reinterpret_tensor(buf15, (1, 1, 1536), (1536, 1536, 1), 0); del buf15  # reuse
        buf40 = reinterpret_tensor(buf33, (1, 1, 1536), (1536, 1536, 1), 0); del buf33  # reuse
        # Topologically Sorted Source Nodes: [inputs_embeds, attn_output_3, hidden_states_5, down_proj, hidden_states_9, attn_output_7, hidden_states_15, hidden_states_16, pow_4, variance_3, add_10, rsqrt_3, hidden_states_17, to_10, hidden_states_18], Original ATen: [aten.embedding, aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_embedding_mean_mul_pow_rsqrt_8.run(buf38, arg1_1, arg2_1, buf21, buf37, arg29_1, buf40, 1, 1536, stream=raw_stream0)
        del arg1_1
        del arg29_1
        buf41 = empty_strided_cuda((1, 8960), (8960, 1), torch.float16)
        # Topologically Sorted Source Nodes: [hidden_states_16, pow_4, variance_3, add_10, rsqrt_3, hidden_states_17, to_10, hidden_states_18, linear_11], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
        extern_kernels.mm(reinterpret_tensor(buf40, (1, 1536), (0, 1), 0), reinterpret_tensor(arg30_1, (1536, 8960), (1, 1536), 0), out=buf41)
        del arg30_1
        buf42 = empty_strided_cuda((1, 8960), (8960, 1), torch.float16)
        # Topologically Sorted Source Nodes: [linear_12], Original ATen: [aten.view, aten.t, aten.mm]
        extern_kernels.mm(reinterpret_tensor(buf40, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg31_1, (1536, 8960), (1, 1536), 0), out=buf42)
        del arg31_1
        buf43 = reinterpret_tensor(buf41, (1, 1, 8960), (8960, 8960, 1), 0); del buf41  # reuse
        # Topologically Sorted Source Nodes: [linear_11, silu_1, linear_12, mul_19], Original ATen: [aten._unsafe_view, aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_mul_silu_6.run(buf43, buf42, 8960, stream=raw_stream0)
        del buf42
        buf44 = reinterpret_tensor(buf40, (1, 1536), (1536, 1), 0); del buf40  # reuse
        # Topologically Sorted Source Nodes: [linear_11, silu_1, linear_12, mul_19, down_proj_1], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
        extern_kernels.mm(reinterpret_tensor(buf43, (1, 8960), (0, 1), 0), reinterpret_tensor(arg32_1, (8960, 1536), (1, 8960), 0), out=buf44)
        del arg32_1
        del buf43
        buf46 = reinterpret_tensor(buf37, (1, 1, 1536), (1536, 1536, 1), 0); del buf37  # reuse
        # Topologically Sorted Source Nodes: [down_proj_1, hidden_states_19, hidden_states_20, pow_5, variance_4, add_12, rsqrt_4, hidden_states_21, to_12, hidden_states_22], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_9.run(buf38, buf44, arg33_1, buf46, 1, 1536, stream=raw_stream0)
        del arg33_1
        buf47 = buf21; del buf21  # reuse
        # Topologically Sorted Source Nodes: [down_proj_1, hidden_states_19, hidden_states_20, pow_5, variance_4, add_12, rsqrt_4, hidden_states_21, to_12, hidden_states_22, linear_14], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.addmm]
        extern_kernels.addmm(arg35_1, reinterpret_tensor(buf46, (1, 1536), (0, 1), 0), reinterpret_tensor(arg34_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf47)
        del arg34_1
        del arg35_1
        buf48 = buf27; del buf27  # reuse
        # Topologically Sorted Source Nodes: [linear_15], Original ATen: [aten.view, aten.t, aten.addmm]
        extern_kernels.addmm(arg37_1, reinterpret_tensor(buf46, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg36_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf48)
        del arg36_1
        del arg37_1
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, cos_5, sin_5, linear_15, view_8, key_states_2, mul_24, x2_5, neg_5, x1_5, cat_6, mul_25, k_embed_2, index_copy__4], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_bmm_cat_expand_index_copy_mul_neg_slice_transpose_unsqueeze_view_1.run(arg0_1, buf48, arg4_1, arg40_1, 256, stream=raw_stream0)
        buf50 = buf48; del buf48  # reuse
        # Topologically Sorted Source Nodes: [linear_16], Original ATen: [aten.view, aten.t, aten.addmm]
        extern_kernels.addmm(arg39_1, reinterpret_tensor(buf46, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg38_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf50)
        del arg38_1
        del arg39_1
        # Topologically Sorted Source Nodes: [linear_16, view_9, value_states_2, index_copy__5], Original ATen: [aten.view, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_index_copy_transpose_view_2.run(arg0_1, buf50, arg41_1, 256, stream=raw_stream0)
        del buf50
        buf52 = reinterpret_tensor(buf46, (1, 12, 1, 128), (1536, 128, 128, 1), 0); del buf46  # reuse
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, linear_14, view_7, query_states_2, cos_5, mul_22, x2_4, neg_4, x1_4, cat_5, sin_5, mul_23, q_embed_2, key_2, value_2, attn_output_8], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.clone, aten._unsafe_view, aten._scaled_dot_product_efficient_attention]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_efficient_attention__to_copy__unsafe_view_add_bmm_cat_clone_expand_mul_neg_slice_transpose_unsqueeze_view_3.run(buf47, arg4_1, arg0_1, buf52, 1536, stream=raw_stream0)
        buf53 = buf31; del buf31  # reuse
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, linear_14, view_7, query_states_2, cos_5, mul_22, x2_4, neg_4, x1_4, cat_5, sin_5, mul_23, q_embed_2, key_2, value_2, attn_output_8], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.clone, aten._unsafe_view, aten._scaled_dot_product_efficient_attention]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_efficient_attention__to_copy__unsafe_view_add_bmm_cat_clone_expand_mul_neg_slice_transpose_unsqueeze_view_4.run(arg40_1, buf53, 294912, stream=raw_stream0)
        del arg40_1
        buf54 = empty_strided_cuda((1, 12, 192, 128), (294912, 24576, 128, 1), torch.float16)
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, linear_14, view_7, query_states_2, cos_5, mul_22, x2_4, neg_4, x1_4, cat_5, sin_5, mul_23, q_embed_2, key_2, value_2, attn_output_8], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.clone, aten._unsafe_view, aten._scaled_dot_product_efficient_attention]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_efficient_attention__to_copy__unsafe_view_add_bmm_cat_clone_expand_mul_neg_slice_transpose_unsqueeze_view_4.run(arg41_1, buf54, 294912, stream=raw_stream0)
        del arg41_1
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, linear_14, view_7, query_states_2, cos_5, mul_22, x2_4, neg_4, x1_4, cat_5, sin_5, mul_23, q_embed_2, key_2, value_2, attn_output_8], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.clone, aten._unsafe_view, aten._scaled_dot_product_efficient_attention]
        buf55 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf52, buf53, buf54, reinterpret_tensor(arg3_1, (1, 12, 1, 192), (192, 0, 192, 1), 0), False, scale=0.08838834764831845)
        del buf53
        buf56 = buf55[0]
        assert_tensor_metadata(buf56, (1, 12, 1, 128), (1536, 128, 1536, 1), torch.float16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
        assert_alignment(buf56, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
        del buf55
        buf60 = reinterpret_tensor(buf52, (1, 1536), (1536, 1), 0); del buf52  # reuse
        # Topologically Sorted Source Nodes: [transpose_12, reshape_8, attn_output_11], Original ATen: [aten.transpose, aten.view, aten.t, aten.mm]
        extern_kernels.mm(reinterpret_tensor(buf56, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg42_1, (1536, 1536), (1, 1536), 0), out=buf60)
        del arg42_1
        buf62 = reinterpret_tensor(buf56, (1, 1, 1536), (1536, 1536, 1), 0); del buf56  # reuse
        # Topologically Sorted Source Nodes: [down_proj_1, hidden_states_19, attn_output_11, hidden_states_25, hidden_states_26, pow_6, variance_5, add_16, rsqrt_5, hidden_states_27, to_14, hidden_states_28], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_10.run(buf38, buf44, buf60, arg43_1, buf62, 1, 1536, stream=raw_stream0)
        del arg43_1
        buf63 = empty_strided_cuda((1, 8960), (8960, 1), torch.float16)
        # Topologically Sorted Source Nodes: [linear_18], Original ATen: [aten.view, aten.t, aten.mm]
        extern_kernels.mm(reinterpret_tensor(buf62, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg44_1, (1536, 8960), (1, 1536), 0), out=buf63)
        del arg44_1
        buf64 = empty_strided_cuda((1, 8960), (8960, 1), torch.float16)
        # Topologically Sorted Source Nodes: [linear_19], Original ATen: [aten.view, aten.t, aten.mm]
        extern_kernels.mm(reinterpret_tensor(buf62, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg45_1, (1536, 8960), (1, 1536), 0), out=buf64)
        del arg45_1
        buf65 = reinterpret_tensor(buf63, (1, 1, 8960), (8960, 8960, 1), 0); del buf63  # reuse
        # Topologically Sorted Source Nodes: [linear_18, silu_2, linear_19, mul_28], Original ATen: [aten._unsafe_view, aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_mul_silu_6.run(buf65, buf64, 8960, stream=raw_stream0)
        del buf64
        buf66 = reinterpret_tensor(buf62, (1, 1536), (1536, 1), 0); del buf62  # reuse
        # Topologically Sorted Source Nodes: [linear_18, silu_2, linear_19, mul_28, down_proj_2], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
        extern_kernels.mm(reinterpret_tensor(buf65, (1, 8960), (0, 1), 0), reinterpret_tensor(arg46_1, (8960, 1536), (1, 8960), 0), out=buf66)
        del arg46_1
        del buf65
        buf68 = reinterpret_tensor(buf47, (1, 1, 1536), (1536, 1536, 1), 0); del buf47  # reuse
        # Topologically Sorted Source Nodes: [down_proj_1, hidden_states_19, attn_output_11, hidden_states_25, down_proj_2, hidden_states_29, hidden_states_30, pow_7, variance_6, add_18, rsqrt_6, hidden_states_31, to_16, hidden_states_32], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_11.run(buf38, buf44, buf60, buf66, arg47_1, buf68, 1, 1536, stream=raw_stream0)
        del arg47_1
        buf69 = buf24; del buf24  # reuse
        # Topologically Sorted Source Nodes: [linear_21], Original ATen: [aten.view, aten.t, aten.addmm]
        extern_kernels.addmm(arg49_1, reinterpret_tensor(buf68, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg48_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf69)
        del arg48_1
        del arg49_1
        buf70 = empty_strided_cuda((1, 256), (256, 1), torch.float16)
        # Topologically Sorted Source Nodes: [linear_22], Original ATen: [aten.view, aten.t, aten.addmm]
        extern_kernels.addmm(arg51_1, reinterpret_tensor(buf68, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg50_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf70)
        del arg50_1
        del arg51_1
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, cos_6, sin_6, linear_22, view_11, key_states_3, mul_33, x2_7, neg_7, x1_7, cat_8, mul_34, k_embed_3, index_copy__6], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_bmm_cat_expand_index_copy_mul_neg_slice_transpose_unsqueeze_view_1.run(arg0_1, buf70, arg4_1, arg54_1, 256, stream=raw_stream0)
        buf72 = buf70; del buf70  # reuse
        # Topologically Sorted Source Nodes: [linear_23], Original ATen: [aten.view, aten.t, aten.addmm]
        extern_kernels.addmm(arg53_1, reinterpret_tensor(buf68, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg52_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf72)
        del arg52_1
        del arg53_1
        # Topologically Sorted Source Nodes: [linear_23, view_12, value_states_3, index_copy__7], Original ATen: [aten.view, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_index_copy_transpose_view_2.run(arg0_1, buf72, arg55_1, 256, stream=raw_stream0)
        del buf72
        buf74 = reinterpret_tensor(buf68, (1, 12, 1, 128), (1536, 128, 128, 1), 0); del buf68  # reuse
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, linear_21, view_10, query_states_3, cos_6, mul_31, x2_6, neg_6, x1_6, cat_7, sin_6, mul_32, q_embed_3, key_3, value_3, attn_output_12], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.clone, aten._unsafe_view, aten._scaled_dot_product_efficient_attention]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_efficient_attention__to_copy__unsafe_view_add_bmm_cat_clone_expand_mul_neg_slice_transpose_unsqueeze_view_3.run(buf69, arg4_1, arg0_1, buf74, 1536, stream=raw_stream0)
        del buf69
        buf75 = buf54; del buf54  # reuse
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, linear_21, view_10, query_states_3, cos_6, mul_31, x2_6, neg_6, x1_6, cat_7, sin_6, mul_32, q_embed_3, key_3, value_3, attn_output_12], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.clone, aten._unsafe_view, aten._scaled_dot_product_efficient_attention]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_efficient_attention__to_copy__unsafe_view_add_bmm_cat_clone_expand_mul_neg_slice_transpose_unsqueeze_view_4.run(arg54_1, buf75, 294912, stream=raw_stream0)
        del arg54_1
        buf76 = empty_strided_cuda((1, 12, 192, 128), (294912, 24576, 128, 1), torch.float16)
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, linear_21, view_10, query_states_3, cos_6, mul_31, x2_6, neg_6, x1_6, cat_7, sin_6, mul_32, q_embed_3, key_3, value_3, attn_output_12], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.clone, aten._unsafe_view, aten._scaled_dot_product_efficient_attention]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_efficient_attention__to_copy__unsafe_view_add_bmm_cat_clone_expand_mul_neg_slice_transpose_unsqueeze_view_4.run(arg55_1, buf76, 294912, stream=raw_stream0)
        del arg55_1
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, linear_21, view_10, query_states_3, cos_6, mul_31, x2_6, neg_6, x1_6, cat_7, sin_6, mul_32, q_embed_3, key_3, value_3, attn_output_12], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.clone, aten._unsafe_view, aten._scaled_dot_product_efficient_attention]
        buf77 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf74, buf75, buf76, reinterpret_tensor(arg3_1, (1, 12, 1, 192), (192, 0, 192, 1), 0), False, scale=0.08838834764831845)
        del buf75
        buf78 = buf77[0]
        assert_tensor_metadata(buf78, (1, 12, 1, 128), (1536, 128, 1536, 1), torch.float16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
        assert_alignment(buf78, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
        del buf77
        buf82 = reinterpret_tensor(buf74, (1, 1536), (1536, 1), 0); del buf74  # reuse
        # Topologically Sorted Source Nodes: [transpose_16, reshape_11, attn_output_15], Original ATen: [aten.transpose, aten.view, aten.t, aten.mm]
        extern_kernels.mm(reinterpret_tensor(buf78, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg56_1, (1536, 1536), (1, 1536), 0), out=buf82)
        del arg56_1
        buf83 = buf38; del buf38  # reuse
        buf85 = reinterpret_tensor(buf78, (1, 1, 1536), (1536, 1536, 1), 0); del buf78  # reuse
        # Topologically Sorted Source Nodes: [down_proj_1, hidden_states_19, attn_output_11, hidden_states_25, down_proj_2, hidden_states_29, attn_output_15, hidden_states_35, hidden_states_36, pow_8, variance_7, add_22, rsqrt_7, hidden_states_37, to_18, hidden_states_38], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_12.run(buf83, buf44, buf60, buf66, buf82, arg57_1, buf85, 1, 1536, stream=raw_stream0)
        del arg57_1
        del buf44
        buf86 = empty_strided_cuda((1, 8960), (8960, 1), torch.float16)
        # Topologically Sorted Source Nodes: [hidden_states_36, pow_8, variance_7, add_22, rsqrt_7, hidden_states_37, to_18, hidden_states_38, linear_25], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
        extern_kernels.mm(reinterpret_tensor(buf85, (1, 1536), (0, 1), 0), reinterpret_tensor(arg58_1, (1536, 8960), (1, 1536), 0), out=buf86)
        del arg58_1
        buf87 = empty_strided_cuda((1, 8960), (8960, 1), torch.float16)
        # Topologically Sorted Source Nodes: [linear_26], Original ATen: [aten.view, aten.t, aten.mm]
        extern_kernels.mm(reinterpret_tensor(buf85, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg59_1, (1536, 8960), (1, 1536), 0), out=buf87)
        del arg59_1
        buf88 = reinterpret_tensor(buf86, (1, 1, 8960), (8960, 8960, 1), 0); del buf86  # reuse
        # Topologically Sorted Source Nodes: [linear_25, silu_3, linear_26, mul_37], Original ATen: [aten._unsafe_view, aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_mul_silu_6.run(buf88, buf87, 8960, stream=raw_stream0)
        del buf87
        buf89 = reinterpret_tensor(buf85, (1, 1536), (1536, 1), 0); del buf85  # reuse
        # Topologically Sorted Source Nodes: [linear_25, silu_3, linear_26, mul_37, down_proj_3], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
        extern_kernels.mm(reinterpret_tensor(buf88, (1, 8960), (0, 1), 0), reinterpret_tensor(arg60_1, (8960, 1536), (1, 8960), 0), out=buf89)
        del arg60_1
        del buf88
        buf91 = reinterpret_tensor(buf82, (1, 1, 1536), (1536, 1536, 1), 0); del buf82  # reuse
        # Topologically Sorted Source Nodes: [down_proj_3, hidden_states_39, hidden_states_40, pow_9, variance_8, add_24, rsqrt_8, hidden_states_41, to_20, hidden_states_42], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_9.run(buf83, buf89, arg61_1, buf91, 1, 1536, stream=raw_stream0)
        del arg61_1
        buf92 = buf66; del buf66  # reuse
        # Topologically Sorted Source Nodes: [down_proj_3, hidden_states_39, hidden_states_40, pow_9, variance_8, add_24, rsqrt_8, hidden_states_41, to_20, hidden_states_42, linear_28], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.addmm]
        extern_kernels.addmm(arg63_1, reinterpret_tensor(buf91, (1, 1536), (0, 1), 0), reinterpret_tensor(arg62_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf92)
        del arg62_1
        del arg63_1
        buf93 = empty_strided_cuda((1, 256), (256, 1), torch.float16)
        # Topologically Sorted Source Nodes: [linear_29], Original ATen: [aten.view, aten.t, aten.addmm]
        extern_kernels.addmm(arg65_1, reinterpret_tensor(buf91, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg64_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf93)
        del arg64_1
        del arg65_1
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, cos_7, sin_7, linear_29, view_14, key_states_4, mul_42, x2_9, neg_9, x1_9, cat_10, mul_43, k_embed_4, index_copy__8], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_bmm_cat_expand_index_copy_mul_neg_slice_transpose_unsqueeze_view_1.run(arg0_1, buf93, arg4_1, arg68_1, 256, stream=raw_stream0)
        buf95 = buf93; del buf93  # reuse
        # Topologically Sorted Source Nodes: [linear_30], Original ATen: [aten.view, aten.t, aten.addmm]
        extern_kernels.addmm(arg67_1, reinterpret_tensor(buf91, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg66_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf95)
        del arg66_1
        del arg67_1
        # Topologically Sorted Source Nodes: [linear_30, view_15, value_states_4, index_copy__9], Original ATen: [aten.view, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_index_copy_transpose_view_2.run(arg0_1, buf95, arg69_1, 256, stream=raw_stream0)
        del buf95
        buf97 = reinterpret_tensor(buf91, (1, 12, 1, 128), (1536, 128, 128, 1), 0); del buf91  # reuse
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, linear_28, view_13, query_states_4, cos_7, mul_40, x2_8, neg_8, x1_8, cat_9, sin_7, mul_41, q_embed_4, key_4, value_4, attn_output_16], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.clone, aten._unsafe_view, aten._scaled_dot_product_efficient_attention]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_efficient_attention__to_copy__unsafe_view_add_bmm_cat_clone_expand_mul_neg_slice_transpose_unsqueeze_view_3.run(buf92, arg4_1, arg0_1, buf97, 1536, stream=raw_stream0)
        buf98 = buf76; del buf76  # reuse
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, linear_28, view_13, query_states_4, cos_7, mul_40, x2_8, neg_8, x1_8, cat_9, sin_7, mul_41, q_embed_4, key_4, value_4, attn_output_16], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.clone, aten._unsafe_view, aten._scaled_dot_product_efficient_attention]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_efficient_attention__to_copy__unsafe_view_add_bmm_cat_clone_expand_mul_neg_slice_transpose_unsqueeze_view_4.run(arg68_1, buf98, 294912, stream=raw_stream0)
        del arg68_1
        buf99 = empty_strided_cuda((1, 12, 192, 128), (294912, 24576, 128, 1), torch.float16)
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, linear_28, view_13, query_states_4, cos_7, mul_40, x2_8, neg_8, x1_8, cat_9, sin_7, mul_41, q_embed_4, key_4, value_4, attn_output_16], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.clone, aten._unsafe_view, aten._scaled_dot_product_efficient_attention]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_efficient_attention__to_copy__unsafe_view_add_bmm_cat_clone_expand_mul_neg_slice_transpose_unsqueeze_view_4.run(arg69_1, buf99, 294912, stream=raw_stream0)
        del arg69_1
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, linear_28, view_13, query_states_4, cos_7, mul_40, x2_8, neg_8, x1_8, cat_9, sin_7, mul_41, q_embed_4, key_4, value_4, attn_output_16], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.clone, aten._unsafe_view, aten._scaled_dot_product_efficient_attention]
        buf100 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf97, buf98, buf99, reinterpret_tensor(arg3_1, (1, 12, 1, 192), (192, 0, 192, 1), 0), False, scale=0.08838834764831845)
        del buf98
        buf101 = buf100[0]
        assert_tensor_metadata(buf101, (1, 12, 1, 128), (1536, 128, 1536, 1), torch.float16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
        assert_alignment(buf101, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
        del buf100
        buf105 = reinterpret_tensor(buf97, (1, 1536), (1536, 1), 0); del buf97  # reuse
        # Topologically Sorted Source Nodes: [transpose_20, reshape_14, attn_output_19], Original ATen: [aten.transpose, aten.view, aten.t, aten.mm]
        extern_kernels.mm(reinterpret_tensor(buf101, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg70_1, (1536, 1536), (1, 1536), 0), out=buf105)
        del arg70_1
        buf107 = reinterpret_tensor(buf101, (1, 1, 1536), (1536, 1536, 1), 0); del buf101  # reuse
        # Topologically Sorted Source Nodes: [down_proj_3, hidden_states_39, attn_output_19, hidden_states_45, hidden_states_46, pow_10, variance_9, add_28, rsqrt_9, hidden_states_47, to_22, hidden_states_48], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_10.run(buf83, buf89, buf105, arg71_1, buf107, 1, 1536, stream=raw_stream0)
        del arg71_1
        buf108 = empty_strided_cuda((1, 8960), (8960, 1), torch.float16)
        # Topologically Sorted Source Nodes: [linear_32], Original ATen: [aten.view, aten.t, aten.mm]
        extern_kernels.mm(reinterpret_tensor(buf107, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg72_1, (1536, 8960), (1, 1536), 0), out=buf108)
        del arg72_1
        buf109 = empty_strided_cuda((1, 8960), (8960, 1), torch.float16)
        # Topologically Sorted Source Nodes: [linear_33], Original ATen: [aten.view, aten.t, aten.mm]
        extern_kernels.mm(reinterpret_tensor(buf107, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg73_1, (1536, 8960), (1, 1536), 0), out=buf109)
        del arg73_1
        buf110 = reinterpret_tensor(buf108, (1, 1, 8960), (8960, 8960, 1), 0); del buf108  # reuse
        # Topologically Sorted Source Nodes: [linear_32, silu_4, linear_33, mul_46], Original ATen: [aten._unsafe_view, aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_mul_silu_6.run(buf110, buf109, 8960, stream=raw_stream0)
        del buf109
        buf111 = reinterpret_tensor(buf107, (1, 1536), (1536, 1), 0); del buf107  # reuse
        # Topologically Sorted Source Nodes: [linear_32, silu_4, linear_33, mul_46, down_proj_4], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
        extern_kernels.mm(reinterpret_tensor(buf110, (1, 8960), (0, 1), 0), reinterpret_tensor(arg74_1, (8960, 1536), (1, 8960), 0), out=buf111)
        del arg74_1
        del buf110
        buf113 = reinterpret_tensor(buf92, (1, 1, 1536), (1536, 1536, 1), 0); del buf92  # reuse
        # Topologically Sorted Source Nodes: [down_proj_3, hidden_states_39, attn_output_19, hidden_states_45, down_proj_4, hidden_states_49, hidden_states_50, pow_11, variance_10, add_30, rsqrt_10, hidden_states_51, to_24, hidden_states_52], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_11.run(buf83, buf89, buf105, buf111, arg75_1, buf113, 1, 1536, stream=raw_stream0)
        del arg75_1
        buf114 = buf60; del buf60  # reuse
        # Topologically Sorted Source Nodes: [linear_35], Original ATen: [aten.view, aten.t, aten.addmm]
        extern_kernels.addmm(arg77_1, reinterpret_tensor(buf113, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg76_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf114)
        del arg76_1
        del arg77_1
        buf115 = empty_strided_cuda((1, 256), (256, 1), torch.float16)
        # Topologically Sorted Source Nodes: [linear_36], Original ATen: [aten.view, aten.t, aten.addmm]
        extern_kernels.addmm(arg79_1, reinterpret_tensor(buf113, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg78_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf115)
        del arg78_1
        del arg79_1
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, cos_8, sin_8, linear_36, view_17, key_states_5, mul_51, x2_11, neg_11, x1_11, cat_12, mul_52, k_embed_5, index_copy__10], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_bmm_cat_expand_index_copy_mul_neg_slice_transpose_unsqueeze_view_1.run(arg0_1, buf115, arg4_1, arg82_1, 256, stream=raw_stream0)
        buf117 = buf115; del buf115  # reuse
        # Topologically Sorted Source Nodes: [linear_37], Original ATen: [aten.view, aten.t, aten.addmm]
        extern_kernels.addmm(arg81_1, reinterpret_tensor(buf113, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg80_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf117)
        del arg80_1
        del arg81_1
        # Topologically Sorted Source Nodes: [linear_37, view_18, value_states_5, index_copy__11], Original ATen: [aten.view, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_index_copy_transpose_view_2.run(arg0_1, buf117, arg83_1, 256, stream=raw_stream0)
        del buf117
        buf119 = reinterpret_tensor(buf113, (1, 12, 1, 128), (1536, 128, 128, 1), 0); del buf113  # reuse
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, linear_35, view_16, query_states_5, cos_8, mul_49, x2_10, neg_10, x1_10, cat_11, sin_8, mul_50, q_embed_5, key_5, value_5, attn_output_20], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.clone, aten._unsafe_view, aten._scaled_dot_product_efficient_attention]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_efficient_attention__to_copy__unsafe_view_add_bmm_cat_clone_expand_mul_neg_slice_transpose_unsqueeze_view_3.run(buf114, arg4_1, arg0_1, buf119, 1536, stream=raw_stream0)
        del buf114
        buf120 = buf99; del buf99  # reuse
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, linear_35, view_16, query_states_5, cos_8, mul_49, x2_10, neg_10, x1_10, cat_11, sin_8, mul_50, q_embed_5, key_5, value_5, attn_output_20], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.clone, aten._unsafe_view, aten._scaled_dot_product_efficient_attention]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_efficient_attention__to_copy__unsafe_view_add_bmm_cat_clone_expand_mul_neg_slice_transpose_unsqueeze_view_4.run(arg82_1, buf120, 294912, stream=raw_stream0)
        del arg82_1
        buf121 = empty_strided_cuda((1, 12, 192, 128), (294912, 24576, 128, 1), torch.float16)
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, linear_35, view_16, query_states_5, cos_8, mul_49, x2_10, neg_10, x1_10, cat_11, sin_8, mul_50, q_embed_5, key_5, value_5, attn_output_20], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.clone, aten._unsafe_view, aten._scaled_dot_product_efficient_attention]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_efficient_attention__to_copy__unsafe_view_add_bmm_cat_clone_expand_mul_neg_slice_transpose_unsqueeze_view_4.run(arg83_1, buf121, 294912, stream=raw_stream0)
        del arg83_1
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, linear_35, view_16, query_states_5, cos_8, mul_49, x2_10, neg_10, x1_10, cat_11, sin_8, mul_50, q_embed_5, key_5, value_5, attn_output_20], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.clone, aten._unsafe_view, aten._scaled_dot_product_efficient_attention]
        buf122 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf119, buf120, buf121, reinterpret_tensor(arg3_1, (1, 12, 1, 192), (192, 0, 192, 1), 0), False, scale=0.08838834764831845)
        del buf120
        buf123 = buf122[0]
        assert_tensor_metadata(buf123, (1, 12, 1, 128), (1536, 128, 1536, 1), torch.float16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
        assert_alignment(buf123, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
        del buf122
        buf127 = reinterpret_tensor(buf119, (1, 1536), (1536, 1), 0); del buf119  # reuse
        # Topologically Sorted Source Nodes: [transpose_24, reshape_17, attn_output_23], Original ATen: [aten.transpose, aten.view, aten.t, aten.mm]
        extern_kernels.mm(reinterpret_tensor(buf123, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg84_1, (1536, 1536), (1, 1536), 0), out=buf127)
        del arg84_1
        buf128 = buf83; del buf83  # reuse
        buf130 = reinterpret_tensor(buf123, (1, 1, 1536), (1536, 1536, 1), 0); del buf123  # reuse
        # Topologically Sorted Source Nodes: [down_proj_3, hidden_states_39, attn_output_19, hidden_states_45, down_proj_4, hidden_states_49, attn_output_23, hidden_states_55, hidden_states_56, pow_12, variance_11, add_34, rsqrt_11, hidden_states_57, to_26, hidden_states_58], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_12.run(buf128, buf89, buf105, buf111, buf127, arg85_1, buf130, 1, 1536, stream=raw_stream0)
        del arg85_1
        del buf105
        buf131 = empty_strided_cuda((1, 8960), (8960, 1), torch.float16)
        # Topologically Sorted Source Nodes: [hidden_states_56, pow_12, variance_11, add_34, rsqrt_11, hidden_states_57, to_26, hidden_states_58, linear_39], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
        extern_kernels.mm(reinterpret_tensor(buf130, (1, 1536), (0, 1), 0), reinterpret_tensor(arg86_1, (1536, 8960), (1, 1536), 0), out=buf131)
        del arg86_1
        buf132 = empty_strided_cuda((1, 8960), (8960, 1), torch.float16)
        # Topologically Sorted Source Nodes: [linear_40], Original ATen: [aten.view, aten.t, aten.mm]
        extern_kernels.mm(reinterpret_tensor(buf130, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg87_1, (1536, 8960), (1, 1536), 0), out=buf132)
        del arg87_1
        buf133 = reinterpret_tensor(buf131, (1, 1, 8960), (8960, 8960, 1), 0); del buf131  # reuse
        # Topologically Sorted Source Nodes: [linear_39, silu_5, linear_40, mul_55], Original ATen: [aten._unsafe_view, aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_mul_silu_6.run(buf133, buf132, 8960, stream=raw_stream0)
        del buf132
        buf134 = reinterpret_tensor(buf130, (1, 1536), (1536, 1), 0); del buf130  # reuse
        # Topologically Sorted Source Nodes: [linear_39, silu_5, linear_40, mul_55, down_proj_5], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
        extern_kernels.mm(reinterpret_tensor(buf133, (1, 8960), (0, 1), 0), reinterpret_tensor(arg88_1, (8960, 1536), (1, 8960), 0), out=buf134)
        del arg88_1
        del buf133
        buf136 = reinterpret_tensor(buf89, (1, 1, 1536), (1536, 1536, 1), 0); del buf89  # reuse
        # Topologically Sorted Source Nodes: [down_proj_5, hidden_states_59, hidden_states_60, pow_13, variance_12, add_36, rsqrt_12, hidden_states_61, to_28, hidden_states_62], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_9.run(buf128, buf134, arg89_1, buf136, 1, 1536, stream=raw_stream0)
        del arg89_1
        buf137 = buf127; del buf127  # reuse
        # Topologically Sorted Source Nodes: [down_proj_5, hidden_states_59, hidden_states_60, pow_13, variance_12, add_36, rsqrt_12, hidden_states_61, to_28, hidden_states_62, linear_42], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.addmm]
        extern_kernels.addmm(arg91_1, reinterpret_tensor(buf136, (1, 1536), (0, 1), 0), reinterpret_tensor(arg90_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf137)
        del arg90_1
        del arg91_1
        buf138 = empty_strided_cuda((1, 256), (256, 1), torch.float16)
        # Topologically Sorted Source Nodes: [linear_43], Original ATen: [aten.view, aten.t, aten.addmm]
        extern_kernels.addmm(arg93_1, reinterpret_tensor(buf136, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg92_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf138)
        del arg92_1
        del arg93_1
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, cos_9, sin_9, linear_43, view_20, key_states_6, mul_60, x2_13, neg_13, x1_13, cat_14, mul_61, k_embed_6, index_copy__12], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_bmm_cat_expand_index_copy_mul_neg_slice_transpose_unsqueeze_view_1.run(arg0_1, buf138, arg4_1, arg96_1, 256, stream=raw_stream0)
        buf140 = buf138; del buf138  # reuse
        # Topologically Sorted Source Nodes: [linear_44], Original ATen: [aten.view, aten.t, aten.addmm]
        extern_kernels.addmm(arg95_1, reinterpret_tensor(buf136, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg94_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf140)
        del arg94_1
        del arg95_1
        # Topologically Sorted Source Nodes: [linear_44, view_21, value_states_6, index_copy__13], Original ATen: [aten.view, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_index_copy_transpose_view_2.run(arg0_1, buf140, arg97_1, 256, stream=raw_stream0)
        del buf140
        buf142 = reinterpret_tensor(buf136, (1, 12, 1, 128), (1536, 128, 128, 1), 0); del buf136  # reuse
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, linear_42, view_19, query_states_6, cos_9, mul_58, x2_12, neg_12, x1_12, cat_13, sin_9, mul_59, q_embed_6, key_6, value_6, attn_output_24], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.clone, aten._unsafe_view, aten._scaled_dot_product_efficient_attention]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_efficient_attention__to_copy__unsafe_view_add_bmm_cat_clone_expand_mul_neg_slice_transpose_unsqueeze_view_3.run(buf137, arg4_1, arg0_1, buf142, 1536, stream=raw_stream0)
        buf143 = buf121; del buf121  # reuse
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, linear_42, view_19, query_states_6, cos_9, mul_58, x2_12, neg_12, x1_12, cat_13, sin_9, mul_59, q_embed_6, key_6, value_6, attn_output_24], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.clone, aten._unsafe_view, aten._scaled_dot_product_efficient_attention]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_efficient_attention__to_copy__unsafe_view_add_bmm_cat_clone_expand_mul_neg_slice_transpose_unsqueeze_view_4.run(arg96_1, buf143, 294912, stream=raw_stream0)
        del arg96_1
        buf144 = empty_strided_cuda((1, 12, 192, 128), (294912, 24576, 128, 1), torch.float16)
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, linear_42, view_19, query_states_6, cos_9, mul_58, x2_12, neg_12, x1_12, cat_13, sin_9, mul_59, q_embed_6, key_6, value_6, attn_output_24], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.clone, aten._unsafe_view, aten._scaled_dot_product_efficient_attention]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_efficient_attention__to_copy__unsafe_view_add_bmm_cat_clone_expand_mul_neg_slice_transpose_unsqueeze_view_4.run(arg97_1, buf144, 294912, stream=raw_stream0)
        del arg97_1
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, linear_42, view_19, query_states_6, cos_9, mul_58, x2_12, neg_12, x1_12, cat_13, sin_9, mul_59, q_embed_6, key_6, value_6, attn_output_24], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.clone, aten._unsafe_view, aten._scaled_dot_product_efficient_attention]
        buf145 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf142, buf143, buf144, reinterpret_tensor(arg3_1, (1, 12, 1, 192), (192, 0, 192, 1), 0), False, scale=0.08838834764831845)
        del buf143
        buf146 = buf145[0]
        assert_tensor_metadata(buf146, (1, 12, 1, 128), (1536, 128, 1536, 1), torch.float16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
        assert_alignment(buf146, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
        del buf145
        buf150 = reinterpret_tensor(buf142, (1, 1536), (1536, 1), 0); del buf142  # reuse
        # Topologically Sorted Source Nodes: [transpose_28, reshape_20, attn_output_27], Original ATen: [aten.transpose, aten.view, aten.t, aten.mm]
        extern_kernels.mm(reinterpret_tensor(buf146, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg98_1, (1536, 1536), (1, 1536), 0), out=buf150)
        del arg98_1
        buf152 = reinterpret_tensor(buf146, (1, 1, 1536), (1536, 1536, 1), 0); del buf146  # reuse
        # Topologically Sorted Source Nodes: [down_proj_5, hidden_states_59, attn_output_27, hidden_states_65, hidden_states_66, pow_14, variance_13, add_40, rsqrt_13, hidden_states_67, to_30, hidden_states_68], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_10.run(buf128, buf134, buf150, arg99_1, buf152, 1, 1536, stream=raw_stream0)
        del arg99_1
        buf153 = empty_strided_cuda((1, 8960), (8960, 1), torch.float16)
        # Topologically Sorted Source Nodes: [linear_46], Original ATen: [aten.view, aten.t, aten.mm]
        extern_kernels.mm(reinterpret_tensor(buf152, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg100_1, (1536, 8960), (1, 1536), 0), out=buf153)
        del arg100_1
        buf154 = empty_strided_cuda((1, 8960), (8960, 1), torch.float16)
        # Topologically Sorted Source Nodes: [linear_47], Original ATen: [aten.view, aten.t, aten.mm]
        extern_kernels.mm(reinterpret_tensor(buf152, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg101_1, (1536, 8960), (1, 1536), 0), out=buf154)
        del arg101_1
        buf155 = reinterpret_tensor(buf153, (1, 1, 8960), (8960, 8960, 1), 0); del buf153  # reuse
        # Topologically Sorted Source Nodes: [linear_46, silu_6, linear_47, mul_64], Original ATen: [aten._unsafe_view, aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_mul_silu_6.run(buf155, buf154, 8960, stream=raw_stream0)
        del buf154
        buf156 = reinterpret_tensor(buf152, (1, 1536), (1536, 1), 0); del buf152  # reuse
        # Topologically Sorted Source Nodes: [linear_46, silu_6, linear_47, mul_64, down_proj_6], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
        extern_kernels.mm(reinterpret_tensor(buf155, (1, 8960), (0, 1), 0), reinterpret_tensor(arg102_1, (8960, 1536), (1, 8960), 0), out=buf156)
        del arg102_1
        del buf155
        buf158 = reinterpret_tensor(buf137, (1, 1, 1536), (1536, 1536, 1), 0); del buf137  # reuse
        # Topologically Sorted Source Nodes: [down_proj_5, hidden_states_59, attn_output_27, hidden_states_65, down_proj_6, hidden_states_69, hidden_states_70, pow_15, variance_14, add_42, rsqrt_14, hidden_states_71, to_32, hidden_states_72], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_11.run(buf128, buf134, buf150, buf156, arg103_1, buf158, 1, 1536, stream=raw_stream0)
        del arg103_1
        buf159 = buf111; del buf111  # reuse
        # Topologically Sorted Source Nodes: [linear_49], Original ATen: [aten.view, aten.t, aten.addmm]
        extern_kernels.addmm(arg105_1, reinterpret_tensor(buf158, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg104_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf159)
        del arg104_1
        del arg105_1
        buf160 = empty_strided_cuda((1, 256), (256, 1), torch.float16)
        # Topologically Sorted Source Nodes: [linear_50], Original ATen: [aten.view, aten.t, aten.addmm]
        extern_kernels.addmm(arg107_1, reinterpret_tensor(buf158, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg106_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf160)
        del arg106_1
        del arg107_1
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, cos_10, sin_10, linear_50, view_23, key_states_7, mul_69, x2_15, neg_15, x1_15, cat_16, mul_70, k_embed_7, index_copy__14], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_bmm_cat_expand_index_copy_mul_neg_slice_transpose_unsqueeze_view_1.run(arg0_1, buf160, arg4_1, arg110_1, 256, stream=raw_stream0)
        buf162 = buf160; del buf160  # reuse
        # Topologically Sorted Source Nodes: [linear_51], Original ATen: [aten.view, aten.t, aten.addmm]
        extern_kernels.addmm(arg109_1, reinterpret_tensor(buf158, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg108_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf162)
        del arg108_1
        del arg109_1
        # Topologically Sorted Source Nodes: [linear_51, view_24, value_states_7, index_copy__15], Original ATen: [aten.view, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_index_copy_transpose_view_2.run(arg0_1, buf162, arg111_1, 256, stream=raw_stream0)
        del buf162
        buf164 = reinterpret_tensor(buf158, (1, 12, 1, 128), (1536, 128, 128, 1), 0); del buf158  # reuse
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, linear_49, view_22, query_states_7, cos_10, mul_67, x2_14, neg_14, x1_14, cat_15, sin_10, mul_68, q_embed_7, key_7, value_7, attn_output_28], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.clone, aten._unsafe_view, aten._scaled_dot_product_efficient_attention]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_efficient_attention__to_copy__unsafe_view_add_bmm_cat_clone_expand_mul_neg_slice_transpose_unsqueeze_view_3.run(buf159, arg4_1, arg0_1, buf164, 1536, stream=raw_stream0)
        del buf159
        buf165 = buf144; del buf144  # reuse
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, linear_49, view_22, query_states_7, cos_10, mul_67, x2_14, neg_14, x1_14, cat_15, sin_10, mul_68, q_embed_7, key_7, value_7, attn_output_28], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.clone, aten._unsafe_view, aten._scaled_dot_product_efficient_attention]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_efficient_attention__to_copy__unsafe_view_add_bmm_cat_clone_expand_mul_neg_slice_transpose_unsqueeze_view_4.run(arg110_1, buf165, 294912, stream=raw_stream0)
        del arg110_1
        buf166 = empty_strided_cuda((1, 12, 192, 128), (294912, 24576, 128, 1), torch.float16)
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, linear_49, view_22, query_states_7, cos_10, mul_67, x2_14, neg_14, x1_14, cat_15, sin_10, mul_68, q_embed_7, key_7, value_7, attn_output_28], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.clone, aten._unsafe_view, aten._scaled_dot_product_efficient_attention]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_efficient_attention__to_copy__unsafe_view_add_bmm_cat_clone_expand_mul_neg_slice_transpose_unsqueeze_view_4.run(arg111_1, buf166, 294912, stream=raw_stream0)
        del arg111_1
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, linear_49, view_22, query_states_7, cos_10, mul_67, x2_14, neg_14, x1_14, cat_15, sin_10, mul_68, q_embed_7, key_7, value_7, attn_output_28], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.clone, aten._unsafe_view, aten._scaled_dot_product_efficient_attention]
        buf167 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf164, buf165, buf166, reinterpret_tensor(arg3_1, (1, 12, 1, 192), (192, 0, 192, 1), 0), False, scale=0.08838834764831845)
        del buf165
        buf168 = buf167[0]
        assert_tensor_metadata(buf168, (1, 12, 1, 128), (1536, 128, 1536, 1), torch.float16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
        assert_alignment(buf168, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
        del buf167
        buf172 = reinterpret_tensor(buf164, (1, 1536), (1536, 1), 0); del buf164  # reuse
        # Topologically Sorted Source Nodes: [transpose_32, reshape_23, attn_output_31], Original ATen: [aten.transpose, aten.view, aten.t, aten.mm]
        extern_kernels.mm(reinterpret_tensor(buf168, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg112_1, (1536, 1536), (1, 1536), 0), out=buf172)
        del arg112_1
        buf173 = buf128; del buf128  # reuse
        buf175 = reinterpret_tensor(buf168, (1, 1, 1536), (1536, 1536, 1), 0); del buf168  # reuse
        # Topologically Sorted Source Nodes: [down_proj_5, hidden_states_59, attn_output_27, hidden_states_65, down_proj_6, hidden_states_69, attn_output_31, hidden_states_75, hidden_states_76, pow_16, variance_15, add_46, rsqrt_15, hidden_states_77, to_34, hidden_states_78], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_12.run(buf173, buf134, buf150, buf156, buf172, arg113_1, buf175, 1, 1536, stream=raw_stream0)
        del arg113_1
        del buf134
        buf176 = empty_strided_cuda((1, 8960), (8960, 1), torch.float16)
        # Topologically Sorted Source Nodes: [hidden_states_76, pow_16, variance_15, add_46, rsqrt_15, hidden_states_77, to_34, hidden_states_78, linear_53], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
        extern_kernels.mm(reinterpret_tensor(buf175, (1, 1536), (0, 1), 0), reinterpret_tensor(arg114_1, (1536, 8960), (1, 1536), 0), out=buf176)
        del arg114_1
        buf177 = empty_strided_cuda((1, 8960), (8960, 1), torch.float16)
        # Topologically Sorted Source Nodes: [linear_54], Original ATen: [aten.view, aten.t, aten.mm]
        extern_kernels.mm(reinterpret_tensor(buf175, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg115_1, (1536, 8960), (1, 1536), 0), out=buf177)
        del arg115_1
        buf178 = reinterpret_tensor(buf176, (1, 1, 8960), (8960, 8960, 1), 0); del buf176  # reuse
        # Topologically Sorted Source Nodes: [linear_53, silu_7, linear_54, mul_73], Original ATen: [aten._unsafe_view, aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_mul_silu_6.run(buf178, buf177, 8960, stream=raw_stream0)
        del buf177
        buf179 = reinterpret_tensor(buf175, (1, 1536), (1536, 1), 0); del buf175  # reuse
        # Topologically Sorted Source Nodes: [linear_53, silu_7, linear_54, mul_73, down_proj_7], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
        extern_kernels.mm(reinterpret_tensor(buf178, (1, 8960), (0, 1), 0), reinterpret_tensor(arg116_1, (8960, 1536), (1, 8960), 0), out=buf179)
        del arg116_1
        del buf178
        buf181 = reinterpret_tensor(buf172, (1, 1, 1536), (1536, 1536, 1), 0); del buf172  # reuse
        # Topologically Sorted Source Nodes: [down_proj_7, hidden_states_79, hidden_states_80, pow_17, variance_16, add_48, rsqrt_16, hidden_states_81, to_36, hidden_states_82], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_9.run(buf173, buf179, arg117_1, buf181, 1, 1536, stream=raw_stream0)
        del arg117_1
        buf182 = buf156; del buf156  # reuse
        # Topologically Sorted Source Nodes: [down_proj_7, hidden_states_79, hidden_states_80, pow_17, variance_16, add_48, rsqrt_16, hidden_states_81, to_36, hidden_states_82, linear_56], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.addmm]
        extern_kernels.addmm(arg119_1, reinterpret_tensor(buf181, (1, 1536), (0, 1), 0), reinterpret_tensor(arg118_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf182)
        del arg118_1
        del arg119_1
        buf183 = empty_strided_cuda((1, 256), (256, 1), torch.float16)
        # Topologically Sorted Source Nodes: [linear_57], Original ATen: [aten.view, aten.t, aten.addmm]
        extern_kernels.addmm(arg121_1, reinterpret_tensor(buf181, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg120_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf183)
        del arg120_1
        del arg121_1
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, cos_11, sin_11, linear_57, view_26, key_states_8, mul_78, x2_17, neg_17, x1_17, cat_18, mul_79, k_embed_8, index_copy__16], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_bmm_cat_expand_index_copy_mul_neg_slice_transpose_unsqueeze_view_1.run(arg0_1, buf183, arg4_1, arg124_1, 256, stream=raw_stream0)
        buf185 = buf183; del buf183  # reuse
        # Topologically Sorted Source Nodes: [linear_58], Original ATen: [aten.view, aten.t, aten.addmm]
        extern_kernels.addmm(arg123_1, reinterpret_tensor(buf181, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg122_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf185)
        del arg122_1
        del arg123_1
        # Topologically Sorted Source Nodes: [linear_58, view_27, value_states_8, index_copy__17], Original ATen: [aten.view, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_index_copy_transpose_view_2.run(arg0_1, buf185, arg125_1, 256, stream=raw_stream0)
        del buf185
        buf187 = reinterpret_tensor(buf181, (1, 12, 1, 128), (1536, 128, 128, 1), 0); del buf181  # reuse
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, linear_56, view_25, query_states_8, cos_11, mul_76, x2_16, neg_16, x1_16, cat_17, sin_11, mul_77, q_embed_8, key_8, value_8, attn_output_32], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.clone, aten._unsafe_view, aten._scaled_dot_product_efficient_attention]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_efficient_attention__to_copy__unsafe_view_add_bmm_cat_clone_expand_mul_neg_slice_transpose_unsqueeze_view_3.run(buf182, arg4_1, arg0_1, buf187, 1536, stream=raw_stream0)
        buf188 = buf166; del buf166  # reuse
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, linear_56, view_25, query_states_8, cos_11, mul_76, x2_16, neg_16, x1_16, cat_17, sin_11, mul_77, q_embed_8, key_8, value_8, attn_output_32], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.clone, aten._unsafe_view, aten._scaled_dot_product_efficient_attention]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_efficient_attention__to_copy__unsafe_view_add_bmm_cat_clone_expand_mul_neg_slice_transpose_unsqueeze_view_4.run(arg124_1, buf188, 294912, stream=raw_stream0)
        del arg124_1
        buf189 = empty_strided_cuda((1, 12, 192, 128), (294912, 24576, 128, 1), torch.float16)
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, linear_56, view_25, query_states_8, cos_11, mul_76, x2_16, neg_16, x1_16, cat_17, sin_11, mul_77, q_embed_8, key_8, value_8, attn_output_32], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.clone, aten._unsafe_view, aten._scaled_dot_product_efficient_attention]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_efficient_attention__to_copy__unsafe_view_add_bmm_cat_clone_expand_mul_neg_slice_transpose_unsqueeze_view_4.run(arg125_1, buf189, 294912, stream=raw_stream0)
        del arg125_1
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, linear_56, view_25, query_states_8, cos_11, mul_76, x2_16, neg_16, x1_16, cat_17, sin_11, mul_77, q_embed_8, key_8, value_8, attn_output_32], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.clone, aten._unsafe_view, aten._scaled_dot_product_efficient_attention]
        buf190 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf187, buf188, buf189, reinterpret_tensor(arg3_1, (1, 12, 1, 192), (192, 0, 192, 1), 0), False, scale=0.08838834764831845)
        del buf188
        buf191 = buf190[0]
        assert_tensor_metadata(buf191, (1, 12, 1, 128), (1536, 128, 1536, 1), torch.float16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
        assert_alignment(buf191, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
        del buf190
        buf195 = reinterpret_tensor(buf187, (1, 1536), (1536, 1), 0); del buf187  # reuse
        # Topologically Sorted Source Nodes: [transpose_36, reshape_26, attn_output_35], Original ATen: [aten.transpose, aten.view, aten.t, aten.mm]
        extern_kernels.mm(reinterpret_tensor(buf191, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg126_1, (1536, 1536), (1, 1536), 0), out=buf195)
        del arg126_1
        buf197 = reinterpret_tensor(buf191, (1, 1, 1536), (1536, 1536, 1), 0); del buf191  # reuse
        # Topologically Sorted Source Nodes: [down_proj_7, hidden_states_79, attn_output_35, hidden_states_85, hidden_states_86, pow_18, variance_17, add_52, rsqrt_17, hidden_states_87, to_38, hidden_states_88], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_10.run(buf173, buf179, buf195, arg127_1, buf197, 1, 1536, stream=raw_stream0)
        del arg127_1
        buf198 = empty_strided_cuda((1, 8960), (8960, 1), torch.float16)
        # Topologically Sorted Source Nodes: [linear_60], Original ATen: [aten.view, aten.t, aten.mm]
        extern_kernels.mm(reinterpret_tensor(buf197, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg128_1, (1536, 8960), (1, 1536), 0), out=buf198)
        del arg128_1
        buf199 = empty_strided_cuda((1, 8960), (8960, 1), torch.float16)
        # Topologically Sorted Source Nodes: [linear_61], Original ATen: [aten.view, aten.t, aten.mm]
        extern_kernels.mm(reinterpret_tensor(buf197, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg129_1, (1536, 8960), (1, 1536), 0), out=buf199)
        del arg129_1
        buf200 = reinterpret_tensor(buf198, (1, 1, 8960), (8960, 8960, 1), 0); del buf198  # reuse
        # Topologically Sorted Source Nodes: [linear_60, silu_8, linear_61, mul_82], Original ATen: [aten._unsafe_view, aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_mul_silu_6.run(buf200, buf199, 8960, stream=raw_stream0)
        del buf199
        buf201 = reinterpret_tensor(buf197, (1, 1536), (1536, 1), 0); del buf197  # reuse
        # Topologically Sorted Source Nodes: [linear_60, silu_8, linear_61, mul_82, down_proj_8], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
        extern_kernels.mm(reinterpret_tensor(buf200, (1, 8960), (0, 1), 0), reinterpret_tensor(arg130_1, (8960, 1536), (1, 8960), 0), out=buf201)
        del arg130_1
        del buf200
        buf203 = reinterpret_tensor(buf182, (1, 1, 1536), (1536, 1536, 1), 0); del buf182  # reuse
        # Topologically Sorted Source Nodes: [down_proj_7, hidden_states_79, attn_output_35, hidden_states_85, down_proj_8, hidden_states_89, hidden_states_90, pow_19, variance_18, add_54, rsqrt_18, hidden_states_91, to_40, hidden_states_92], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_11.run(buf173, buf179, buf195, buf201, arg131_1, buf203, 1, 1536, stream=raw_stream0)
        del arg131_1
        buf204 = buf150; del buf150  # reuse
        # Topologically Sorted Source Nodes: [linear_63], Original ATen: [aten.view, aten.t, aten.addmm]
        extern_kernels.addmm(arg133_1, reinterpret_tensor(buf203, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg132_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf204)
        del arg132_1
        del arg133_1
        buf205 = empty_strided_cuda((1, 256), (256, 1), torch.float16)
        # Topologically Sorted Source Nodes: [linear_64], Original ATen: [aten.view, aten.t, aten.addmm]
        extern_kernels.addmm(arg135_1, reinterpret_tensor(buf203, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg134_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf205)
        del arg134_1
        del arg135_1
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, cos_12, sin_12, linear_64, view_29, key_states_9, mul_87, x2_19, neg_19, x1_19, cat_20, mul_88, k_embed_9, index_copy__18], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_bmm_cat_expand_index_copy_mul_neg_slice_transpose_unsqueeze_view_1.run(arg0_1, buf205, arg4_1, arg138_1, 256, stream=raw_stream0)
        buf207 = buf205; del buf205  # reuse
        # Topologically Sorted Source Nodes: [linear_65], Original ATen: [aten.view, aten.t, aten.addmm]
        extern_kernels.addmm(arg137_1, reinterpret_tensor(buf203, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg136_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf207)
        del arg136_1
        del arg137_1
        # Topologically Sorted Source Nodes: [linear_65, view_30, value_states_9, index_copy__19], Original ATen: [aten.view, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_index_copy_transpose_view_2.run(arg0_1, buf207, arg139_1, 256, stream=raw_stream0)
        del buf207
        buf209 = reinterpret_tensor(buf203, (1, 12, 1, 128), (1536, 128, 128, 1), 0); del buf203  # reuse
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, linear_63, view_28, query_states_9, cos_12, mul_85, x2_18, neg_18, x1_18, cat_19, sin_12, mul_86, q_embed_9, key_9, value_9, attn_output_36], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.clone, aten._unsafe_view, aten._scaled_dot_product_efficient_attention]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_efficient_attention__to_copy__unsafe_view_add_bmm_cat_clone_expand_mul_neg_slice_transpose_unsqueeze_view_3.run(buf204, arg4_1, arg0_1, buf209, 1536, stream=raw_stream0)
        del buf204
        buf210 = buf189; del buf189  # reuse
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, linear_63, view_28, query_states_9, cos_12, mul_85, x2_18, neg_18, x1_18, cat_19, sin_12, mul_86, q_embed_9, key_9, value_9, attn_output_36], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.clone, aten._unsafe_view, aten._scaled_dot_product_efficient_attention]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_efficient_attention__to_copy__unsafe_view_add_bmm_cat_clone_expand_mul_neg_slice_transpose_unsqueeze_view_4.run(arg138_1, buf210, 294912, stream=raw_stream0)
        del arg138_1
        buf211 = empty_strided_cuda((1, 12, 192, 128), (294912, 24576, 128, 1), torch.float16)
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, linear_63, view_28, query_states_9, cos_12, mul_85, x2_18, neg_18, x1_18, cat_19, sin_12, mul_86, q_embed_9, key_9, value_9, attn_output_36], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.clone, aten._unsafe_view, aten._scaled_dot_product_efficient_attention]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_efficient_attention__to_copy__unsafe_view_add_bmm_cat_clone_expand_mul_neg_slice_transpose_unsqueeze_view_4.run(arg139_1, buf211, 294912, stream=raw_stream0)
        del arg139_1
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, linear_63, view_28, query_states_9, cos_12, mul_85, x2_18, neg_18, x1_18, cat_19, sin_12, mul_86, q_embed_9, key_9, value_9, attn_output_36], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.clone, aten._unsafe_view, aten._scaled_dot_product_efficient_attention]
        buf212 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf209, buf210, buf211, reinterpret_tensor(arg3_1, (1, 12, 1, 192), (192, 0, 192, 1), 0), False, scale=0.08838834764831845)
        del buf210
        buf213 = buf212[0]
        assert_tensor_metadata(buf213, (1, 12, 1, 128), (1536, 128, 1536, 1), torch.float16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
        assert_alignment(buf213, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
        del buf212
        buf217 = reinterpret_tensor(buf209, (1, 1536), (1536, 1), 0); del buf209  # reuse
        # Topologically Sorted Source Nodes: [transpose_40, reshape_29, attn_output_39], Original ATen: [aten.transpose, aten.view, aten.t, aten.mm]
        extern_kernels.mm(reinterpret_tensor(buf213, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg140_1, (1536, 1536), (1, 1536), 0), out=buf217)
        del arg140_1
        buf218 = buf173; del buf173  # reuse
        buf220 = reinterpret_tensor(buf213, (1, 1, 1536), (1536, 1536, 1), 0); del buf213  # reuse
        # Topologically Sorted Source Nodes: [down_proj_7, hidden_states_79, attn_output_35, hidden_states_85, down_proj_8, hidden_states_89, attn_output_39, hidden_states_95, hidden_states_96, pow_20, variance_19, add_58, rsqrt_19, hidden_states_97, to_42, hidden_states_98], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_12.run(buf218, buf179, buf195, buf201, buf217, arg141_1, buf220, 1, 1536, stream=raw_stream0)
        del arg141_1
        del buf179
        buf221 = empty_strided_cuda((1, 8960), (8960, 1), torch.float16)
        # Topologically Sorted Source Nodes: [hidden_states_96, pow_20, variance_19, add_58, rsqrt_19, hidden_states_97, to_42, hidden_states_98, linear_67], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
        extern_kernels.mm(reinterpret_tensor(buf220, (1, 1536), (0, 1), 0), reinterpret_tensor(arg142_1, (1536, 8960), (1, 1536), 0), out=buf221)
        del arg142_1
        buf222 = empty_strided_cuda((1, 8960), (8960, 1), torch.float16)
        # Topologically Sorted Source Nodes: [linear_68], Original ATen: [aten.view, aten.t, aten.mm]
        extern_kernels.mm(reinterpret_tensor(buf220, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg143_1, (1536, 8960), (1, 1536), 0), out=buf222)
        del arg143_1
        buf223 = reinterpret_tensor(buf221, (1, 1, 8960), (8960, 8960, 1), 0); del buf221  # reuse
        # Topologically Sorted Source Nodes: [linear_67, silu_9, linear_68, mul_91], Original ATen: [aten._unsafe_view, aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_mul_silu_6.run(buf223, buf222, 8960, stream=raw_stream0)
        del buf222
        buf224 = reinterpret_tensor(buf220, (1, 1536), (1536, 1), 0); del buf220  # reuse
        # Topologically Sorted Source Nodes: [linear_67, silu_9, linear_68, mul_91, down_proj_9], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
        extern_kernels.mm(reinterpret_tensor(buf223, (1, 8960), (0, 1), 0), reinterpret_tensor(arg144_1, (8960, 1536), (1, 8960), 0), out=buf224)
        del arg144_1
        del buf223
        buf226 = reinterpret_tensor(buf217, (1, 1, 1536), (1536, 1536, 1), 0); del buf217  # reuse
        # Topologically Sorted Source Nodes: [down_proj_9, hidden_states_99, hidden_states_100, pow_21, variance_20, add_60, rsqrt_20, hidden_states_101, to_44, hidden_states_102], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_9.run(buf218, buf224, arg145_1, buf226, 1, 1536, stream=raw_stream0)
        del arg145_1
        buf227 = buf201; del buf201  # reuse
        # Topologically Sorted Source Nodes: [down_proj_9, hidden_states_99, hidden_states_100, pow_21, variance_20, add_60, rsqrt_20, hidden_states_101, to_44, hidden_states_102, linear_70], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.addmm]
        extern_kernels.addmm(arg147_1, reinterpret_tensor(buf226, (1, 1536), (0, 1), 0), reinterpret_tensor(arg146_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf227)
        del arg146_1
        del arg147_1
        buf228 = empty_strided_cuda((1, 256), (256, 1), torch.float16)
        # Topologically Sorted Source Nodes: [linear_71], Original ATen: [aten.view, aten.t, aten.addmm]
        extern_kernels.addmm(arg149_1, reinterpret_tensor(buf226, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg148_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf228)
        del arg148_1
        del arg149_1
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, cos_13, sin_13, linear_71, view_32, key_states_10, mul_96, x2_21, neg_21, x1_21, cat_22, mul_97, k_embed_10, index_copy__20], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_bmm_cat_expand_index_copy_mul_neg_slice_transpose_unsqueeze_view_1.run(arg0_1, buf228, arg4_1, arg152_1, 256, stream=raw_stream0)
        buf230 = buf228; del buf228  # reuse
        # Topologically Sorted Source Nodes: [linear_72], Original ATen: [aten.view, aten.t, aten.addmm]
        extern_kernels.addmm(arg151_1, reinterpret_tensor(buf226, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg150_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf230)
        del arg150_1
        del arg151_1
        # Topologically Sorted Source Nodes: [linear_72, view_33, value_states_10, index_copy__21], Original ATen: [aten.view, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_index_copy_transpose_view_2.run(arg0_1, buf230, arg153_1, 256, stream=raw_stream0)
        del buf230
        buf232 = reinterpret_tensor(buf226, (1, 12, 1, 128), (1536, 128, 128, 1), 0); del buf226  # reuse
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, linear_70, view_31, query_states_10, cos_13, mul_94, x2_20, neg_20, x1_20, cat_21, sin_13, mul_95, q_embed_10, key_10, value_10, attn_output_40], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.clone, aten._unsafe_view, aten._scaled_dot_product_efficient_attention]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_efficient_attention__to_copy__unsafe_view_add_bmm_cat_clone_expand_mul_neg_slice_transpose_unsqueeze_view_3.run(buf227, arg4_1, arg0_1, buf232, 1536, stream=raw_stream0)
        buf233 = buf211; del buf211  # reuse
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, linear_70, view_31, query_states_10, cos_13, mul_94, x2_20, neg_20, x1_20, cat_21, sin_13, mul_95, q_embed_10, key_10, value_10, attn_output_40], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.clone, aten._unsafe_view, aten._scaled_dot_product_efficient_attention]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_efficient_attention__to_copy__unsafe_view_add_bmm_cat_clone_expand_mul_neg_slice_transpose_unsqueeze_view_4.run(arg152_1, buf233, 294912, stream=raw_stream0)
        del arg152_1
        buf234 = empty_strided_cuda((1, 12, 192, 128), (294912, 24576, 128, 1), torch.float16)
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, linear_70, view_31, query_states_10, cos_13, mul_94, x2_20, neg_20, x1_20, cat_21, sin_13, mul_95, q_embed_10, key_10, value_10, attn_output_40], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.clone, aten._unsafe_view, aten._scaled_dot_product_efficient_attention]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_efficient_attention__to_copy__unsafe_view_add_bmm_cat_clone_expand_mul_neg_slice_transpose_unsqueeze_view_4.run(arg153_1, buf234, 294912, stream=raw_stream0)
        del arg153_1
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, linear_70, view_31, query_states_10, cos_13, mul_94, x2_20, neg_20, x1_20, cat_21, sin_13, mul_95, q_embed_10, key_10, value_10, attn_output_40], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.clone, aten._unsafe_view, aten._scaled_dot_product_efficient_attention]
        buf235 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf232, buf233, buf234, reinterpret_tensor(arg3_1, (1, 12, 1, 192), (192, 0, 192, 1), 0), False, scale=0.08838834764831845)
        del buf233
        buf236 = buf235[0]
        assert_tensor_metadata(buf236, (1, 12, 1, 128), (1536, 128, 1536, 1), torch.float16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
        assert_alignment(buf236, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
        del buf235
        buf240 = reinterpret_tensor(buf232, (1, 1536), (1536, 1), 0); del buf232  # reuse
        # Topologically Sorted Source Nodes: [transpose_44, reshape_32, attn_output_43], Original ATen: [aten.transpose, aten.view, aten.t, aten.mm]
        extern_kernels.mm(reinterpret_tensor(buf236, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg154_1, (1536, 1536), (1, 1536), 0), out=buf240)
        del arg154_1
        buf242 = reinterpret_tensor(buf236, (1, 1, 1536), (1536, 1536, 1), 0); del buf236  # reuse
        # Topologically Sorted Source Nodes: [down_proj_9, hidden_states_99, attn_output_43, hidden_states_105, hidden_states_106, pow_22, variance_21, add_64, rsqrt_21, hidden_states_107, to_46, hidden_states_108], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_10.run(buf218, buf224, buf240, arg155_1, buf242, 1, 1536, stream=raw_stream0)
        del arg155_1
        buf243 = empty_strided_cuda((1, 8960), (8960, 1), torch.float16)
        # Topologically Sorted Source Nodes: [linear_74], Original ATen: [aten.view, aten.t, aten.mm]
        extern_kernels.mm(reinterpret_tensor(buf242, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg156_1, (1536, 8960), (1, 1536), 0), out=buf243)
        del arg156_1
        buf244 = empty_strided_cuda((1, 8960), (8960, 1), torch.float16)
        # Topologically Sorted Source Nodes: [linear_75], Original ATen: [aten.view, aten.t, aten.mm]
        extern_kernels.mm(reinterpret_tensor(buf242, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg157_1, (1536, 8960), (1, 1536), 0), out=buf244)
        del arg157_1
        buf245 = reinterpret_tensor(buf243, (1, 1, 8960), (8960, 8960, 1), 0); del buf243  # reuse
        # Topologically Sorted Source Nodes: [linear_74, silu_10, linear_75, mul_100], Original ATen: [aten._unsafe_view, aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_mul_silu_6.run(buf245, buf244, 8960, stream=raw_stream0)
        del buf244
        buf246 = reinterpret_tensor(buf242, (1, 1536), (1536, 1), 0); del buf242  # reuse
        # Topologically Sorted Source Nodes: [linear_74, silu_10, linear_75, mul_100, down_proj_10], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
        extern_kernels.mm(reinterpret_tensor(buf245, (1, 8960), (0, 1), 0), reinterpret_tensor(arg158_1, (8960, 1536), (1, 8960), 0), out=buf246)
        del arg158_1
        del buf245
        buf248 = reinterpret_tensor(buf227, (1, 1, 1536), (1536, 1536, 1), 0); del buf227  # reuse
        # Topologically Sorted Source Nodes: [down_proj_9, hidden_states_99, attn_output_43, hidden_states_105, down_proj_10, hidden_states_109, hidden_states_110, pow_23, variance_22, add_66, rsqrt_22, hidden_states_111, to_48, hidden_states_112], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_11.run(buf218, buf224, buf240, buf246, arg159_1, buf248, 1, 1536, stream=raw_stream0)
        del arg159_1
        buf249 = buf195; del buf195  # reuse
        # Topologically Sorted Source Nodes: [linear_77], Original ATen: [aten.view, aten.t, aten.addmm]
        extern_kernels.addmm(arg161_1, reinterpret_tensor(buf248, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg160_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf249)
        del arg160_1
        del arg161_1
        buf250 = empty_strided_cuda((1, 256), (256, 1), torch.float16)
        # Topologically Sorted Source Nodes: [linear_78], Original ATen: [aten.view, aten.t, aten.addmm]
        extern_kernels.addmm(arg163_1, reinterpret_tensor(buf248, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg162_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf250)
        del arg162_1
        del arg163_1
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, cos_14, sin_14, linear_78, view_35, key_states_11, mul_105, x2_23, neg_23, x1_23, cat_24, mul_106, k_embed_11, index_copy__22], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_bmm_cat_expand_index_copy_mul_neg_slice_transpose_unsqueeze_view_1.run(arg0_1, buf250, arg4_1, arg166_1, 256, stream=raw_stream0)
        buf252 = buf250; del buf250  # reuse
        # Topologically Sorted Source Nodes: [linear_79], Original ATen: [aten.view, aten.t, aten.addmm]
        extern_kernels.addmm(arg165_1, reinterpret_tensor(buf248, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg164_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf252)
        del arg164_1
        del arg165_1
        # Topologically Sorted Source Nodes: [linear_79, view_36, value_states_11, index_copy__23], Original ATen: [aten.view, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_index_copy_transpose_view_2.run(arg0_1, buf252, arg167_1, 256, stream=raw_stream0)
        del buf252
        buf254 = reinterpret_tensor(buf248, (1, 12, 1, 128), (1536, 128, 128, 1), 0); del buf248  # reuse
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, linear_77, view_34, query_states_11, cos_14, mul_103, x2_22, neg_22, x1_22, cat_23, sin_14, mul_104, q_embed_11, key_11, value_11, attn_output_44], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.clone, aten._unsafe_view, aten._scaled_dot_product_efficient_attention]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_efficient_attention__to_copy__unsafe_view_add_bmm_cat_clone_expand_mul_neg_slice_transpose_unsqueeze_view_3.run(buf249, arg4_1, arg0_1, buf254, 1536, stream=raw_stream0)
        del buf249
        buf255 = buf234; del buf234  # reuse
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, linear_77, view_34, query_states_11, cos_14, mul_103, x2_22, neg_22, x1_22, cat_23, sin_14, mul_104, q_embed_11, key_11, value_11, attn_output_44], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.clone, aten._unsafe_view, aten._scaled_dot_product_efficient_attention]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_efficient_attention__to_copy__unsafe_view_add_bmm_cat_clone_expand_mul_neg_slice_transpose_unsqueeze_view_4.run(arg166_1, buf255, 294912, stream=raw_stream0)
        del arg166_1
        buf256 = empty_strided_cuda((1, 12, 192, 128), (294912, 24576, 128, 1), torch.float16)
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, linear_77, view_34, query_states_11, cos_14, mul_103, x2_22, neg_22, x1_22, cat_23, sin_14, mul_104, q_embed_11, key_11, value_11, attn_output_44], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.clone, aten._unsafe_view, aten._scaled_dot_product_efficient_attention]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_efficient_attention__to_copy__unsafe_view_add_bmm_cat_clone_expand_mul_neg_slice_transpose_unsqueeze_view_4.run(arg167_1, buf256, 294912, stream=raw_stream0)
        del arg167_1
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, linear_77, view_34, query_states_11, cos_14, mul_103, x2_22, neg_22, x1_22, cat_23, sin_14, mul_104, q_embed_11, key_11, value_11, attn_output_44], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.clone, aten._unsafe_view, aten._scaled_dot_product_efficient_attention]
        buf257 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf254, buf255, buf256, reinterpret_tensor(arg3_1, (1, 12, 1, 192), (192, 0, 192, 1), 0), False, scale=0.08838834764831845)
        del buf255
        buf258 = buf257[0]
        assert_tensor_metadata(buf258, (1, 12, 1, 128), (1536, 128, 1536, 1), torch.float16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
        assert_alignment(buf258, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
        del buf257
        buf262 = reinterpret_tensor(buf254, (1, 1536), (1536, 1), 0); del buf254  # reuse
        # Topologically Sorted Source Nodes: [transpose_48, reshape_35, attn_output_47], Original ATen: [aten.transpose, aten.view, aten.t, aten.mm]
        extern_kernels.mm(reinterpret_tensor(buf258, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg168_1, (1536, 1536), (1, 1536), 0), out=buf262)
        del arg168_1
        buf263 = buf218; del buf218  # reuse
        buf265 = reinterpret_tensor(buf258, (1, 1, 1536), (1536, 1536, 1), 0); del buf258  # reuse
        # Topologically Sorted Source Nodes: [down_proj_9, hidden_states_99, attn_output_43, hidden_states_105, down_proj_10, hidden_states_109, attn_output_47, hidden_states_115, hidden_states_116, pow_24, variance_23, add_70, rsqrt_23, hidden_states_117, to_50, hidden_states_118], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_12.run(buf263, buf224, buf240, buf246, buf262, arg169_1, buf265, 1, 1536, stream=raw_stream0)
        del arg169_1
        del buf224
        buf266 = empty_strided_cuda((1, 8960), (8960, 1), torch.float16)
        # Topologically Sorted Source Nodes: [hidden_states_116, pow_24, variance_23, add_70, rsqrt_23, hidden_states_117, to_50, hidden_states_118, linear_81], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
        extern_kernels.mm(reinterpret_tensor(buf265, (1, 1536), (0, 1), 0), reinterpret_tensor(arg170_1, (1536, 8960), (1, 1536), 0), out=buf266)
        del arg170_1
        buf267 = empty_strided_cuda((1, 8960), (8960, 1), torch.float16)
        # Topologically Sorted Source Nodes: [linear_82], Original ATen: [aten.view, aten.t, aten.mm]
        extern_kernels.mm(reinterpret_tensor(buf265, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg171_1, (1536, 8960), (1, 1536), 0), out=buf267)
        del arg171_1
        buf268 = reinterpret_tensor(buf266, (1, 1, 8960), (8960, 8960, 1), 0); del buf266  # reuse
        # Topologically Sorted Source Nodes: [linear_81, silu_11, linear_82, mul_109], Original ATen: [aten._unsafe_view, aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_mul_silu_6.run(buf268, buf267, 8960, stream=raw_stream0)
        del buf267
        buf269 = reinterpret_tensor(buf265, (1, 1536), (1536, 1), 0); del buf265  # reuse
        # Topologically Sorted Source Nodes: [linear_81, silu_11, linear_82, mul_109, down_proj_11], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
        extern_kernels.mm(reinterpret_tensor(buf268, (1, 8960), (0, 1), 0), reinterpret_tensor(arg172_1, (8960, 1536), (1, 8960), 0), out=buf269)
        del arg172_1
        del buf268
        buf271 = reinterpret_tensor(buf262, (1, 1, 1536), (1536, 1536, 1), 0); del buf262  # reuse
        # Topologically Sorted Source Nodes: [down_proj_11, hidden_states_119, hidden_states_120, pow_25, variance_24, add_72, rsqrt_24, hidden_states_121, to_52, hidden_states_122], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_9.run(buf263, buf269, arg173_1, buf271, 1, 1536, stream=raw_stream0)
        del arg173_1
        buf272 = buf246; del buf246  # reuse
        # Topologically Sorted Source Nodes: [down_proj_11, hidden_states_119, hidden_states_120, pow_25, variance_24, add_72, rsqrt_24, hidden_states_121, to_52, hidden_states_122, linear_84], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.addmm]
        extern_kernels.addmm(arg175_1, reinterpret_tensor(buf271, (1, 1536), (0, 1), 0), reinterpret_tensor(arg174_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf272)
        del arg174_1
        del arg175_1
        buf273 = empty_strided_cuda((1, 256), (256, 1), torch.float16)
        # Topologically Sorted Source Nodes: [linear_85], Original ATen: [aten.view, aten.t, aten.addmm]
        extern_kernels.addmm(arg177_1, reinterpret_tensor(buf271, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg176_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf273)
        del arg176_1
        del arg177_1
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, cos_15, sin_15, linear_85, view_38, key_states_12, mul_114, x2_25, neg_25, x1_25, cat_26, mul_115, k_embed_12, index_copy__24], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_bmm_cat_expand_index_copy_mul_neg_slice_transpose_unsqueeze_view_1.run(arg0_1, buf273, arg4_1, arg180_1, 256, stream=raw_stream0)
        buf275 = buf273; del buf273  # reuse
        # Topologically Sorted Source Nodes: [linear_86], Original ATen: [aten.view, aten.t, aten.addmm]
        extern_kernels.addmm(arg179_1, reinterpret_tensor(buf271, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg178_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf275)
        del arg178_1
        del arg179_1
        # Topologically Sorted Source Nodes: [linear_86, view_39, value_states_12, index_copy__25], Original ATen: [aten.view, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_index_copy_transpose_view_2.run(arg0_1, buf275, arg181_1, 256, stream=raw_stream0)
        del buf275
        buf277 = reinterpret_tensor(buf271, (1, 12, 1, 128), (1536, 128, 128, 1), 0); del buf271  # reuse
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, linear_84, view_37, query_states_12, cos_15, mul_112, x2_24, neg_24, x1_24, cat_25, sin_15, mul_113, q_embed_12, key_12, value_12, attn_output_48], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.clone, aten._unsafe_view, aten._scaled_dot_product_efficient_attention]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_efficient_attention__to_copy__unsafe_view_add_bmm_cat_clone_expand_mul_neg_slice_transpose_unsqueeze_view_3.run(buf272, arg4_1, arg0_1, buf277, 1536, stream=raw_stream0)
        buf278 = buf256; del buf256  # reuse
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, linear_84, view_37, query_states_12, cos_15, mul_112, x2_24, neg_24, x1_24, cat_25, sin_15, mul_113, q_embed_12, key_12, value_12, attn_output_48], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.clone, aten._unsafe_view, aten._scaled_dot_product_efficient_attention]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_efficient_attention__to_copy__unsafe_view_add_bmm_cat_clone_expand_mul_neg_slice_transpose_unsqueeze_view_4.run(arg180_1, buf278, 294912, stream=raw_stream0)
        del arg180_1
        buf279 = empty_strided_cuda((1, 12, 192, 128), (294912, 24576, 128, 1), torch.float16)
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, linear_84, view_37, query_states_12, cos_15, mul_112, x2_24, neg_24, x1_24, cat_25, sin_15, mul_113, q_embed_12, key_12, value_12, attn_output_48], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.clone, aten._unsafe_view, aten._scaled_dot_product_efficient_attention]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_efficient_attention__to_copy__unsafe_view_add_bmm_cat_clone_expand_mul_neg_slice_transpose_unsqueeze_view_4.run(arg181_1, buf279, 294912, stream=raw_stream0)
        del arg181_1
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, linear_84, view_37, query_states_12, cos_15, mul_112, x2_24, neg_24, x1_24, cat_25, sin_15, mul_113, q_embed_12, key_12, value_12, attn_output_48], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.clone, aten._unsafe_view, aten._scaled_dot_product_efficient_attention]
        buf280 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf277, buf278, buf279, reinterpret_tensor(arg3_1, (1, 12, 1, 192), (192, 0, 192, 1), 0), False, scale=0.08838834764831845)
        del buf278
        buf281 = buf280[0]
        assert_tensor_metadata(buf281, (1, 12, 1, 128), (1536, 128, 1536, 1), torch.float16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
        assert_alignment(buf281, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
        del buf280
        buf285 = reinterpret_tensor(buf277, (1, 1536), (1536, 1), 0); del buf277  # reuse
        # Topologically Sorted Source Nodes: [transpose_52, reshape_38, attn_output_51], Original ATen: [aten.transpose, aten.view, aten.t, aten.mm]
        extern_kernels.mm(reinterpret_tensor(buf281, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg182_1, (1536, 1536), (1, 1536), 0), out=buf285)
        del arg182_1
        buf287 = reinterpret_tensor(buf281, (1, 1, 1536), (1536, 1536, 1), 0); del buf281  # reuse
        # Topologically Sorted Source Nodes: [down_proj_11, hidden_states_119, attn_output_51, hidden_states_125, hidden_states_126, pow_26, variance_25, add_76, rsqrt_25, hidden_states_127, to_54, hidden_states_128], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_10.run(buf263, buf269, buf285, arg183_1, buf287, 1, 1536, stream=raw_stream0)
        del arg183_1
        buf288 = empty_strided_cuda((1, 8960), (8960, 1), torch.float16)
        # Topologically Sorted Source Nodes: [linear_88], Original ATen: [aten.view, aten.t, aten.mm]
        extern_kernels.mm(reinterpret_tensor(buf287, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg184_1, (1536, 8960), (1, 1536), 0), out=buf288)
        del arg184_1
        buf289 = empty_strided_cuda((1, 8960), (8960, 1), torch.float16)
        # Topologically Sorted Source Nodes: [linear_89], Original ATen: [aten.view, aten.t, aten.mm]
        extern_kernels.mm(reinterpret_tensor(buf287, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg185_1, (1536, 8960), (1, 1536), 0), out=buf289)
        del arg185_1
        buf290 = reinterpret_tensor(buf288, (1, 1, 8960), (8960, 8960, 1), 0); del buf288  # reuse
        # Topologically Sorted Source Nodes: [linear_88, silu_12, linear_89, mul_118], Original ATen: [aten._unsafe_view, aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_mul_silu_6.run(buf290, buf289, 8960, stream=raw_stream0)
        del buf289
        buf291 = reinterpret_tensor(buf287, (1, 1536), (1536, 1), 0); del buf287  # reuse
        # Topologically Sorted Source Nodes: [linear_88, silu_12, linear_89, mul_118, down_proj_12], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
        extern_kernels.mm(reinterpret_tensor(buf290, (1, 8960), (0, 1), 0), reinterpret_tensor(arg186_1, (8960, 1536), (1, 8960), 0), out=buf291)
        del arg186_1
        del buf290
        buf293 = reinterpret_tensor(buf272, (1, 1, 1536), (1536, 1536, 1), 0); del buf272  # reuse
        # Topologically Sorted Source Nodes: [down_proj_11, hidden_states_119, attn_output_51, hidden_states_125, down_proj_12, hidden_states_129, hidden_states_130, pow_27, variance_26, add_78, rsqrt_26, hidden_states_131, to_56, hidden_states_132], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_11.run(buf263, buf269, buf285, buf291, arg187_1, buf293, 1, 1536, stream=raw_stream0)
        del arg187_1
        buf294 = buf240; del buf240  # reuse
        # Topologically Sorted Source Nodes: [linear_91], Original ATen: [aten.view, aten.t, aten.addmm]
        extern_kernels.addmm(arg189_1, reinterpret_tensor(buf293, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg188_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf294)
        del arg188_1
        del arg189_1
        buf295 = empty_strided_cuda((1, 256), (256, 1), torch.float16)
        # Topologically Sorted Source Nodes: [linear_92], Original ATen: [aten.view, aten.t, aten.addmm]
        extern_kernels.addmm(arg191_1, reinterpret_tensor(buf293, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg190_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf295)
        del arg190_1
        del arg191_1
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, cos_16, sin_16, linear_92, view_41, key_states_13, mul_123, x2_27, neg_27, x1_27, cat_28, mul_124, k_embed_13, index_copy__26], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_bmm_cat_expand_index_copy_mul_neg_slice_transpose_unsqueeze_view_1.run(arg0_1, buf295, arg4_1, arg194_1, 256, stream=raw_stream0)
        buf297 = buf295; del buf295  # reuse
        # Topologically Sorted Source Nodes: [linear_93], Original ATen: [aten.view, aten.t, aten.addmm]
        extern_kernels.addmm(arg193_1, reinterpret_tensor(buf293, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg192_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf297)
        del arg192_1
        del arg193_1
        # Topologically Sorted Source Nodes: [linear_93, view_42, value_states_13, index_copy__27], Original ATen: [aten.view, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_index_copy_transpose_view_2.run(arg0_1, buf297, arg195_1, 256, stream=raw_stream0)
        del buf297
        buf299 = reinterpret_tensor(buf293, (1, 12, 1, 128), (1536, 128, 128, 1), 0); del buf293  # reuse
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, linear_91, view_40, query_states_13, cos_16, mul_121, x2_26, neg_26, x1_26, cat_27, sin_16, mul_122, q_embed_13, key_13, value_13, attn_output_52], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.clone, aten._unsafe_view, aten._scaled_dot_product_efficient_attention]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_efficient_attention__to_copy__unsafe_view_add_bmm_cat_clone_expand_mul_neg_slice_transpose_unsqueeze_view_3.run(buf294, arg4_1, arg0_1, buf299, 1536, stream=raw_stream0)
        del buf294
        buf300 = buf279; del buf279  # reuse
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, linear_91, view_40, query_states_13, cos_16, mul_121, x2_26, neg_26, x1_26, cat_27, sin_16, mul_122, q_embed_13, key_13, value_13, attn_output_52], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.clone, aten._unsafe_view, aten._scaled_dot_product_efficient_attention]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_efficient_attention__to_copy__unsafe_view_add_bmm_cat_clone_expand_mul_neg_slice_transpose_unsqueeze_view_4.run(arg194_1, buf300, 294912, stream=raw_stream0)
        del arg194_1
        buf301 = empty_strided_cuda((1, 12, 192, 128), (294912, 24576, 128, 1), torch.float16)
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, linear_91, view_40, query_states_13, cos_16, mul_121, x2_26, neg_26, x1_26, cat_27, sin_16, mul_122, q_embed_13, key_13, value_13, attn_output_52], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.clone, aten._unsafe_view, aten._scaled_dot_product_efficient_attention]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_efficient_attention__to_copy__unsafe_view_add_bmm_cat_clone_expand_mul_neg_slice_transpose_unsqueeze_view_4.run(arg195_1, buf301, 294912, stream=raw_stream0)
        del arg195_1
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, linear_91, view_40, query_states_13, cos_16, mul_121, x2_26, neg_26, x1_26, cat_27, sin_16, mul_122, q_embed_13, key_13, value_13, attn_output_52], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.clone, aten._unsafe_view, aten._scaled_dot_product_efficient_attention]
        buf302 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf299, buf300, buf301, reinterpret_tensor(arg3_1, (1, 12, 1, 192), (192, 0, 192, 1), 0), False, scale=0.08838834764831845)
        del buf300
        buf303 = buf302[0]
        assert_tensor_metadata(buf303, (1, 12, 1, 128), (1536, 128, 1536, 1), torch.float16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
        assert_alignment(buf303, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
        del buf302
        buf307 = reinterpret_tensor(buf299, (1, 1536), (1536, 1), 0); del buf299  # reuse
        # Topologically Sorted Source Nodes: [transpose_56, reshape_41, attn_output_55], Original ATen: [aten.transpose, aten.view, aten.t, aten.mm]
        extern_kernels.mm(reinterpret_tensor(buf303, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg196_1, (1536, 1536), (1, 1536), 0), out=buf307)
        del arg196_1
        buf308 = buf263; del buf263  # reuse
        buf310 = reinterpret_tensor(buf303, (1, 1, 1536), (1536, 1536, 1), 0); del buf303  # reuse
        # Topologically Sorted Source Nodes: [down_proj_11, hidden_states_119, attn_output_51, hidden_states_125, down_proj_12, hidden_states_129, attn_output_55, hidden_states_135, hidden_states_136, pow_28, variance_27, add_82, rsqrt_27, hidden_states_137, to_58, hidden_states_138], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_12.run(buf308, buf269, buf285, buf291, buf307, arg197_1, buf310, 1, 1536, stream=raw_stream0)
        del arg197_1
        del buf269
        buf311 = empty_strided_cuda((1, 8960), (8960, 1), torch.float16)
        # Topologically Sorted Source Nodes: [hidden_states_136, pow_28, variance_27, add_82, rsqrt_27, hidden_states_137, to_58, hidden_states_138, linear_95], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
        extern_kernels.mm(reinterpret_tensor(buf310, (1, 1536), (0, 1), 0), reinterpret_tensor(arg198_1, (1536, 8960), (1, 1536), 0), out=buf311)
        del arg198_1
        buf312 = empty_strided_cuda((1, 8960), (8960, 1), torch.float16)
        # Topologically Sorted Source Nodes: [linear_96], Original ATen: [aten.view, aten.t, aten.mm]
        extern_kernels.mm(reinterpret_tensor(buf310, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg199_1, (1536, 8960), (1, 1536), 0), out=buf312)
        del arg199_1
        buf313 = reinterpret_tensor(buf311, (1, 1, 8960), (8960, 8960, 1), 0); del buf311  # reuse
        # Topologically Sorted Source Nodes: [linear_95, silu_13, linear_96, mul_127], Original ATen: [aten._unsafe_view, aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_mul_silu_6.run(buf313, buf312, 8960, stream=raw_stream0)
        del buf312
        buf314 = reinterpret_tensor(buf310, (1, 1536), (1536, 1), 0); del buf310  # reuse
        # Topologically Sorted Source Nodes: [linear_95, silu_13, linear_96, mul_127, down_proj_13], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
        extern_kernels.mm(reinterpret_tensor(buf313, (1, 8960), (0, 1), 0), reinterpret_tensor(arg200_1, (8960, 1536), (1, 8960), 0), out=buf314)
        del arg200_1
        del buf313
        buf316 = reinterpret_tensor(buf307, (1, 1, 1536), (1536, 1536, 1), 0); del buf307  # reuse
        # Topologically Sorted Source Nodes: [down_proj_13, hidden_states_139, hidden_states_140, pow_29, variance_28, add_84, rsqrt_28, hidden_states_141, to_60, hidden_states_142], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_9.run(buf308, buf314, arg201_1, buf316, 1, 1536, stream=raw_stream0)
        del arg201_1
        buf317 = buf291; del buf291  # reuse
        # Topologically Sorted Source Nodes: [down_proj_13, hidden_states_139, hidden_states_140, pow_29, variance_28, add_84, rsqrt_28, hidden_states_141, to_60, hidden_states_142, linear_98], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.addmm]
        extern_kernels.addmm(arg203_1, reinterpret_tensor(buf316, (1, 1536), (0, 1), 0), reinterpret_tensor(arg202_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf317)
        del arg202_1
        del arg203_1
        buf318 = empty_strided_cuda((1, 256), (256, 1), torch.float16)
        # Topologically Sorted Source Nodes: [linear_99], Original ATen: [aten.view, aten.t, aten.addmm]
        extern_kernels.addmm(arg205_1, reinterpret_tensor(buf316, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg204_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf318)
        del arg204_1
        del arg205_1
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, cos_17, sin_17, linear_99, view_44, key_states_14, mul_132, x2_29, neg_29, x1_29, cat_30, mul_133, k_embed_14, index_copy__28], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_bmm_cat_expand_index_copy_mul_neg_slice_transpose_unsqueeze_view_1.run(arg0_1, buf318, arg4_1, arg208_1, 256, stream=raw_stream0)
        buf320 = buf318; del buf318  # reuse
        # Topologically Sorted Source Nodes: [linear_100], Original ATen: [aten.view, aten.t, aten.addmm]
        extern_kernels.addmm(arg207_1, reinterpret_tensor(buf316, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg206_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf320)
        del arg206_1
        del arg207_1
        # Topologically Sorted Source Nodes: [linear_100, view_45, value_states_14, index_copy__29], Original ATen: [aten.view, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_index_copy_transpose_view_2.run(arg0_1, buf320, arg209_1, 256, stream=raw_stream0)
        del buf320
        buf322 = reinterpret_tensor(buf316, (1, 12, 1, 128), (1536, 128, 128, 1), 0); del buf316  # reuse
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, linear_98, view_43, query_states_14, cos_17, mul_130, x2_28, neg_28, x1_28, cat_29, sin_17, mul_131, q_embed_14, key_14, value_14, attn_output_56], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.clone, aten._unsafe_view, aten._scaled_dot_product_efficient_attention]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_efficient_attention__to_copy__unsafe_view_add_bmm_cat_clone_expand_mul_neg_slice_transpose_unsqueeze_view_3.run(buf317, arg4_1, arg0_1, buf322, 1536, stream=raw_stream0)
        buf323 = buf301; del buf301  # reuse
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, linear_98, view_43, query_states_14, cos_17, mul_130, x2_28, neg_28, x1_28, cat_29, sin_17, mul_131, q_embed_14, key_14, value_14, attn_output_56], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.clone, aten._unsafe_view, aten._scaled_dot_product_efficient_attention]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_efficient_attention__to_copy__unsafe_view_add_bmm_cat_clone_expand_mul_neg_slice_transpose_unsqueeze_view_4.run(arg208_1, buf323, 294912, stream=raw_stream0)
        del arg208_1
        buf324 = empty_strided_cuda((1, 12, 192, 128), (294912, 24576, 128, 1), torch.float16)
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, linear_98, view_43, query_states_14, cos_17, mul_130, x2_28, neg_28, x1_28, cat_29, sin_17, mul_131, q_embed_14, key_14, value_14, attn_output_56], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.clone, aten._unsafe_view, aten._scaled_dot_product_efficient_attention]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_efficient_attention__to_copy__unsafe_view_add_bmm_cat_clone_expand_mul_neg_slice_transpose_unsqueeze_view_4.run(arg209_1, buf324, 294912, stream=raw_stream0)
        del arg209_1
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, linear_98, view_43, query_states_14, cos_17, mul_130, x2_28, neg_28, x1_28, cat_29, sin_17, mul_131, q_embed_14, key_14, value_14, attn_output_56], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.clone, aten._unsafe_view, aten._scaled_dot_product_efficient_attention]
        buf325 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf322, buf323, buf324, reinterpret_tensor(arg3_1, (1, 12, 1, 192), (192, 0, 192, 1), 0), False, scale=0.08838834764831845)
        del buf323
        buf326 = buf325[0]
        assert_tensor_metadata(buf326, (1, 12, 1, 128), (1536, 128, 1536, 1), torch.float16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
        assert_alignment(buf326, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
        del buf325
        buf330 = reinterpret_tensor(buf322, (1, 1536), (1536, 1), 0); del buf322  # reuse
        # Topologically Sorted Source Nodes: [transpose_60, reshape_44, attn_output_59], Original ATen: [aten.transpose, aten.view, aten.t, aten.mm]
        extern_kernels.mm(reinterpret_tensor(buf326, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg210_1, (1536, 1536), (1, 1536), 0), out=buf330)
        del arg210_1
        buf332 = reinterpret_tensor(buf326, (1, 1, 1536), (1536, 1536, 1), 0); del buf326  # reuse
        # Topologically Sorted Source Nodes: [down_proj_13, hidden_states_139, attn_output_59, hidden_states_145, hidden_states_146, pow_30, variance_29, add_88, rsqrt_29, hidden_states_147, to_62, hidden_states_148], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_10.run(buf308, buf314, buf330, arg211_1, buf332, 1, 1536, stream=raw_stream0)
        del arg211_1
        buf333 = empty_strided_cuda((1, 8960), (8960, 1), torch.float16)
        # Topologically Sorted Source Nodes: [linear_102], Original ATen: [aten.view, aten.t, aten.mm]
        extern_kernels.mm(reinterpret_tensor(buf332, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg212_1, (1536, 8960), (1, 1536), 0), out=buf333)
        del arg212_1
        buf334 = empty_strided_cuda((1, 8960), (8960, 1), torch.float16)
        # Topologically Sorted Source Nodes: [linear_103], Original ATen: [aten.view, aten.t, aten.mm]
        extern_kernels.mm(reinterpret_tensor(buf332, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg213_1, (1536, 8960), (1, 1536), 0), out=buf334)
        del arg213_1
        buf335 = reinterpret_tensor(buf333, (1, 1, 8960), (8960, 8960, 1), 0); del buf333  # reuse
        # Topologically Sorted Source Nodes: [linear_102, silu_14, linear_103, mul_136], Original ATen: [aten._unsafe_view, aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_mul_silu_6.run(buf335, buf334, 8960, stream=raw_stream0)
        del buf334
        buf336 = reinterpret_tensor(buf332, (1, 1536), (1536, 1), 0); del buf332  # reuse
        # Topologically Sorted Source Nodes: [linear_102, silu_14, linear_103, mul_136, down_proj_14], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
        extern_kernels.mm(reinterpret_tensor(buf335, (1, 8960), (0, 1), 0), reinterpret_tensor(arg214_1, (8960, 1536), (1, 8960), 0), out=buf336)
        del arg214_1
        del buf335
        buf338 = reinterpret_tensor(buf317, (1, 1, 1536), (1536, 1536, 1), 0); del buf317  # reuse
        # Topologically Sorted Source Nodes: [down_proj_13, hidden_states_139, attn_output_59, hidden_states_145, down_proj_14, hidden_states_149, hidden_states_150, pow_31, variance_30, add_90, rsqrt_30, hidden_states_151, to_64, hidden_states_152], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_11.run(buf308, buf314, buf330, buf336, arg215_1, buf338, 1, 1536, stream=raw_stream0)
        del arg215_1
        buf339 = buf285; del buf285  # reuse
        # Topologically Sorted Source Nodes: [linear_105], Original ATen: [aten.view, aten.t, aten.addmm]
        extern_kernels.addmm(arg217_1, reinterpret_tensor(buf338, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg216_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf339)
        del arg216_1
        del arg217_1
        buf340 = empty_strided_cuda((1, 256), (256, 1), torch.float16)
        # Topologically Sorted Source Nodes: [linear_106], Original ATen: [aten.view, aten.t, aten.addmm]
        extern_kernels.addmm(arg219_1, reinterpret_tensor(buf338, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg218_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf340)
        del arg218_1
        del arg219_1
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, cos_18, sin_18, linear_106, view_47, key_states_15, mul_141, x2_31, neg_31, x1_31, cat_32, mul_142, k_embed_15, index_copy__30], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_bmm_cat_expand_index_copy_mul_neg_slice_transpose_unsqueeze_view_1.run(arg0_1, buf340, arg4_1, arg222_1, 256, stream=raw_stream0)
        buf342 = buf340; del buf340  # reuse
        # Topologically Sorted Source Nodes: [linear_107], Original ATen: [aten.view, aten.t, aten.addmm]
        extern_kernels.addmm(arg221_1, reinterpret_tensor(buf338, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg220_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf342)
        del arg220_1
        del arg221_1
        # Topologically Sorted Source Nodes: [linear_107, view_48, value_states_15, index_copy__31], Original ATen: [aten.view, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_index_copy_transpose_view_2.run(arg0_1, buf342, arg223_1, 256, stream=raw_stream0)
        del buf342
        buf344 = reinterpret_tensor(buf338, (1, 12, 1, 128), (1536, 128, 128, 1), 0); del buf338  # reuse
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, linear_105, view_46, query_states_15, cos_18, mul_139, x2_30, neg_30, x1_30, cat_31, sin_18, mul_140, q_embed_15, key_15, value_15, attn_output_60], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.clone, aten._unsafe_view, aten._scaled_dot_product_efficient_attention]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_efficient_attention__to_copy__unsafe_view_add_bmm_cat_clone_expand_mul_neg_slice_transpose_unsqueeze_view_3.run(buf339, arg4_1, arg0_1, buf344, 1536, stream=raw_stream0)
        del buf339
        buf345 = buf324; del buf324  # reuse
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, linear_105, view_46, query_states_15, cos_18, mul_139, x2_30, neg_30, x1_30, cat_31, sin_18, mul_140, q_embed_15, key_15, value_15, attn_output_60], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.clone, aten._unsafe_view, aten._scaled_dot_product_efficient_attention]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_efficient_attention__to_copy__unsafe_view_add_bmm_cat_clone_expand_mul_neg_slice_transpose_unsqueeze_view_4.run(arg222_1, buf345, 294912, stream=raw_stream0)
        del arg222_1
        buf346 = empty_strided_cuda((1, 12, 192, 128), (294912, 24576, 128, 1), torch.float16)
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, linear_105, view_46, query_states_15, cos_18, mul_139, x2_30, neg_30, x1_30, cat_31, sin_18, mul_140, q_embed_15, key_15, value_15, attn_output_60], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.clone, aten._unsafe_view, aten._scaled_dot_product_efficient_attention]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_efficient_attention__to_copy__unsafe_view_add_bmm_cat_clone_expand_mul_neg_slice_transpose_unsqueeze_view_4.run(arg223_1, buf346, 294912, stream=raw_stream0)
        del arg223_1
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, linear_105, view_46, query_states_15, cos_18, mul_139, x2_30, neg_30, x1_30, cat_31, sin_18, mul_140, q_embed_15, key_15, value_15, attn_output_60], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.clone, aten._unsafe_view, aten._scaled_dot_product_efficient_attention]
        buf347 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf344, buf345, buf346, reinterpret_tensor(arg3_1, (1, 12, 1, 192), (192, 0, 192, 1), 0), False, scale=0.08838834764831845)
        del buf345
        buf348 = buf347[0]
        assert_tensor_metadata(buf348, (1, 12, 1, 128), (1536, 128, 1536, 1), torch.float16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
        assert_alignment(buf348, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
        del buf347
        buf352 = reinterpret_tensor(buf344, (1, 1536), (1536, 1), 0); del buf344  # reuse
        # Topologically Sorted Source Nodes: [transpose_64, reshape_47, attn_output_63], Original ATen: [aten.transpose, aten.view, aten.t, aten.mm]
        extern_kernels.mm(reinterpret_tensor(buf348, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg224_1, (1536, 1536), (1, 1536), 0), out=buf352)
        del arg224_1
        buf353 = buf308; del buf308  # reuse
        buf355 = reinterpret_tensor(buf348, (1, 1, 1536), (1536, 1536, 1), 0); del buf348  # reuse
        # Topologically Sorted Source Nodes: [down_proj_13, hidden_states_139, attn_output_59, hidden_states_145, down_proj_14, hidden_states_149, attn_output_63, hidden_states_155, hidden_states_156, pow_32, variance_31, add_94, rsqrt_31, hidden_states_157, to_66, hidden_states_158], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_12.run(buf353, buf314, buf330, buf336, buf352, arg225_1, buf355, 1, 1536, stream=raw_stream0)
        del arg225_1
        del buf314
        buf356 = empty_strided_cuda((1, 8960), (8960, 1), torch.float16)
        # Topologically Sorted Source Nodes: [hidden_states_156, pow_32, variance_31, add_94, rsqrt_31, hidden_states_157, to_66, hidden_states_158, linear_109], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
        extern_kernels.mm(reinterpret_tensor(buf355, (1, 1536), (0, 1), 0), reinterpret_tensor(arg226_1, (1536, 8960), (1, 1536), 0), out=buf356)
        del arg226_1
        buf357 = empty_strided_cuda((1, 8960), (8960, 1), torch.float16)
        # Topologically Sorted Source Nodes: [linear_110], Original ATen: [aten.view, aten.t, aten.mm]
        extern_kernels.mm(reinterpret_tensor(buf355, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg227_1, (1536, 8960), (1, 1536), 0), out=buf357)
        del arg227_1
        buf358 = reinterpret_tensor(buf356, (1, 1, 8960), (8960, 8960, 1), 0); del buf356  # reuse
        # Topologically Sorted Source Nodes: [linear_109, silu_15, linear_110, mul_145], Original ATen: [aten._unsafe_view, aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_mul_silu_6.run(buf358, buf357, 8960, stream=raw_stream0)
        del buf357
        buf359 = reinterpret_tensor(buf355, (1, 1536), (1536, 1), 0); del buf355  # reuse
        # Topologically Sorted Source Nodes: [linear_109, silu_15, linear_110, mul_145, down_proj_15], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
        extern_kernels.mm(reinterpret_tensor(buf358, (1, 8960), (0, 1), 0), reinterpret_tensor(arg228_1, (8960, 1536), (1, 8960), 0), out=buf359)
        del arg228_1
        del buf358
        buf361 = reinterpret_tensor(buf352, (1, 1, 1536), (1536, 1536, 1), 0); del buf352  # reuse
        # Topologically Sorted Source Nodes: [down_proj_15, hidden_states_159, hidden_states_160, pow_33, variance_32, add_96, rsqrt_32, hidden_states_161, to_68, hidden_states_162], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_9.run(buf353, buf359, arg229_1, buf361, 1, 1536, stream=raw_stream0)
        del arg229_1
        buf362 = buf336; del buf336  # reuse
        # Topologically Sorted Source Nodes: [down_proj_15, hidden_states_159, hidden_states_160, pow_33, variance_32, add_96, rsqrt_32, hidden_states_161, to_68, hidden_states_162, linear_112], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.addmm]
        extern_kernels.addmm(arg231_1, reinterpret_tensor(buf361, (1, 1536), (0, 1), 0), reinterpret_tensor(arg230_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf362)
        del arg230_1
        del arg231_1
        buf363 = empty_strided_cuda((1, 256), (256, 1), torch.float16)
        # Topologically Sorted Source Nodes: [linear_113], Original ATen: [aten.view, aten.t, aten.addmm]
        extern_kernels.addmm(arg233_1, reinterpret_tensor(buf361, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg232_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf363)
        del arg232_1
        del arg233_1
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, cos_19, sin_19, linear_113, view_50, key_states_16, mul_150, x2_33, neg_33, x1_33, cat_34, mul_151, k_embed_16, index_copy__32], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_bmm_cat_expand_index_copy_mul_neg_slice_transpose_unsqueeze_view_1.run(arg0_1, buf363, arg4_1, arg236_1, 256, stream=raw_stream0)
        buf365 = buf363; del buf363  # reuse
        # Topologically Sorted Source Nodes: [linear_114], Original ATen: [aten.view, aten.t, aten.addmm]
        extern_kernels.addmm(arg235_1, reinterpret_tensor(buf361, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg234_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf365)
        del arg234_1
        del arg235_1
        # Topologically Sorted Source Nodes: [linear_114, view_51, value_states_16, index_copy__33], Original ATen: [aten.view, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_index_copy_transpose_view_2.run(arg0_1, buf365, arg237_1, 256, stream=raw_stream0)
        del buf365
        buf367 = reinterpret_tensor(buf361, (1, 12, 1, 128), (1536, 128, 128, 1), 0); del buf361  # reuse
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, linear_112, view_49, query_states_16, cos_19, mul_148, x2_32, neg_32, x1_32, cat_33, sin_19, mul_149, q_embed_16, key_16, value_16, attn_output_64], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.clone, aten._unsafe_view, aten._scaled_dot_product_efficient_attention]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_efficient_attention__to_copy__unsafe_view_add_bmm_cat_clone_expand_mul_neg_slice_transpose_unsqueeze_view_3.run(buf362, arg4_1, arg0_1, buf367, 1536, stream=raw_stream0)
        buf368 = buf346; del buf346  # reuse
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, linear_112, view_49, query_states_16, cos_19, mul_148, x2_32, neg_32, x1_32, cat_33, sin_19, mul_149, q_embed_16, key_16, value_16, attn_output_64], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.clone, aten._unsafe_view, aten._scaled_dot_product_efficient_attention]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_efficient_attention__to_copy__unsafe_view_add_bmm_cat_clone_expand_mul_neg_slice_transpose_unsqueeze_view_4.run(arg236_1, buf368, 294912, stream=raw_stream0)
        del arg236_1
        buf369 = empty_strided_cuda((1, 12, 192, 128), (294912, 24576, 128, 1), torch.float16)
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, linear_112, view_49, query_states_16, cos_19, mul_148, x2_32, neg_32, x1_32, cat_33, sin_19, mul_149, q_embed_16, key_16, value_16, attn_output_64], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.clone, aten._unsafe_view, aten._scaled_dot_product_efficient_attention]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_efficient_attention__to_copy__unsafe_view_add_bmm_cat_clone_expand_mul_neg_slice_transpose_unsqueeze_view_4.run(arg237_1, buf369, 294912, stream=raw_stream0)
        del arg237_1
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, linear_112, view_49, query_states_16, cos_19, mul_148, x2_32, neg_32, x1_32, cat_33, sin_19, mul_149, q_embed_16, key_16, value_16, attn_output_64], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.clone, aten._unsafe_view, aten._scaled_dot_product_efficient_attention]
        buf370 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf367, buf368, buf369, reinterpret_tensor(arg3_1, (1, 12, 1, 192), (192, 0, 192, 1), 0), False, scale=0.08838834764831845)
        del buf368
        buf371 = buf370[0]
        assert_tensor_metadata(buf371, (1, 12, 1, 128), (1536, 128, 1536, 1), torch.float16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
        assert_alignment(buf371, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
        del buf370
        buf375 = reinterpret_tensor(buf367, (1, 1536), (1536, 1), 0); del buf367  # reuse
        # Topologically Sorted Source Nodes: [transpose_68, reshape_50, attn_output_67], Original ATen: [aten.transpose, aten.view, aten.t, aten.mm]
        extern_kernels.mm(reinterpret_tensor(buf371, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg238_1, (1536, 1536), (1, 1536), 0), out=buf375)
        del arg238_1
        buf377 = reinterpret_tensor(buf371, (1, 1, 1536), (1536, 1536, 1), 0); del buf371  # reuse
        # Topologically Sorted Source Nodes: [down_proj_15, hidden_states_159, attn_output_67, hidden_states_165, hidden_states_166, pow_34, variance_33, add_100, rsqrt_33, hidden_states_167, to_70, hidden_states_168], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_10.run(buf353, buf359, buf375, arg239_1, buf377, 1, 1536, stream=raw_stream0)
        del arg239_1
        buf378 = empty_strided_cuda((1, 8960), (8960, 1), torch.float16)
        # Topologically Sorted Source Nodes: [linear_116], Original ATen: [aten.view, aten.t, aten.mm]
        extern_kernels.mm(reinterpret_tensor(buf377, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg240_1, (1536, 8960), (1, 1536), 0), out=buf378)
        del arg240_1
        buf379 = empty_strided_cuda((1, 8960), (8960, 1), torch.float16)
        # Topologically Sorted Source Nodes: [linear_117], Original ATen: [aten.view, aten.t, aten.mm]
        extern_kernels.mm(reinterpret_tensor(buf377, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg241_1, (1536, 8960), (1, 1536), 0), out=buf379)
        del arg241_1
        buf380 = reinterpret_tensor(buf378, (1, 1, 8960), (8960, 8960, 1), 0); del buf378  # reuse
        # Topologically Sorted Source Nodes: [linear_116, silu_16, linear_117, mul_154], Original ATen: [aten._unsafe_view, aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_mul_silu_6.run(buf380, buf379, 8960, stream=raw_stream0)
        del buf379
        buf381 = reinterpret_tensor(buf377, (1, 1536), (1536, 1), 0); del buf377  # reuse
        # Topologically Sorted Source Nodes: [linear_116, silu_16, linear_117, mul_154, down_proj_16], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
        extern_kernels.mm(reinterpret_tensor(buf380, (1, 8960), (0, 1), 0), reinterpret_tensor(arg242_1, (8960, 1536), (1, 8960), 0), out=buf381)
        del arg242_1
        del buf380
        buf383 = reinterpret_tensor(buf362, (1, 1, 1536), (1536, 1536, 1), 0); del buf362  # reuse
        # Topologically Sorted Source Nodes: [down_proj_15, hidden_states_159, attn_output_67, hidden_states_165, down_proj_16, hidden_states_169, hidden_states_170, pow_35, variance_34, add_102, rsqrt_34, hidden_states_171, to_72, hidden_states_172], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_11.run(buf353, buf359, buf375, buf381, arg243_1, buf383, 1, 1536, stream=raw_stream0)
        del arg243_1
        buf384 = buf330; del buf330  # reuse
        # Topologically Sorted Source Nodes: [linear_119], Original ATen: [aten.view, aten.t, aten.addmm]
        extern_kernels.addmm(arg245_1, reinterpret_tensor(buf383, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg244_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf384)
        del arg244_1
        del arg245_1
        buf385 = empty_strided_cuda((1, 256), (256, 1), torch.float16)
        # Topologically Sorted Source Nodes: [linear_120], Original ATen: [aten.view, aten.t, aten.addmm]
        extern_kernels.addmm(arg247_1, reinterpret_tensor(buf383, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg246_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf385)
        del arg246_1
        del arg247_1
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, cos_20, sin_20, linear_120, view_53, key_states_17, mul_159, x2_35, neg_35, x1_35, cat_36, mul_160, k_embed_17, index_copy__34], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_bmm_cat_expand_index_copy_mul_neg_slice_transpose_unsqueeze_view_1.run(arg0_1, buf385, arg4_1, arg250_1, 256, stream=raw_stream0)
        buf387 = buf385; del buf385  # reuse
        # Topologically Sorted Source Nodes: [linear_121], Original ATen: [aten.view, aten.t, aten.addmm]
        extern_kernels.addmm(arg249_1, reinterpret_tensor(buf383, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg248_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf387)
        del arg248_1
        del arg249_1
        # Topologically Sorted Source Nodes: [linear_121, view_54, value_states_17, index_copy__35], Original ATen: [aten.view, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_index_copy_transpose_view_2.run(arg0_1, buf387, arg251_1, 256, stream=raw_stream0)
        del buf387
        buf389 = reinterpret_tensor(buf383, (1, 12, 1, 128), (1536, 128, 128, 1), 0); del buf383  # reuse
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, linear_119, view_52, query_states_17, cos_20, mul_157, x2_34, neg_34, x1_34, cat_35, sin_20, mul_158, q_embed_17, key_17, value_17, attn_output_68], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.clone, aten._unsafe_view, aten._scaled_dot_product_efficient_attention]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_efficient_attention__to_copy__unsafe_view_add_bmm_cat_clone_expand_mul_neg_slice_transpose_unsqueeze_view_3.run(buf384, arg4_1, arg0_1, buf389, 1536, stream=raw_stream0)
        del buf384
        buf390 = buf369; del buf369  # reuse
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, linear_119, view_52, query_states_17, cos_20, mul_157, x2_34, neg_34, x1_34, cat_35, sin_20, mul_158, q_embed_17, key_17, value_17, attn_output_68], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.clone, aten._unsafe_view, aten._scaled_dot_product_efficient_attention]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_efficient_attention__to_copy__unsafe_view_add_bmm_cat_clone_expand_mul_neg_slice_transpose_unsqueeze_view_4.run(arg250_1, buf390, 294912, stream=raw_stream0)
        del arg250_1
        buf391 = empty_strided_cuda((1, 12, 192, 128), (294912, 24576, 128, 1), torch.float16)
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, linear_119, view_52, query_states_17, cos_20, mul_157, x2_34, neg_34, x1_34, cat_35, sin_20, mul_158, q_embed_17, key_17, value_17, attn_output_68], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.clone, aten._unsafe_view, aten._scaled_dot_product_efficient_attention]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_efficient_attention__to_copy__unsafe_view_add_bmm_cat_clone_expand_mul_neg_slice_transpose_unsqueeze_view_4.run(arg251_1, buf391, 294912, stream=raw_stream0)
        del arg251_1
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, linear_119, view_52, query_states_17, cos_20, mul_157, x2_34, neg_34, x1_34, cat_35, sin_20, mul_158, q_embed_17, key_17, value_17, attn_output_68], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.clone, aten._unsafe_view, aten._scaled_dot_product_efficient_attention]
        buf392 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf389, buf390, buf391, reinterpret_tensor(arg3_1, (1, 12, 1, 192), (192, 0, 192, 1), 0), False, scale=0.08838834764831845)
        del buf390
        buf393 = buf392[0]
        assert_tensor_metadata(buf393, (1, 12, 1, 128), (1536, 128, 1536, 1), torch.float16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
        assert_alignment(buf393, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
        del buf392
        buf397 = reinterpret_tensor(buf389, (1, 1536), (1536, 1), 0); del buf389  # reuse
        # Topologically Sorted Source Nodes: [transpose_72, reshape_53, attn_output_71], Original ATen: [aten.transpose, aten.view, aten.t, aten.mm]
        extern_kernels.mm(reinterpret_tensor(buf393, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg252_1, (1536, 1536), (1, 1536), 0), out=buf397)
        del arg252_1
        buf398 = buf353; del buf353  # reuse
        buf400 = reinterpret_tensor(buf393, (1, 1, 1536), (1536, 1536, 1), 0); del buf393  # reuse
        # Topologically Sorted Source Nodes: [down_proj_15, hidden_states_159, attn_output_67, hidden_states_165, down_proj_16, hidden_states_169, attn_output_71, hidden_states_175, hidden_states_176, pow_36, variance_35, add_106, rsqrt_35, hidden_states_177, to_74, hidden_states_178], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_12.run(buf398, buf359, buf375, buf381, buf397, arg253_1, buf400, 1, 1536, stream=raw_stream0)
        del arg253_1
        del buf359
        buf401 = empty_strided_cuda((1, 8960), (8960, 1), torch.float16)
        # Topologically Sorted Source Nodes: [hidden_states_176, pow_36, variance_35, add_106, rsqrt_35, hidden_states_177, to_74, hidden_states_178, linear_123], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
        extern_kernels.mm(reinterpret_tensor(buf400, (1, 1536), (0, 1), 0), reinterpret_tensor(arg254_1, (1536, 8960), (1, 1536), 0), out=buf401)
        del arg254_1
        buf402 = empty_strided_cuda((1, 8960), (8960, 1), torch.float16)
        # Topologically Sorted Source Nodes: [linear_124], Original ATen: [aten.view, aten.t, aten.mm]
        extern_kernels.mm(reinterpret_tensor(buf400, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg255_1, (1536, 8960), (1, 1536), 0), out=buf402)
        del arg255_1
        buf403 = reinterpret_tensor(buf401, (1, 1, 8960), (8960, 8960, 1), 0); del buf401  # reuse
        # Topologically Sorted Source Nodes: [linear_123, silu_17, linear_124, mul_163], Original ATen: [aten._unsafe_view, aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_mul_silu_6.run(buf403, buf402, 8960, stream=raw_stream0)
        del buf402
        buf404 = reinterpret_tensor(buf400, (1, 1536), (1536, 1), 0); del buf400  # reuse
        # Topologically Sorted Source Nodes: [linear_123, silu_17, linear_124, mul_163, down_proj_17], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
        extern_kernels.mm(reinterpret_tensor(buf403, (1, 8960), (0, 1), 0), reinterpret_tensor(arg256_1, (8960, 1536), (1, 8960), 0), out=buf404)
        del arg256_1
        del buf403
        buf406 = reinterpret_tensor(buf397, (1, 1, 1536), (1536, 1536, 1), 0); del buf397  # reuse
        # Topologically Sorted Source Nodes: [down_proj_17, hidden_states_179, hidden_states_180, pow_37, variance_36, add_108, rsqrt_36, hidden_states_181, to_76, hidden_states_182], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_9.run(buf398, buf404, arg257_1, buf406, 1, 1536, stream=raw_stream0)
        del arg257_1
        buf407 = buf381; del buf381  # reuse
        # Topologically Sorted Source Nodes: [down_proj_17, hidden_states_179, hidden_states_180, pow_37, variance_36, add_108, rsqrt_36, hidden_states_181, to_76, hidden_states_182, linear_126], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.addmm]
        extern_kernels.addmm(arg259_1, reinterpret_tensor(buf406, (1, 1536), (0, 1), 0), reinterpret_tensor(arg258_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf407)
        del arg258_1
        del arg259_1
        buf408 = empty_strided_cuda((1, 256), (256, 1), torch.float16)
        # Topologically Sorted Source Nodes: [linear_127], Original ATen: [aten.view, aten.t, aten.addmm]
        extern_kernels.addmm(arg261_1, reinterpret_tensor(buf406, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg260_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf408)
        del arg260_1
        del arg261_1
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, cos_21, sin_21, linear_127, view_56, key_states_18, mul_168, x2_37, neg_37, x1_37, cat_38, mul_169, k_embed_18, index_copy__36], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_bmm_cat_expand_index_copy_mul_neg_slice_transpose_unsqueeze_view_1.run(arg0_1, buf408, arg4_1, arg264_1, 256, stream=raw_stream0)
        buf410 = buf408; del buf408  # reuse
        # Topologically Sorted Source Nodes: [linear_128], Original ATen: [aten.view, aten.t, aten.addmm]
        extern_kernels.addmm(arg263_1, reinterpret_tensor(buf406, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg262_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf410)
        del arg262_1
        del arg263_1
        # Topologically Sorted Source Nodes: [linear_128, view_57, value_states_18, index_copy__37], Original ATen: [aten.view, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_index_copy_transpose_view_2.run(arg0_1, buf410, arg265_1, 256, stream=raw_stream0)
        del buf410
        buf412 = reinterpret_tensor(buf406, (1, 12, 1, 128), (1536, 128, 128, 1), 0); del buf406  # reuse
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, linear_126, view_55, query_states_18, cos_21, mul_166, x2_36, neg_36, x1_36, cat_37, sin_21, mul_167, q_embed_18, key_18, value_18, attn_output_72], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.clone, aten._unsafe_view, aten._scaled_dot_product_efficient_attention]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_efficient_attention__to_copy__unsafe_view_add_bmm_cat_clone_expand_mul_neg_slice_transpose_unsqueeze_view_3.run(buf407, arg4_1, arg0_1, buf412, 1536, stream=raw_stream0)
        buf413 = buf391; del buf391  # reuse
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, linear_126, view_55, query_states_18, cos_21, mul_166, x2_36, neg_36, x1_36, cat_37, sin_21, mul_167, q_embed_18, key_18, value_18, attn_output_72], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.clone, aten._unsafe_view, aten._scaled_dot_product_efficient_attention]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_efficient_attention__to_copy__unsafe_view_add_bmm_cat_clone_expand_mul_neg_slice_transpose_unsqueeze_view_4.run(arg264_1, buf413, 294912, stream=raw_stream0)
        del arg264_1
        buf414 = empty_strided_cuda((1, 12, 192, 128), (294912, 24576, 128, 1), torch.float16)
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, linear_126, view_55, query_states_18, cos_21, mul_166, x2_36, neg_36, x1_36, cat_37, sin_21, mul_167, q_embed_18, key_18, value_18, attn_output_72], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.clone, aten._unsafe_view, aten._scaled_dot_product_efficient_attention]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_efficient_attention__to_copy__unsafe_view_add_bmm_cat_clone_expand_mul_neg_slice_transpose_unsqueeze_view_4.run(arg265_1, buf414, 294912, stream=raw_stream0)
        del arg265_1
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, linear_126, view_55, query_states_18, cos_21, mul_166, x2_36, neg_36, x1_36, cat_37, sin_21, mul_167, q_embed_18, key_18, value_18, attn_output_72], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.clone, aten._unsafe_view, aten._scaled_dot_product_efficient_attention]
        buf415 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf412, buf413, buf414, reinterpret_tensor(arg3_1, (1, 12, 1, 192), (192, 0, 192, 1), 0), False, scale=0.08838834764831845)
        del buf413
        buf416 = buf415[0]
        assert_tensor_metadata(buf416, (1, 12, 1, 128), (1536, 128, 1536, 1), torch.float16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
        assert_alignment(buf416, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
        del buf415
        buf420 = reinterpret_tensor(buf412, (1, 1536), (1536, 1), 0); del buf412  # reuse
        # Topologically Sorted Source Nodes: [transpose_76, reshape_56, attn_output_75], Original ATen: [aten.transpose, aten.view, aten.t, aten.mm]
        extern_kernels.mm(reinterpret_tensor(buf416, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg266_1, (1536, 1536), (1, 1536), 0), out=buf420)
        del arg266_1
        buf422 = reinterpret_tensor(buf416, (1, 1, 1536), (1536, 1536, 1), 0); del buf416  # reuse
        # Topologically Sorted Source Nodes: [down_proj_17, hidden_states_179, attn_output_75, hidden_states_185, hidden_states_186, pow_38, variance_37, add_112, rsqrt_37, hidden_states_187, to_78, hidden_states_188], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_10.run(buf398, buf404, buf420, arg267_1, buf422, 1, 1536, stream=raw_stream0)
        del arg267_1
        buf423 = empty_strided_cuda((1, 8960), (8960, 1), torch.float16)
        # Topologically Sorted Source Nodes: [linear_130], Original ATen: [aten.view, aten.t, aten.mm]
        extern_kernels.mm(reinterpret_tensor(buf422, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg268_1, (1536, 8960), (1, 1536), 0), out=buf423)
        del arg268_1
        buf424 = empty_strided_cuda((1, 8960), (8960, 1), torch.float16)
        # Topologically Sorted Source Nodes: [linear_131], Original ATen: [aten.view, aten.t, aten.mm]
        extern_kernels.mm(reinterpret_tensor(buf422, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg269_1, (1536, 8960), (1, 1536), 0), out=buf424)
        del arg269_1
        buf425 = reinterpret_tensor(buf423, (1, 1, 8960), (8960, 8960, 1), 0); del buf423  # reuse
        # Topologically Sorted Source Nodes: [linear_130, silu_18, linear_131, mul_172], Original ATen: [aten._unsafe_view, aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_mul_silu_6.run(buf425, buf424, 8960, stream=raw_stream0)
        del buf424
        buf426 = reinterpret_tensor(buf422, (1, 1536), (1536, 1), 0); del buf422  # reuse
        # Topologically Sorted Source Nodes: [linear_130, silu_18, linear_131, mul_172, down_proj_18], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
        extern_kernels.mm(reinterpret_tensor(buf425, (1, 8960), (0, 1), 0), reinterpret_tensor(arg270_1, (8960, 1536), (1, 8960), 0), out=buf426)
        del arg270_1
        del buf425
        buf428 = reinterpret_tensor(buf407, (1, 1, 1536), (1536, 1536, 1), 0); del buf407  # reuse
        # Topologically Sorted Source Nodes: [down_proj_17, hidden_states_179, attn_output_75, hidden_states_185, down_proj_18, hidden_states_189, hidden_states_190, pow_39, variance_38, add_114, rsqrt_38, hidden_states_191, to_80, hidden_states_192], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_11.run(buf398, buf404, buf420, buf426, arg271_1, buf428, 1, 1536, stream=raw_stream0)
        del arg271_1
        buf429 = buf375; del buf375  # reuse
        # Topologically Sorted Source Nodes: [linear_133], Original ATen: [aten.view, aten.t, aten.addmm]
        extern_kernels.addmm(arg273_1, reinterpret_tensor(buf428, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg272_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf429)
        del arg272_1
        del arg273_1
        buf430 = empty_strided_cuda((1, 256), (256, 1), torch.float16)
        # Topologically Sorted Source Nodes: [linear_134], Original ATen: [aten.view, aten.t, aten.addmm]
        extern_kernels.addmm(arg275_1, reinterpret_tensor(buf428, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg274_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf430)
        del arg274_1
        del arg275_1
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, cos_22, sin_22, linear_134, view_59, key_states_19, mul_177, x2_39, neg_39, x1_39, cat_40, mul_178, k_embed_19, index_copy__38], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_bmm_cat_expand_index_copy_mul_neg_slice_transpose_unsqueeze_view_1.run(arg0_1, buf430, arg4_1, arg278_1, 256, stream=raw_stream0)
        buf432 = buf430; del buf430  # reuse
        # Topologically Sorted Source Nodes: [linear_135], Original ATen: [aten.view, aten.t, aten.addmm]
        extern_kernels.addmm(arg277_1, reinterpret_tensor(buf428, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg276_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf432)
        del arg276_1
        del arg277_1
        # Topologically Sorted Source Nodes: [linear_135, view_60, value_states_19, index_copy__39], Original ATen: [aten.view, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_index_copy_transpose_view_2.run(arg0_1, buf432, arg279_1, 256, stream=raw_stream0)
        del buf432
        buf434 = reinterpret_tensor(buf428, (1, 12, 1, 128), (1536, 128, 128, 1), 0); del buf428  # reuse
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, linear_133, view_58, query_states_19, cos_22, mul_175, x2_38, neg_38, x1_38, cat_39, sin_22, mul_176, q_embed_19, key_19, value_19, attn_output_76], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.clone, aten._unsafe_view, aten._scaled_dot_product_efficient_attention]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_efficient_attention__to_copy__unsafe_view_add_bmm_cat_clone_expand_mul_neg_slice_transpose_unsqueeze_view_3.run(buf429, arg4_1, arg0_1, buf434, 1536, stream=raw_stream0)
        del buf429
        buf435 = buf414; del buf414  # reuse
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, linear_133, view_58, query_states_19, cos_22, mul_175, x2_38, neg_38, x1_38, cat_39, sin_22, mul_176, q_embed_19, key_19, value_19, attn_output_76], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.clone, aten._unsafe_view, aten._scaled_dot_product_efficient_attention]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_efficient_attention__to_copy__unsafe_view_add_bmm_cat_clone_expand_mul_neg_slice_transpose_unsqueeze_view_4.run(arg278_1, buf435, 294912, stream=raw_stream0)
        del arg278_1
        buf436 = empty_strided_cuda((1, 12, 192, 128), (294912, 24576, 128, 1), torch.float16)
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, linear_133, view_58, query_states_19, cos_22, mul_175, x2_38, neg_38, x1_38, cat_39, sin_22, mul_176, q_embed_19, key_19, value_19, attn_output_76], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.clone, aten._unsafe_view, aten._scaled_dot_product_efficient_attention]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_efficient_attention__to_copy__unsafe_view_add_bmm_cat_clone_expand_mul_neg_slice_transpose_unsqueeze_view_4.run(arg279_1, buf436, 294912, stream=raw_stream0)
        del arg279_1
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, linear_133, view_58, query_states_19, cos_22, mul_175, x2_38, neg_38, x1_38, cat_39, sin_22, mul_176, q_embed_19, key_19, value_19, attn_output_76], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.clone, aten._unsafe_view, aten._scaled_dot_product_efficient_attention]
        buf437 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf434, buf435, buf436, reinterpret_tensor(arg3_1, (1, 12, 1, 192), (192, 0, 192, 1), 0), False, scale=0.08838834764831845)
        del buf435
        buf438 = buf437[0]
        assert_tensor_metadata(buf438, (1, 12, 1, 128), (1536, 128, 1536, 1), torch.float16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
        assert_alignment(buf438, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
        del buf437
        buf442 = reinterpret_tensor(buf434, (1, 1536), (1536, 1), 0); del buf434  # reuse
        # Topologically Sorted Source Nodes: [transpose_80, reshape_59, attn_output_79], Original ATen: [aten.transpose, aten.view, aten.t, aten.mm]
        extern_kernels.mm(reinterpret_tensor(buf438, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg280_1, (1536, 1536), (1, 1536), 0), out=buf442)
        del arg280_1
        buf443 = buf398; del buf398  # reuse
        buf445 = reinterpret_tensor(buf438, (1, 1, 1536), (1536, 1536, 1), 0); del buf438  # reuse
        # Topologically Sorted Source Nodes: [down_proj_17, hidden_states_179, attn_output_75, hidden_states_185, down_proj_18, hidden_states_189, attn_output_79, hidden_states_195, hidden_states_196, pow_40, variance_39, add_118, rsqrt_39, hidden_states_197, to_82, hidden_states_198], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_12.run(buf443, buf404, buf420, buf426, buf442, arg281_1, buf445, 1, 1536, stream=raw_stream0)
        del arg281_1
        del buf404
        buf446 = empty_strided_cuda((1, 8960), (8960, 1), torch.float16)
        # Topologically Sorted Source Nodes: [hidden_states_196, pow_40, variance_39, add_118, rsqrt_39, hidden_states_197, to_82, hidden_states_198, linear_137], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
        extern_kernels.mm(reinterpret_tensor(buf445, (1, 1536), (0, 1), 0), reinterpret_tensor(arg282_1, (1536, 8960), (1, 1536), 0), out=buf446)
        del arg282_1
        buf447 = empty_strided_cuda((1, 8960), (8960, 1), torch.float16)
        # Topologically Sorted Source Nodes: [linear_138], Original ATen: [aten.view, aten.t, aten.mm]
        extern_kernels.mm(reinterpret_tensor(buf445, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg283_1, (1536, 8960), (1, 1536), 0), out=buf447)
        del arg283_1
        buf448 = reinterpret_tensor(buf446, (1, 1, 8960), (8960, 8960, 1), 0); del buf446  # reuse
        # Topologically Sorted Source Nodes: [linear_137, silu_19, linear_138, mul_181], Original ATen: [aten._unsafe_view, aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_mul_silu_6.run(buf448, buf447, 8960, stream=raw_stream0)
        del buf447
        buf449 = reinterpret_tensor(buf445, (1, 1536), (1536, 1), 0); del buf445  # reuse
        # Topologically Sorted Source Nodes: [linear_137, silu_19, linear_138, mul_181, down_proj_19], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
        extern_kernels.mm(reinterpret_tensor(buf448, (1, 8960), (0, 1), 0), reinterpret_tensor(arg284_1, (8960, 1536), (1, 8960), 0), out=buf449)
        del arg284_1
        del buf448
        buf451 = reinterpret_tensor(buf442, (1, 1, 1536), (1536, 1536, 1), 0); del buf442  # reuse
        # Topologically Sorted Source Nodes: [down_proj_19, hidden_states_199, hidden_states_200, pow_41, variance_40, add_120, rsqrt_40, hidden_states_201, to_84, hidden_states_202], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_9.run(buf443, buf449, arg285_1, buf451, 1, 1536, stream=raw_stream0)
        del arg285_1
        buf452 = buf426; del buf426  # reuse
        # Topologically Sorted Source Nodes: [down_proj_19, hidden_states_199, hidden_states_200, pow_41, variance_40, add_120, rsqrt_40, hidden_states_201, to_84, hidden_states_202, linear_140], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.addmm]
        extern_kernels.addmm(arg287_1, reinterpret_tensor(buf451, (1, 1536), (0, 1), 0), reinterpret_tensor(arg286_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf452)
        del arg286_1
        del arg287_1
        buf453 = empty_strided_cuda((1, 256), (256, 1), torch.float16)
        # Topologically Sorted Source Nodes: [linear_141], Original ATen: [aten.view, aten.t, aten.addmm]
        extern_kernels.addmm(arg289_1, reinterpret_tensor(buf451, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg288_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf453)
        del arg288_1
        del arg289_1
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, cos_23, sin_23, linear_141, view_62, key_states_20, mul_186, x2_41, neg_41, x1_41, cat_42, mul_187, k_embed_20, index_copy__40], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_bmm_cat_expand_index_copy_mul_neg_slice_transpose_unsqueeze_view_1.run(arg0_1, buf453, arg4_1, arg292_1, 256, stream=raw_stream0)
        buf455 = buf453; del buf453  # reuse
        # Topologically Sorted Source Nodes: [linear_142], Original ATen: [aten.view, aten.t, aten.addmm]
        extern_kernels.addmm(arg291_1, reinterpret_tensor(buf451, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg290_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf455)
        del arg290_1
        del arg291_1
        # Topologically Sorted Source Nodes: [linear_142, view_63, value_states_20, index_copy__41], Original ATen: [aten.view, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_index_copy_transpose_view_2.run(arg0_1, buf455, arg293_1, 256, stream=raw_stream0)
        del buf455
        buf457 = reinterpret_tensor(buf451, (1, 12, 1, 128), (1536, 128, 128, 1), 0); del buf451  # reuse
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, linear_140, view_61, query_states_20, cos_23, mul_184, x2_40, neg_40, x1_40, cat_41, sin_23, mul_185, q_embed_20, key_20, value_20, attn_output_80], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.clone, aten._unsafe_view, aten._scaled_dot_product_efficient_attention]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_efficient_attention__to_copy__unsafe_view_add_bmm_cat_clone_expand_mul_neg_slice_transpose_unsqueeze_view_3.run(buf452, arg4_1, arg0_1, buf457, 1536, stream=raw_stream0)
        buf458 = buf436; del buf436  # reuse
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, linear_140, view_61, query_states_20, cos_23, mul_184, x2_40, neg_40, x1_40, cat_41, sin_23, mul_185, q_embed_20, key_20, value_20, attn_output_80], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.clone, aten._unsafe_view, aten._scaled_dot_product_efficient_attention]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_efficient_attention__to_copy__unsafe_view_add_bmm_cat_clone_expand_mul_neg_slice_transpose_unsqueeze_view_4.run(arg292_1, buf458, 294912, stream=raw_stream0)
        del arg292_1
        buf459 = empty_strided_cuda((1, 12, 192, 128), (294912, 24576, 128, 1), torch.float16)
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, linear_140, view_61, query_states_20, cos_23, mul_184, x2_40, neg_40, x1_40, cat_41, sin_23, mul_185, q_embed_20, key_20, value_20, attn_output_80], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.clone, aten._unsafe_view, aten._scaled_dot_product_efficient_attention]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_efficient_attention__to_copy__unsafe_view_add_bmm_cat_clone_expand_mul_neg_slice_transpose_unsqueeze_view_4.run(arg293_1, buf459, 294912, stream=raw_stream0)
        del arg293_1
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, linear_140, view_61, query_states_20, cos_23, mul_184, x2_40, neg_40, x1_40, cat_41, sin_23, mul_185, q_embed_20, key_20, value_20, attn_output_80], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.clone, aten._unsafe_view, aten._scaled_dot_product_efficient_attention]
        buf460 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf457, buf458, buf459, reinterpret_tensor(arg3_1, (1, 12, 1, 192), (192, 0, 192, 1), 0), False, scale=0.08838834764831845)
        del buf458
        buf461 = buf460[0]
        assert_tensor_metadata(buf461, (1, 12, 1, 128), (1536, 128, 1536, 1), torch.float16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
        assert_alignment(buf461, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
        del buf460
        buf465 = reinterpret_tensor(buf457, (1, 1536), (1536, 1), 0); del buf457  # reuse
        # Topologically Sorted Source Nodes: [transpose_84, reshape_62, attn_output_83], Original ATen: [aten.transpose, aten.view, aten.t, aten.mm]
        extern_kernels.mm(reinterpret_tensor(buf461, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg294_1, (1536, 1536), (1, 1536), 0), out=buf465)
        del arg294_1
        buf467 = reinterpret_tensor(buf461, (1, 1, 1536), (1536, 1536, 1), 0); del buf461  # reuse
        # Topologically Sorted Source Nodes: [down_proj_19, hidden_states_199, attn_output_83, hidden_states_205, hidden_states_206, pow_42, variance_41, add_124, rsqrt_41, hidden_states_207, to_86, hidden_states_208], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_10.run(buf443, buf449, buf465, arg295_1, buf467, 1, 1536, stream=raw_stream0)
        del arg295_1
        buf468 = empty_strided_cuda((1, 8960), (8960, 1), torch.float16)
        # Topologically Sorted Source Nodes: [linear_144], Original ATen: [aten.view, aten.t, aten.mm]
        extern_kernels.mm(reinterpret_tensor(buf467, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg296_1, (1536, 8960), (1, 1536), 0), out=buf468)
        del arg296_1
        buf469 = empty_strided_cuda((1, 8960), (8960, 1), torch.float16)
        # Topologically Sorted Source Nodes: [linear_145], Original ATen: [aten.view, aten.t, aten.mm]
        extern_kernels.mm(reinterpret_tensor(buf467, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg297_1, (1536, 8960), (1, 1536), 0), out=buf469)
        del arg297_1
        buf470 = reinterpret_tensor(buf468, (1, 1, 8960), (8960, 8960, 1), 0); del buf468  # reuse
        # Topologically Sorted Source Nodes: [linear_144, silu_20, linear_145, mul_190], Original ATen: [aten._unsafe_view, aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_mul_silu_6.run(buf470, buf469, 8960, stream=raw_stream0)
        del buf469
        buf471 = reinterpret_tensor(buf467, (1, 1536), (1536, 1), 0); del buf467  # reuse
        # Topologically Sorted Source Nodes: [linear_144, silu_20, linear_145, mul_190, down_proj_20], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
        extern_kernels.mm(reinterpret_tensor(buf470, (1, 8960), (0, 1), 0), reinterpret_tensor(arg298_1, (8960, 1536), (1, 8960), 0), out=buf471)
        del arg298_1
        del buf470
        buf473 = reinterpret_tensor(buf452, (1, 1, 1536), (1536, 1536, 1), 0); del buf452  # reuse
        # Topologically Sorted Source Nodes: [down_proj_19, hidden_states_199, attn_output_83, hidden_states_205, down_proj_20, hidden_states_209, hidden_states_210, pow_43, variance_42, add_126, rsqrt_42, hidden_states_211, to_88, hidden_states_212], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_11.run(buf443, buf449, buf465, buf471, arg299_1, buf473, 1, 1536, stream=raw_stream0)
        del arg299_1
        buf474 = buf420; del buf420  # reuse
        # Topologically Sorted Source Nodes: [linear_147], Original ATen: [aten.view, aten.t, aten.addmm]
        extern_kernels.addmm(arg301_1, reinterpret_tensor(buf473, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg300_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf474)
        del arg300_1
        del arg301_1
        buf475 = empty_strided_cuda((1, 256), (256, 1), torch.float16)
        # Topologically Sorted Source Nodes: [linear_148], Original ATen: [aten.view, aten.t, aten.addmm]
        extern_kernels.addmm(arg303_1, reinterpret_tensor(buf473, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg302_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf475)
        del arg302_1
        del arg303_1
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, cos_24, sin_24, linear_148, view_65, key_states_21, mul_195, x2_43, neg_43, x1_43, cat_44, mul_196, k_embed_21, index_copy__42], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_bmm_cat_expand_index_copy_mul_neg_slice_transpose_unsqueeze_view_1.run(arg0_1, buf475, arg4_1, arg306_1, 256, stream=raw_stream0)
        buf477 = buf475; del buf475  # reuse
        # Topologically Sorted Source Nodes: [linear_149], Original ATen: [aten.view, aten.t, aten.addmm]
        extern_kernels.addmm(arg305_1, reinterpret_tensor(buf473, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg304_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf477)
        del arg304_1
        del arg305_1
        # Topologically Sorted Source Nodes: [linear_149, view_66, value_states_21, index_copy__43], Original ATen: [aten.view, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_index_copy_transpose_view_2.run(arg0_1, buf477, arg307_1, 256, stream=raw_stream0)
        del buf477
        buf479 = reinterpret_tensor(buf473, (1, 12, 1, 128), (1536, 128, 128, 1), 0); del buf473  # reuse
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, linear_147, view_64, query_states_21, cos_24, mul_193, x2_42, neg_42, x1_42, cat_43, sin_24, mul_194, q_embed_21, key_21, value_21, attn_output_84], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.clone, aten._unsafe_view, aten._scaled_dot_product_efficient_attention]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_efficient_attention__to_copy__unsafe_view_add_bmm_cat_clone_expand_mul_neg_slice_transpose_unsqueeze_view_3.run(buf474, arg4_1, arg0_1, buf479, 1536, stream=raw_stream0)
        del buf474
        buf480 = buf459; del buf459  # reuse
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, linear_147, view_64, query_states_21, cos_24, mul_193, x2_42, neg_42, x1_42, cat_43, sin_24, mul_194, q_embed_21, key_21, value_21, attn_output_84], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.clone, aten._unsafe_view, aten._scaled_dot_product_efficient_attention]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_efficient_attention__to_copy__unsafe_view_add_bmm_cat_clone_expand_mul_neg_slice_transpose_unsqueeze_view_4.run(arg306_1, buf480, 294912, stream=raw_stream0)
        del arg306_1
        buf481 = empty_strided_cuda((1, 12, 192, 128), (294912, 24576, 128, 1), torch.float16)
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, linear_147, view_64, query_states_21, cos_24, mul_193, x2_42, neg_42, x1_42, cat_43, sin_24, mul_194, q_embed_21, key_21, value_21, attn_output_84], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.clone, aten._unsafe_view, aten._scaled_dot_product_efficient_attention]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_efficient_attention__to_copy__unsafe_view_add_bmm_cat_clone_expand_mul_neg_slice_transpose_unsqueeze_view_4.run(arg307_1, buf481, 294912, stream=raw_stream0)
        del arg307_1
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, linear_147, view_64, query_states_21, cos_24, mul_193, x2_42, neg_42, x1_42, cat_43, sin_24, mul_194, q_embed_21, key_21, value_21, attn_output_84], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.clone, aten._unsafe_view, aten._scaled_dot_product_efficient_attention]
        buf482 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf479, buf480, buf481, reinterpret_tensor(arg3_1, (1, 12, 1, 192), (192, 0, 192, 1), 0), False, scale=0.08838834764831845)
        del buf480
        buf483 = buf482[0]
        assert_tensor_metadata(buf483, (1, 12, 1, 128), (1536, 128, 1536, 1), torch.float16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
        assert_alignment(buf483, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
        del buf482
        buf487 = reinterpret_tensor(buf479, (1, 1536), (1536, 1), 0); del buf479  # reuse
        # Topologically Sorted Source Nodes: [transpose_88, reshape_65, attn_output_87], Original ATen: [aten.transpose, aten.view, aten.t, aten.mm]
        extern_kernels.mm(reinterpret_tensor(buf483, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg308_1, (1536, 1536), (1, 1536), 0), out=buf487)
        del arg308_1
        buf488 = buf443; del buf443  # reuse
        buf490 = reinterpret_tensor(buf483, (1, 1, 1536), (1536, 1536, 1), 0); del buf483  # reuse
        # Topologically Sorted Source Nodes: [down_proj_19, hidden_states_199, attn_output_83, hidden_states_205, down_proj_20, hidden_states_209, attn_output_87, hidden_states_215, hidden_states_216, pow_44, variance_43, add_130, rsqrt_43, hidden_states_217, to_90, hidden_states_218], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_12.run(buf488, buf449, buf465, buf471, buf487, arg309_1, buf490, 1, 1536, stream=raw_stream0)
        del arg309_1
        del buf449
        buf491 = empty_strided_cuda((1, 8960), (8960, 1), torch.float16)
        # Topologically Sorted Source Nodes: [hidden_states_216, pow_44, variance_43, add_130, rsqrt_43, hidden_states_217, to_90, hidden_states_218, linear_151], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
        extern_kernels.mm(reinterpret_tensor(buf490, (1, 1536), (0, 1), 0), reinterpret_tensor(arg310_1, (1536, 8960), (1, 1536), 0), out=buf491)
        del arg310_1
        buf492 = empty_strided_cuda((1, 8960), (8960, 1), torch.float16)
        # Topologically Sorted Source Nodes: [linear_152], Original ATen: [aten.view, aten.t, aten.mm]
        extern_kernels.mm(reinterpret_tensor(buf490, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg311_1, (1536, 8960), (1, 1536), 0), out=buf492)
        del arg311_1
        buf493 = reinterpret_tensor(buf491, (1, 1, 8960), (8960, 8960, 1), 0); del buf491  # reuse
        # Topologically Sorted Source Nodes: [linear_151, silu_21, linear_152, mul_199], Original ATen: [aten._unsafe_view, aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_mul_silu_6.run(buf493, buf492, 8960, stream=raw_stream0)
        del buf492
        buf494 = reinterpret_tensor(buf490, (1, 1536), (1536, 1), 0); del buf490  # reuse
        # Topologically Sorted Source Nodes: [linear_151, silu_21, linear_152, mul_199, down_proj_21], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
        extern_kernels.mm(reinterpret_tensor(buf493, (1, 8960), (0, 1), 0), reinterpret_tensor(arg312_1, (8960, 1536), (1, 8960), 0), out=buf494)
        del arg312_1
        del buf493
        buf496 = reinterpret_tensor(buf487, (1, 1, 1536), (1536, 1536, 1), 0); del buf487  # reuse
        # Topologically Sorted Source Nodes: [down_proj_21, hidden_states_219, hidden_states_220, pow_45, variance_44, add_132, rsqrt_44, hidden_states_221, to_92, hidden_states_222], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_9.run(buf488, buf494, arg313_1, buf496, 1, 1536, stream=raw_stream0)
        del arg313_1
        buf497 = buf471; del buf471  # reuse
        # Topologically Sorted Source Nodes: [down_proj_21, hidden_states_219, hidden_states_220, pow_45, variance_44, add_132, rsqrt_44, hidden_states_221, to_92, hidden_states_222, linear_154], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.addmm]
        extern_kernels.addmm(arg315_1, reinterpret_tensor(buf496, (1, 1536), (0, 1), 0), reinterpret_tensor(arg314_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf497)
        del arg314_1
        del arg315_1
        buf498 = empty_strided_cuda((1, 256), (256, 1), torch.float16)
        # Topologically Sorted Source Nodes: [linear_155], Original ATen: [aten.view, aten.t, aten.addmm]
        extern_kernels.addmm(arg317_1, reinterpret_tensor(buf496, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg316_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf498)
        del arg316_1
        del arg317_1
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, cos_25, sin_25, linear_155, view_68, key_states_22, mul_204, x2_45, neg_45, x1_45, cat_46, mul_205, k_embed_22, index_copy__44], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_bmm_cat_expand_index_copy_mul_neg_slice_transpose_unsqueeze_view_1.run(arg0_1, buf498, arg4_1, arg320_1, 256, stream=raw_stream0)
        buf500 = buf498; del buf498  # reuse
        # Topologically Sorted Source Nodes: [linear_156], Original ATen: [aten.view, aten.t, aten.addmm]
        extern_kernels.addmm(arg319_1, reinterpret_tensor(buf496, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg318_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf500)
        del arg318_1
        del arg319_1
        # Topologically Sorted Source Nodes: [linear_156, view_69, value_states_22, index_copy__45], Original ATen: [aten.view, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_index_copy_transpose_view_2.run(arg0_1, buf500, arg321_1, 256, stream=raw_stream0)
        del buf500
        buf502 = reinterpret_tensor(buf496, (1, 12, 1, 128), (1536, 128, 128, 1), 0); del buf496  # reuse
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, linear_154, view_67, query_states_22, cos_25, mul_202, x2_44, neg_44, x1_44, cat_45, sin_25, mul_203, q_embed_22, key_22, value_22, attn_output_88], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.clone, aten._unsafe_view, aten._scaled_dot_product_efficient_attention]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_efficient_attention__to_copy__unsafe_view_add_bmm_cat_clone_expand_mul_neg_slice_transpose_unsqueeze_view_3.run(buf497, arg4_1, arg0_1, buf502, 1536, stream=raw_stream0)
        buf503 = buf481; del buf481  # reuse
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, linear_154, view_67, query_states_22, cos_25, mul_202, x2_44, neg_44, x1_44, cat_45, sin_25, mul_203, q_embed_22, key_22, value_22, attn_output_88], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.clone, aten._unsafe_view, aten._scaled_dot_product_efficient_attention]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_efficient_attention__to_copy__unsafe_view_add_bmm_cat_clone_expand_mul_neg_slice_transpose_unsqueeze_view_4.run(arg320_1, buf503, 294912, stream=raw_stream0)
        del arg320_1
        buf504 = empty_strided_cuda((1, 12, 192, 128), (294912, 24576, 128, 1), torch.float16)
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, linear_154, view_67, query_states_22, cos_25, mul_202, x2_44, neg_44, x1_44, cat_45, sin_25, mul_203, q_embed_22, key_22, value_22, attn_output_88], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.clone, aten._unsafe_view, aten._scaled_dot_product_efficient_attention]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_efficient_attention__to_copy__unsafe_view_add_bmm_cat_clone_expand_mul_neg_slice_transpose_unsqueeze_view_4.run(arg321_1, buf504, 294912, stream=raw_stream0)
        del arg321_1
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, linear_154, view_67, query_states_22, cos_25, mul_202, x2_44, neg_44, x1_44, cat_45, sin_25, mul_203, q_embed_22, key_22, value_22, attn_output_88], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.clone, aten._unsafe_view, aten._scaled_dot_product_efficient_attention]
        buf505 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf502, buf503, buf504, reinterpret_tensor(arg3_1, (1, 12, 1, 192), (192, 0, 192, 1), 0), False, scale=0.08838834764831845)
        del buf503
        buf506 = buf505[0]
        assert_tensor_metadata(buf506, (1, 12, 1, 128), (1536, 128, 1536, 1), torch.float16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
        assert_alignment(buf506, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
        del buf505
        buf510 = reinterpret_tensor(buf502, (1, 1536), (1536, 1), 0); del buf502  # reuse
        # Topologically Sorted Source Nodes: [transpose_92, reshape_68, attn_output_91], Original ATen: [aten.transpose, aten.view, aten.t, aten.mm]
        extern_kernels.mm(reinterpret_tensor(buf506, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg322_1, (1536, 1536), (1, 1536), 0), out=buf510)
        del arg322_1
        buf512 = reinterpret_tensor(buf506, (1, 1, 1536), (1536, 1536, 1), 0); del buf506  # reuse
        # Topologically Sorted Source Nodes: [down_proj_21, hidden_states_219, attn_output_91, hidden_states_225, hidden_states_226, pow_46, variance_45, add_136, rsqrt_45, hidden_states_227, to_94, hidden_states_228], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_10.run(buf488, buf494, buf510, arg323_1, buf512, 1, 1536, stream=raw_stream0)
        del arg323_1
        buf513 = empty_strided_cuda((1, 8960), (8960, 1), torch.float16)
        # Topologically Sorted Source Nodes: [linear_158], Original ATen: [aten.view, aten.t, aten.mm]
        extern_kernels.mm(reinterpret_tensor(buf512, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg324_1, (1536, 8960), (1, 1536), 0), out=buf513)
        del arg324_1
        buf514 = empty_strided_cuda((1, 8960), (8960, 1), torch.float16)
        # Topologically Sorted Source Nodes: [linear_159], Original ATen: [aten.view, aten.t, aten.mm]
        extern_kernels.mm(reinterpret_tensor(buf512, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg325_1, (1536, 8960), (1, 1536), 0), out=buf514)
        del arg325_1
        buf515 = reinterpret_tensor(buf513, (1, 1, 8960), (8960, 8960, 1), 0); del buf513  # reuse
        # Topologically Sorted Source Nodes: [linear_158, silu_22, linear_159, mul_208], Original ATen: [aten._unsafe_view, aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_mul_silu_6.run(buf515, buf514, 8960, stream=raw_stream0)
        del buf514
        buf516 = reinterpret_tensor(buf512, (1, 1536), (1536, 1), 0); del buf512  # reuse
        # Topologically Sorted Source Nodes: [linear_158, silu_22, linear_159, mul_208, down_proj_22], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
        extern_kernels.mm(reinterpret_tensor(buf515, (1, 8960), (0, 1), 0), reinterpret_tensor(arg326_1, (8960, 1536), (1, 8960), 0), out=buf516)
        del arg326_1
        del buf515
        buf518 = reinterpret_tensor(buf497, (1, 1, 1536), (1536, 1536, 1), 0); del buf497  # reuse
        # Topologically Sorted Source Nodes: [down_proj_21, hidden_states_219, attn_output_91, hidden_states_225, down_proj_22, hidden_states_229, hidden_states_230, pow_47, variance_46, add_138, rsqrt_46, hidden_states_231, to_96, hidden_states_232], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_11.run(buf488, buf494, buf510, buf516, arg327_1, buf518, 1, 1536, stream=raw_stream0)
        del arg327_1
        buf519 = buf465; del buf465  # reuse
        # Topologically Sorted Source Nodes: [linear_161], Original ATen: [aten.view, aten.t, aten.addmm]
        extern_kernels.addmm(arg329_1, reinterpret_tensor(buf518, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg328_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf519)
        del arg328_1
        del arg329_1
        buf520 = empty_strided_cuda((1, 256), (256, 1), torch.float16)
        # Topologically Sorted Source Nodes: [linear_162], Original ATen: [aten.view, aten.t, aten.addmm]
        extern_kernels.addmm(arg331_1, reinterpret_tensor(buf518, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg330_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf520)
        del arg330_1
        del arg331_1
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, cos_26, sin_26, linear_162, view_71, key_states_23, mul_213, x2_47, neg_47, x1_47, cat_48, mul_214, k_embed_23, index_copy__46], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_bmm_cat_expand_index_copy_mul_neg_slice_transpose_unsqueeze_view_1.run(arg0_1, buf520, arg4_1, arg334_1, 256, stream=raw_stream0)
        buf522 = buf520; del buf520  # reuse
        # Topologically Sorted Source Nodes: [linear_163], Original ATen: [aten.view, aten.t, aten.addmm]
        extern_kernels.addmm(arg333_1, reinterpret_tensor(buf518, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg332_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf522)
        del arg332_1
        del arg333_1
        # Topologically Sorted Source Nodes: [linear_163, view_72, value_states_23, index_copy__47], Original ATen: [aten.view, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_index_copy_transpose_view_2.run(arg0_1, buf522, arg335_1, 256, stream=raw_stream0)
        del buf522
        buf524 = reinterpret_tensor(buf518, (1, 12, 1, 128), (1536, 128, 128, 1), 0); del buf518  # reuse
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, linear_161, view_70, query_states_23, cos_26, mul_211, x2_46, neg_46, x1_46, cat_47, sin_26, mul_212, q_embed_23, key_23, value_23, attn_output_92], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.clone, aten._unsafe_view, aten._scaled_dot_product_efficient_attention]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_efficient_attention__to_copy__unsafe_view_add_bmm_cat_clone_expand_mul_neg_slice_transpose_unsqueeze_view_3.run(buf519, arg4_1, arg0_1, buf524, 1536, stream=raw_stream0)
        del buf519
        buf525 = buf504; del buf504  # reuse
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, linear_161, view_70, query_states_23, cos_26, mul_211, x2_46, neg_46, x1_46, cat_47, sin_26, mul_212, q_embed_23, key_23, value_23, attn_output_92], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.clone, aten._unsafe_view, aten._scaled_dot_product_efficient_attention]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_efficient_attention__to_copy__unsafe_view_add_bmm_cat_clone_expand_mul_neg_slice_transpose_unsqueeze_view_4.run(arg334_1, buf525, 294912, stream=raw_stream0)
        del arg334_1
        buf526 = empty_strided_cuda((1, 12, 192, 128), (294912, 24576, 128, 1), torch.float16)
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, linear_161, view_70, query_states_23, cos_26, mul_211, x2_46, neg_46, x1_46, cat_47, sin_26, mul_212, q_embed_23, key_23, value_23, attn_output_92], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.clone, aten._unsafe_view, aten._scaled_dot_product_efficient_attention]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_efficient_attention__to_copy__unsafe_view_add_bmm_cat_clone_expand_mul_neg_slice_transpose_unsqueeze_view_4.run(arg335_1, buf526, 294912, stream=raw_stream0)
        del arg335_1
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, linear_161, view_70, query_states_23, cos_26, mul_211, x2_46, neg_46, x1_46, cat_47, sin_26, mul_212, q_embed_23, key_23, value_23, attn_output_92], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.clone, aten._unsafe_view, aten._scaled_dot_product_efficient_attention]
        buf527 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf524, buf525, buf526, reinterpret_tensor(arg3_1, (1, 12, 1, 192), (192, 0, 192, 1), 0), False, scale=0.08838834764831845)
        del buf525
        buf528 = buf527[0]
        assert_tensor_metadata(buf528, (1, 12, 1, 128), (1536, 128, 1536, 1), torch.float16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
        assert_alignment(buf528, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
        del buf527
        buf532 = reinterpret_tensor(buf524, (1, 1536), (1536, 1), 0); del buf524  # reuse
        # Topologically Sorted Source Nodes: [transpose_96, reshape_71, attn_output_95], Original ATen: [aten.transpose, aten.view, aten.t, aten.mm]
        extern_kernels.mm(reinterpret_tensor(buf528, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg336_1, (1536, 1536), (1, 1536), 0), out=buf532)
        del arg336_1
        buf533 = buf488; del buf488  # reuse
        buf535 = reinterpret_tensor(buf528, (1, 1, 1536), (1536, 1536, 1), 0); del buf528  # reuse
        # Topologically Sorted Source Nodes: [down_proj_21, hidden_states_219, attn_output_91, hidden_states_225, down_proj_22, hidden_states_229, attn_output_95, hidden_states_235, hidden_states_236, pow_48, variance_47, add_142, rsqrt_47, hidden_states_237, to_98, hidden_states_238], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_12.run(buf533, buf494, buf510, buf516, buf532, arg337_1, buf535, 1, 1536, stream=raw_stream0)
        del arg337_1
        del buf494
        buf536 = empty_strided_cuda((1, 8960), (8960, 1), torch.float16)
        # Topologically Sorted Source Nodes: [hidden_states_236, pow_48, variance_47, add_142, rsqrt_47, hidden_states_237, to_98, hidden_states_238, linear_165], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
        extern_kernels.mm(reinterpret_tensor(buf535, (1, 1536), (0, 1), 0), reinterpret_tensor(arg338_1, (1536, 8960), (1, 1536), 0), out=buf536)
        del arg338_1
        buf537 = empty_strided_cuda((1, 8960), (8960, 1), torch.float16)
        # Topologically Sorted Source Nodes: [linear_166], Original ATen: [aten.view, aten.t, aten.mm]
        extern_kernels.mm(reinterpret_tensor(buf535, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg339_1, (1536, 8960), (1, 1536), 0), out=buf537)
        del arg339_1
        buf538 = reinterpret_tensor(buf536, (1, 1, 8960), (8960, 8960, 1), 0); del buf536  # reuse
        # Topologically Sorted Source Nodes: [linear_165, silu_23, linear_166, mul_217], Original ATen: [aten._unsafe_view, aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_mul_silu_6.run(buf538, buf537, 8960, stream=raw_stream0)
        del buf537
        buf539 = reinterpret_tensor(buf535, (1, 1536), (1536, 1), 0); del buf535  # reuse
        # Topologically Sorted Source Nodes: [linear_165, silu_23, linear_166, mul_217, down_proj_23], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
        extern_kernels.mm(reinterpret_tensor(buf538, (1, 8960), (0, 1), 0), reinterpret_tensor(arg340_1, (8960, 1536), (1, 8960), 0), out=buf539)
        del arg340_1
        del buf538
        buf541 = reinterpret_tensor(buf532, (1, 1, 1536), (1536, 1536, 1), 0); del buf532  # reuse
        # Topologically Sorted Source Nodes: [down_proj_23, hidden_states_239, hidden_states_240, pow_49, variance_48, add_144, rsqrt_48, hidden_states_241, to_100, hidden_states_242], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_9.run(buf533, buf539, arg341_1, buf541, 1, 1536, stream=raw_stream0)
        del arg341_1
        buf542 = buf516; del buf516  # reuse
        # Topologically Sorted Source Nodes: [down_proj_23, hidden_states_239, hidden_states_240, pow_49, variance_48, add_144, rsqrt_48, hidden_states_241, to_100, hidden_states_242, linear_168], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.addmm]
        extern_kernels.addmm(arg343_1, reinterpret_tensor(buf541, (1, 1536), (0, 1), 0), reinterpret_tensor(arg342_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf542)
        del arg342_1
        del arg343_1
        buf543 = empty_strided_cuda((1, 256), (256, 1), torch.float16)
        # Topologically Sorted Source Nodes: [linear_169], Original ATen: [aten.view, aten.t, aten.addmm]
        extern_kernels.addmm(arg345_1, reinterpret_tensor(buf541, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg344_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf543)
        del arg344_1
        del arg345_1
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, cos_27, sin_27, linear_169, view_74, key_states_24, mul_222, x2_49, neg_49, x1_49, cat_50, mul_223, k_embed_24, index_copy__48], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_bmm_cat_expand_index_copy_mul_neg_slice_transpose_unsqueeze_view_1.run(arg0_1, buf543, arg4_1, arg348_1, 256, stream=raw_stream0)
        buf545 = buf543; del buf543  # reuse
        # Topologically Sorted Source Nodes: [linear_170], Original ATen: [aten.view, aten.t, aten.addmm]
        extern_kernels.addmm(arg347_1, reinterpret_tensor(buf541, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg346_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf545)
        del arg346_1
        del arg347_1
        # Topologically Sorted Source Nodes: [linear_170, view_75, value_states_24, index_copy__49], Original ATen: [aten.view, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_index_copy_transpose_view_2.run(arg0_1, buf545, arg349_1, 256, stream=raw_stream0)
        del buf545
        buf547 = reinterpret_tensor(buf541, (1, 12, 1, 128), (1536, 128, 128, 1), 0); del buf541  # reuse
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, linear_168, view_73, query_states_24, cos_27, mul_220, x2_48, neg_48, x1_48, cat_49, sin_27, mul_221, q_embed_24, key_24, value_24, attn_output_96], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.clone, aten._unsafe_view, aten._scaled_dot_product_efficient_attention]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_efficient_attention__to_copy__unsafe_view_add_bmm_cat_clone_expand_mul_neg_slice_transpose_unsqueeze_view_3.run(buf542, arg4_1, arg0_1, buf547, 1536, stream=raw_stream0)
        buf548 = buf526; del buf526  # reuse
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, linear_168, view_73, query_states_24, cos_27, mul_220, x2_48, neg_48, x1_48, cat_49, sin_27, mul_221, q_embed_24, key_24, value_24, attn_output_96], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.clone, aten._unsafe_view, aten._scaled_dot_product_efficient_attention]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_efficient_attention__to_copy__unsafe_view_add_bmm_cat_clone_expand_mul_neg_slice_transpose_unsqueeze_view_4.run(arg348_1, buf548, 294912, stream=raw_stream0)
        del arg348_1
        buf549 = empty_strided_cuda((1, 12, 192, 128), (294912, 24576, 128, 1), torch.float16)
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, linear_168, view_73, query_states_24, cos_27, mul_220, x2_48, neg_48, x1_48, cat_49, sin_27, mul_221, q_embed_24, key_24, value_24, attn_output_96], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.clone, aten._unsafe_view, aten._scaled_dot_product_efficient_attention]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_efficient_attention__to_copy__unsafe_view_add_bmm_cat_clone_expand_mul_neg_slice_transpose_unsqueeze_view_4.run(arg349_1, buf549, 294912, stream=raw_stream0)
        del arg349_1
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, linear_168, view_73, query_states_24, cos_27, mul_220, x2_48, neg_48, x1_48, cat_49, sin_27, mul_221, q_embed_24, key_24, value_24, attn_output_96], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.clone, aten._unsafe_view, aten._scaled_dot_product_efficient_attention]
        buf550 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf547, buf548, buf549, reinterpret_tensor(arg3_1, (1, 12, 1, 192), (192, 0, 192, 1), 0), False, scale=0.08838834764831845)
        del buf548
        buf551 = buf550[0]
        assert_tensor_metadata(buf551, (1, 12, 1, 128), (1536, 128, 1536, 1), torch.float16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
        assert_alignment(buf551, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
        del buf550
        buf555 = reinterpret_tensor(buf547, (1, 1536), (1536, 1), 0); del buf547  # reuse
        # Topologically Sorted Source Nodes: [transpose_100, reshape_74, attn_output_99], Original ATen: [aten.transpose, aten.view, aten.t, aten.mm]
        extern_kernels.mm(reinterpret_tensor(buf551, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg350_1, (1536, 1536), (1, 1536), 0), out=buf555)
        del arg350_1
        buf557 = reinterpret_tensor(buf551, (1, 1, 1536), (1536, 1536, 1), 0); del buf551  # reuse
        # Topologically Sorted Source Nodes: [down_proj_23, hidden_states_239, attn_output_99, hidden_states_245, hidden_states_246, pow_50, variance_49, add_148, rsqrt_49, hidden_states_247, to_102, hidden_states_248], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_10.run(buf533, buf539, buf555, arg351_1, buf557, 1, 1536, stream=raw_stream0)
        del arg351_1
        buf558 = empty_strided_cuda((1, 8960), (8960, 1), torch.float16)
        # Topologically Sorted Source Nodes: [linear_172], Original ATen: [aten.view, aten.t, aten.mm]
        extern_kernels.mm(reinterpret_tensor(buf557, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg352_1, (1536, 8960), (1, 1536), 0), out=buf558)
        del arg352_1
        buf559 = empty_strided_cuda((1, 8960), (8960, 1), torch.float16)
        # Topologically Sorted Source Nodes: [linear_173], Original ATen: [aten.view, aten.t, aten.mm]
        extern_kernels.mm(reinterpret_tensor(buf557, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg353_1, (1536, 8960), (1, 1536), 0), out=buf559)
        del arg353_1
        buf560 = reinterpret_tensor(buf558, (1, 1, 8960), (8960, 8960, 1), 0); del buf558  # reuse
        # Topologically Sorted Source Nodes: [linear_172, silu_24, linear_173, mul_226], Original ATen: [aten._unsafe_view, aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_mul_silu_6.run(buf560, buf559, 8960, stream=raw_stream0)
        del buf559
        buf561 = reinterpret_tensor(buf557, (1, 1536), (1536, 1), 0); del buf557  # reuse
        # Topologically Sorted Source Nodes: [linear_172, silu_24, linear_173, mul_226, down_proj_24], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
        extern_kernels.mm(reinterpret_tensor(buf560, (1, 8960), (0, 1), 0), reinterpret_tensor(arg354_1, (8960, 1536), (1, 8960), 0), out=buf561)
        del arg354_1
        del buf560
        buf563 = reinterpret_tensor(buf542, (1, 1, 1536), (1536, 1536, 1), 0); del buf542  # reuse
        # Topologically Sorted Source Nodes: [down_proj_23, hidden_states_239, attn_output_99, hidden_states_245, down_proj_24, hidden_states_249, hidden_states_250, pow_51, variance_50, add_150, rsqrt_50, hidden_states_251, to_104, hidden_states_252], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_11.run(buf533, buf539, buf555, buf561, arg355_1, buf563, 1, 1536, stream=raw_stream0)
        del arg355_1
        buf564 = buf510; del buf510  # reuse
        # Topologically Sorted Source Nodes: [linear_175], Original ATen: [aten.view, aten.t, aten.addmm]
        extern_kernels.addmm(arg357_1, reinterpret_tensor(buf563, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg356_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf564)
        del arg356_1
        del arg357_1
        buf565 = empty_strided_cuda((1, 256), (256, 1), torch.float16)
        # Topologically Sorted Source Nodes: [linear_176], Original ATen: [aten.view, aten.t, aten.addmm]
        extern_kernels.addmm(arg359_1, reinterpret_tensor(buf563, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg358_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf565)
        del arg358_1
        del arg359_1
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, cos_28, sin_28, linear_176, view_77, key_states_25, mul_231, x2_51, neg_51, x1_51, cat_52, mul_232, k_embed_25, index_copy__50], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_bmm_cat_expand_index_copy_mul_neg_slice_transpose_unsqueeze_view_1.run(arg0_1, buf565, arg4_1, arg362_1, 256, stream=raw_stream0)
        buf567 = buf565; del buf565  # reuse
        # Topologically Sorted Source Nodes: [linear_177], Original ATen: [aten.view, aten.t, aten.addmm]
        extern_kernels.addmm(arg361_1, reinterpret_tensor(buf563, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg360_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf567)
        del arg360_1
        del arg361_1
        # Topologically Sorted Source Nodes: [linear_177, view_78, value_states_25, index_copy__51], Original ATen: [aten.view, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_index_copy_transpose_view_2.run(arg0_1, buf567, arg363_1, 256, stream=raw_stream0)
        del buf567
        buf569 = reinterpret_tensor(buf563, (1, 12, 1, 128), (1536, 128, 128, 1), 0); del buf563  # reuse
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, linear_175, view_76, query_states_25, cos_28, mul_229, x2_50, neg_50, x1_50, cat_51, sin_28, mul_230, q_embed_25, key_25, value_25, attn_output_100], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.clone, aten._unsafe_view, aten._scaled_dot_product_efficient_attention]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_efficient_attention__to_copy__unsafe_view_add_bmm_cat_clone_expand_mul_neg_slice_transpose_unsqueeze_view_3.run(buf564, arg4_1, arg0_1, buf569, 1536, stream=raw_stream0)
        del buf564
        buf570 = buf549; del buf549  # reuse
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, linear_175, view_76, query_states_25, cos_28, mul_229, x2_50, neg_50, x1_50, cat_51, sin_28, mul_230, q_embed_25, key_25, value_25, attn_output_100], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.clone, aten._unsafe_view, aten._scaled_dot_product_efficient_attention]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_efficient_attention__to_copy__unsafe_view_add_bmm_cat_clone_expand_mul_neg_slice_transpose_unsqueeze_view_4.run(arg362_1, buf570, 294912, stream=raw_stream0)
        del arg362_1
        buf571 = empty_strided_cuda((1, 12, 192, 128), (294912, 24576, 128, 1), torch.float16)
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, linear_175, view_76, query_states_25, cos_28, mul_229, x2_50, neg_50, x1_50, cat_51, sin_28, mul_230, q_embed_25, key_25, value_25, attn_output_100], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.clone, aten._unsafe_view, aten._scaled_dot_product_efficient_attention]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_efficient_attention__to_copy__unsafe_view_add_bmm_cat_clone_expand_mul_neg_slice_transpose_unsqueeze_view_4.run(arg363_1, buf571, 294912, stream=raw_stream0)
        del arg363_1
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, linear_175, view_76, query_states_25, cos_28, mul_229, x2_50, neg_50, x1_50, cat_51, sin_28, mul_230, q_embed_25, key_25, value_25, attn_output_100], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.clone, aten._unsafe_view, aten._scaled_dot_product_efficient_attention]
        buf572 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf569, buf570, buf571, reinterpret_tensor(arg3_1, (1, 12, 1, 192), (192, 0, 192, 1), 0), False, scale=0.08838834764831845)
        del buf570
        buf573 = buf572[0]
        assert_tensor_metadata(buf573, (1, 12, 1, 128), (1536, 128, 1536, 1), torch.float16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
        assert_alignment(buf573, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
        del buf572
        buf577 = reinterpret_tensor(buf569, (1, 1536), (1536, 1), 0); del buf569  # reuse
        # Topologically Sorted Source Nodes: [transpose_104, reshape_77, attn_output_103], Original ATen: [aten.transpose, aten.view, aten.t, aten.mm]
        extern_kernels.mm(reinterpret_tensor(buf573, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg364_1, (1536, 1536), (1, 1536), 0), out=buf577)
        del arg364_1
        buf578 = buf533; del buf533  # reuse
        buf580 = reinterpret_tensor(buf573, (1, 1, 1536), (1536, 1536, 1), 0); del buf573  # reuse
        # Topologically Sorted Source Nodes: [down_proj_23, hidden_states_239, attn_output_99, hidden_states_245, down_proj_24, hidden_states_249, attn_output_103, hidden_states_255, hidden_states_256, pow_52, variance_51, add_154, rsqrt_51, hidden_states_257, to_106, hidden_states_258], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_12.run(buf578, buf539, buf555, buf561, buf577, arg365_1, buf580, 1, 1536, stream=raw_stream0)
        del arg365_1
        del buf539
        buf581 = empty_strided_cuda((1, 8960), (8960, 1), torch.float16)
        # Topologically Sorted Source Nodes: [hidden_states_256, pow_52, variance_51, add_154, rsqrt_51, hidden_states_257, to_106, hidden_states_258, linear_179], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
        extern_kernels.mm(reinterpret_tensor(buf580, (1, 1536), (0, 1), 0), reinterpret_tensor(arg366_1, (1536, 8960), (1, 1536), 0), out=buf581)
        del arg366_1
        buf582 = empty_strided_cuda((1, 8960), (8960, 1), torch.float16)
        # Topologically Sorted Source Nodes: [linear_180], Original ATen: [aten.view, aten.t, aten.mm]
        extern_kernels.mm(reinterpret_tensor(buf580, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg367_1, (1536, 8960), (1, 1536), 0), out=buf582)
        del arg367_1
        buf583 = reinterpret_tensor(buf581, (1, 1, 8960), (8960, 8960, 1), 0); del buf581  # reuse
        # Topologically Sorted Source Nodes: [linear_179, silu_25, linear_180, mul_235], Original ATen: [aten._unsafe_view, aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_mul_silu_6.run(buf583, buf582, 8960, stream=raw_stream0)
        del buf582
        buf584 = reinterpret_tensor(buf580, (1, 1536), (1536, 1), 0); del buf580  # reuse
        # Topologically Sorted Source Nodes: [linear_179, silu_25, linear_180, mul_235, down_proj_25], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
        extern_kernels.mm(reinterpret_tensor(buf583, (1, 8960), (0, 1), 0), reinterpret_tensor(arg368_1, (8960, 1536), (1, 8960), 0), out=buf584)
        del arg368_1
        del buf583
        buf586 = reinterpret_tensor(buf577, (1, 1, 1536), (1536, 1536, 1), 0); del buf577  # reuse
        # Topologically Sorted Source Nodes: [down_proj_25, hidden_states_259, hidden_states_260, pow_53, variance_52, add_156, rsqrt_52, hidden_states_261, to_108, hidden_states_262], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_9.run(buf578, buf584, arg369_1, buf586, 1, 1536, stream=raw_stream0)
        del arg369_1
        buf587 = buf561; del buf561  # reuse
        # Topologically Sorted Source Nodes: [down_proj_25, hidden_states_259, hidden_states_260, pow_53, variance_52, add_156, rsqrt_52, hidden_states_261, to_108, hidden_states_262, linear_182], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.t, aten.addmm]
        extern_kernels.addmm(arg371_1, reinterpret_tensor(buf586, (1, 1536), (0, 1), 0), reinterpret_tensor(arg370_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf587)
        del arg370_1
        del arg371_1
        buf588 = empty_strided_cuda((1, 256), (256, 1), torch.float16)
        # Topologically Sorted Source Nodes: [linear_183], Original ATen: [aten.view, aten.t, aten.addmm]
        extern_kernels.addmm(arg373_1, reinterpret_tensor(buf586, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg372_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf588)
        del arg372_1
        del arg373_1
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, cos_29, sin_29, linear_183, view_80, key_states_26, mul_240, x2_53, neg_53, x1_53, cat_54, mul_241, k_embed_26, index_copy__52], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_bmm_cat_expand_index_copy_mul_neg_slice_transpose_unsqueeze_view_1.run(arg0_1, buf588, arg4_1, arg376_1, 256, stream=raw_stream0)
        buf590 = buf588; del buf588  # reuse
        # Topologically Sorted Source Nodes: [linear_184], Original ATen: [aten.view, aten.t, aten.addmm]
        extern_kernels.addmm(arg375_1, reinterpret_tensor(buf586, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg374_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf590)
        del arg374_1
        del arg375_1
        # Topologically Sorted Source Nodes: [linear_184, view_81, value_states_26, index_copy__53], Original ATen: [aten.view, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_index_copy_transpose_view_2.run(arg0_1, buf590, arg377_1, 256, stream=raw_stream0)
        del buf590
        buf592 = reinterpret_tensor(buf586, (1, 12, 1, 128), (1536, 128, 128, 1), 0); del buf586  # reuse
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, linear_182, view_79, query_states_26, cos_29, mul_238, x2_52, neg_52, x1_52, cat_53, sin_29, mul_239, q_embed_26, key_26, value_26, attn_output_104], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.clone, aten._unsafe_view, aten._scaled_dot_product_efficient_attention]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_efficient_attention__to_copy__unsafe_view_add_bmm_cat_clone_expand_mul_neg_slice_transpose_unsqueeze_view_3.run(buf587, arg4_1, arg0_1, buf592, 1536, stream=raw_stream0)
        buf593 = buf571; del buf571  # reuse
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, linear_182, view_79, query_states_26, cos_29, mul_238, x2_52, neg_52, x1_52, cat_53, sin_29, mul_239, q_embed_26, key_26, value_26, attn_output_104], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.clone, aten._unsafe_view, aten._scaled_dot_product_efficient_attention]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_efficient_attention__to_copy__unsafe_view_add_bmm_cat_clone_expand_mul_neg_slice_transpose_unsqueeze_view_4.run(arg376_1, buf593, 294912, stream=raw_stream0)
        del arg376_1
        buf594 = empty_strided_cuda((1, 12, 192, 128), (294912, 24576, 128, 1), torch.float16)
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, linear_182, view_79, query_states_26, cos_29, mul_238, x2_52, neg_52, x1_52, cat_53, sin_29, mul_239, q_embed_26, key_26, value_26, attn_output_104], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.clone, aten._unsafe_view, aten._scaled_dot_product_efficient_attention]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_efficient_attention__to_copy__unsafe_view_add_bmm_cat_clone_expand_mul_neg_slice_transpose_unsqueeze_view_4.run(arg377_1, buf594, 294912, stream=raw_stream0)
        del arg377_1
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, linear_182, view_79, query_states_26, cos_29, mul_238, x2_52, neg_52, x1_52, cat_53, sin_29, mul_239, q_embed_26, key_26, value_26, attn_output_104], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.clone, aten._unsafe_view, aten._scaled_dot_product_efficient_attention]
        buf595 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf592, buf593, buf594, reinterpret_tensor(arg3_1, (1, 12, 1, 192), (192, 0, 192, 1), 0), False, scale=0.08838834764831845)
        del buf593
        buf596 = buf595[0]
        assert_tensor_metadata(buf596, (1, 12, 1, 128), (1536, 128, 1536, 1), torch.float16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
        assert_alignment(buf596, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
        del buf595
        buf600 = reinterpret_tensor(buf592, (1, 1536), (1536, 1), 0); del buf592  # reuse
        # Topologically Sorted Source Nodes: [transpose_108, reshape_80, attn_output_107], Original ATen: [aten.transpose, aten.view, aten.t, aten.mm]
        extern_kernels.mm(reinterpret_tensor(buf596, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg378_1, (1536, 1536), (1, 1536), 0), out=buf600)
        del arg378_1
        buf602 = reinterpret_tensor(buf596, (1, 1, 1536), (1536, 1536, 1), 0); del buf596  # reuse
        # Topologically Sorted Source Nodes: [down_proj_25, hidden_states_259, attn_output_107, hidden_states_265, hidden_states_266, pow_54, variance_53, add_160, rsqrt_53, hidden_states_267, to_110, hidden_states_268], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_10.run(buf578, buf584, buf600, arg379_1, buf602, 1, 1536, stream=raw_stream0)
        del arg379_1
        buf603 = empty_strided_cuda((1, 8960), (8960, 1), torch.float16)
        # Topologically Sorted Source Nodes: [linear_186], Original ATen: [aten.view, aten.t, aten.mm]
        extern_kernels.mm(reinterpret_tensor(buf602, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg380_1, (1536, 8960), (1, 1536), 0), out=buf603)
        del arg380_1
        buf604 = empty_strided_cuda((1, 8960), (8960, 1), torch.float16)
        # Topologically Sorted Source Nodes: [linear_187], Original ATen: [aten.view, aten.t, aten.mm]
        extern_kernels.mm(reinterpret_tensor(buf602, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg381_1, (1536, 8960), (1, 1536), 0), out=buf604)
        del arg381_1
        buf605 = reinterpret_tensor(buf603, (1, 1, 8960), (8960, 8960, 1), 0); del buf603  # reuse
        # Topologically Sorted Source Nodes: [linear_186, silu_26, linear_187, mul_244], Original ATen: [aten._unsafe_view, aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_mul_silu_6.run(buf605, buf604, 8960, stream=raw_stream0)
        del buf604
        buf606 = reinterpret_tensor(buf602, (1, 1536), (1536, 1), 0); del buf602  # reuse
        # Topologically Sorted Source Nodes: [linear_186, silu_26, linear_187, mul_244, down_proj_26], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
        extern_kernels.mm(reinterpret_tensor(buf605, (1, 8960), (0, 1), 0), reinterpret_tensor(arg382_1, (8960, 1536), (1, 8960), 0), out=buf606)
        del arg382_1
        del buf605
        buf608 = reinterpret_tensor(buf587, (1, 1, 1536), (1536, 1536, 1), 0); del buf587  # reuse
        # Topologically Sorted Source Nodes: [down_proj_25, hidden_states_259, attn_output_107, hidden_states_265, down_proj_26, hidden_states_269, hidden_states_270, pow_55, variance_54, add_162, rsqrt_54, hidden_states_271, to_112, hidden_states_272], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_11.run(buf578, buf584, buf600, buf606, arg383_1, buf608, 1, 1536, stream=raw_stream0)
        del arg383_1
        buf609 = buf555; del buf555  # reuse
        # Topologically Sorted Source Nodes: [linear_189], Original ATen: [aten.view, aten.t, aten.addmm]
        extern_kernels.addmm(arg385_1, reinterpret_tensor(buf608, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg384_1, (1536, 1536), (1, 1536), 0), alpha=1, beta=1, out=buf609)
        del arg384_1
        del arg385_1
        buf610 = empty_strided_cuda((1, 256), (256, 1), torch.float16)
        # Topologically Sorted Source Nodes: [linear_190], Original ATen: [aten.view, aten.t, aten.addmm]
        extern_kernels.addmm(arg387_1, reinterpret_tensor(buf608, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg386_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf610)
        del arg386_1
        del arg387_1
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, cos_30, sin_30, linear_190, view_83, key_states_27, mul_249, x2_55, neg_55, x1_55, cat_56, mul_250, k_embed_27, index_copy__54], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__to_copy_add_bmm_cat_expand_index_copy_mul_neg_slice_transpose_unsqueeze_view_1.run(arg0_1, buf610, arg4_1, arg390_1, 256, stream=raw_stream0)
        buf612 = buf610; del buf610  # reuse
        # Topologically Sorted Source Nodes: [linear_191], Original ATen: [aten.view, aten.t, aten.addmm]
        extern_kernels.addmm(arg389_1, reinterpret_tensor(buf608, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg388_1, (1536, 256), (1, 1536), 0), alpha=1, beta=1, out=buf612)
        del arg388_1
        del arg389_1
        # Topologically Sorted Source Nodes: [linear_191, view_84, value_states_27, index_copy__55], Original ATen: [aten.view, aten.transpose, aten.index_copy]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused_index_copy_transpose_view_2.run(arg0_1, buf612, arg391_1, 256, stream=raw_stream0)
        del buf612
        buf614 = reinterpret_tensor(buf608, (1, 12, 1, 128), (1536, 128, 128, 1), 0); del buf608  # reuse
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, linear_189, view_82, query_states_27, cos_30, mul_247, x2_54, neg_54, x1_54, cat_55, sin_30, mul_248, q_embed_27, key_27, value_27, attn_output_108], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.clone, aten._unsafe_view, aten._scaled_dot_product_efficient_attention]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_efficient_attention__to_copy__unsafe_view_add_bmm_cat_clone_expand_mul_neg_slice_transpose_unsqueeze_view_3.run(buf609, arg4_1, arg0_1, buf614, 1536, stream=raw_stream0)
        del arg0_1
        del arg4_1
        del buf609
        buf615 = buf594; del buf594  # reuse
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, linear_189, view_82, query_states_27, cos_30, mul_247, x2_54, neg_54, x1_54, cat_55, sin_30, mul_248, q_embed_27, key_27, value_27, attn_output_108], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.clone, aten._unsafe_view, aten._scaled_dot_product_efficient_attention]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_efficient_attention__to_copy__unsafe_view_add_bmm_cat_clone_expand_mul_neg_slice_transpose_unsqueeze_view_4.run(arg390_1, buf615, 294912, stream=raw_stream0)
        del arg390_1
        buf616 = empty_strided_cuda((1, 12, 192, 128), (294912, 24576, 128, 1), torch.float16)
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, linear_189, view_82, query_states_27, cos_30, mul_247, x2_54, neg_54, x1_54, cat_55, sin_30, mul_248, q_embed_27, key_27, value_27, attn_output_108], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.clone, aten._unsafe_view, aten._scaled_dot_product_efficient_attention]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__scaled_dot_product_efficient_attention__to_copy__unsafe_view_add_bmm_cat_clone_expand_mul_neg_slice_transpose_unsqueeze_view_4.run(arg391_1, buf616, 294912, stream=raw_stream0)
        del arg391_1
        # Topologically Sorted Source Nodes: [getitem, expand, view, getitem_1, position_ids_expanded, matmul, freqs, emb, cos_1, cos_2, sin_1, sin_2, linear_189, view_82, query_states_27, cos_30, mul_247, x2_54, neg_54, x1_54, cat_55, sin_30, mul_248, q_embed_27, key_27, value_27, attn_output_108], Original ATen: [aten.unsqueeze, aten.expand, aten.view, aten._to_copy, aten.bmm, aten.transpose, aten.cat, aten.mul, aten.slice, aten.neg, aten.add, aten.clone, aten._unsafe_view, aten._scaled_dot_product_efficient_attention]
        buf617 = torch.ops.aten._scaled_dot_product_efficient_attention.default(buf614, buf615, buf616, reinterpret_tensor(arg3_1, (1, 12, 1, 192), (192, 0, 192, 1), 0), False, scale=0.08838834764831845)
        del arg3_1
        del buf615
        del buf616
        buf618 = buf617[0]
        assert_tensor_metadata(buf618, (1, 12, 1, 128), (1536, 128, 1536, 1), torch.float16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
        assert_alignment(buf618, 16, 'torch.ops.aten._scaled_dot_product_efficient_attention.default')
        del buf617
        buf622 = reinterpret_tensor(buf614, (1, 1536), (1536, 1), 0); del buf614  # reuse
        # Topologically Sorted Source Nodes: [transpose_112, reshape_83, attn_output_111], Original ATen: [aten.transpose, aten.view, aten.t, aten.mm]
        extern_kernels.mm(reinterpret_tensor(buf618, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg392_1, (1536, 1536), (1, 1536), 0), out=buf622)
        del arg392_1
        buf623 = buf578; del buf578  # reuse
        buf625 = reinterpret_tensor(buf618, (1, 1, 1536), (1536, 1536, 1), 0); del buf618  # reuse
        # Topologically Sorted Source Nodes: [down_proj_25, hidden_states_259, attn_output_107, hidden_states_265, down_proj_26, hidden_states_269, attn_output_111, hidden_states_275, hidden_states_276, pow_56, variance_55, add_166, rsqrt_55, hidden_states_277, to_114, hidden_states_278], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_12.run(buf623, buf584, buf600, buf606, buf622, arg393_1, buf625, 1, 1536, stream=raw_stream0)
        del arg393_1
        del buf584
        del buf600
        del buf606
        del buf622
        buf626 = empty_strided_cuda((1, 8960), (8960, 1), torch.float16)
        # Topologically Sorted Source Nodes: [hidden_states_276, pow_56, variance_55, add_166, rsqrt_55, hidden_states_277, to_114, hidden_states_278, linear_193], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
        extern_kernels.mm(reinterpret_tensor(buf625, (1, 1536), (0, 1), 0), reinterpret_tensor(arg394_1, (1536, 8960), (1, 1536), 0), out=buf626)
        del arg394_1
        buf627 = empty_strided_cuda((1, 8960), (8960, 1), torch.float16)
        # Topologically Sorted Source Nodes: [linear_194], Original ATen: [aten.view, aten.t, aten.mm]
        extern_kernels.mm(reinterpret_tensor(buf625, (1, 1536), (1536, 1), 0), reinterpret_tensor(arg395_1, (1536, 8960), (1, 1536), 0), out=buf627)
        del arg395_1
        buf628 = reinterpret_tensor(buf626, (1, 1, 8960), (8960, 8960, 1), 0); del buf626  # reuse
        # Topologically Sorted Source Nodes: [linear_193, silu_27, linear_194, mul_253], Original ATen: [aten._unsafe_view, aten.silu, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_poi_fused__unsafe_view_mul_silu_6.run(buf628, buf627, 8960, stream=raw_stream0)
        del buf627
        buf629 = reinterpret_tensor(buf625, (1, 1536), (1536, 1), 0); del buf625  # reuse
        # Topologically Sorted Source Nodes: [linear_193, silu_27, linear_194, mul_253, down_proj_27], Original ATen: [aten._unsafe_view, aten.silu, aten.mul, aten.view, aten.t, aten.mm]
        extern_kernels.mm(reinterpret_tensor(buf628, (1, 8960), (0, 1), 0), reinterpret_tensor(arg396_1, (8960, 1536), (1, 8960), 0), out=buf629)
        del arg396_1
        del buf628
        buf631 = buf623; del buf623  # reuse
        # Topologically Sorted Source Nodes: [down_proj_27, hidden_states_279, hidden_states_280, pow_57, variance_56, add_168, rsqrt_56, hidden_states_281, to_116, hidden_states_282], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__to_copy__unsafe_view_add_mean_mul_pow_rsqrt_13.run(buf631, buf629, arg397_1, 1, 1536, stream=raw_stream0)
        del arg397_1
        del buf629
        buf632 = empty_strided_cuda((1, 151936), (151936, 1), torch.float16)
        # Topologically Sorted Source Nodes: [down_proj_27, hidden_states_279, hidden_states_280, pow_57, variance_56, add_168, rsqrt_56, hidden_states_281, to_116, hidden_states_282, getitem_198, logits], Original ATen: [aten._unsafe_view, aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.slice, aten.view, aten.t, aten.mm]
        extern_kernels.mm(reinterpret_tensor(buf631, (1, 1536), (0, 1), 0), reinterpret_tensor(arg2_1, (1536, 151936), (1, 1536), 0), out=buf632)
        del arg2_1
        del buf631
        buf633 = empty_strided_cuda((1, ), (1, ), torch.int64)
        # Topologically Sorted Source Nodes: [logits, logits_1, argmax], Original ATen: [aten._unsafe_view, aten.select, aten.argmax]
        raw_stream0 = get_raw_stream(0)
        triton_red_fused__unsafe_view_argmax_select_14.run(buf632, buf633, 1, 151936, stream=raw_stream0)
    return (buf632, buf633, )


async_compile.wait(globals())
del async_compile

class Runner:
    def __init__(self, partitions):
        self.partitions = partitions

    def recursively_apply_fns(self, fns):
        new_callables = []
        for fn, c in zip(fns, self.partitions):
            new_callables.append(fn(c))
        self.partitions = new_callables

    def call(self, args):
        arg0_1, arg1_1, arg2_1, arg3_1, arg4_1, arg5_1, arg6_1, arg7_1, arg8_1, arg9_1, arg10_1, arg11_1, arg12_1, arg13_1, arg14_1, arg15_1, arg16_1, arg17_1, arg18_1, arg19_1, arg20_1, arg21_1, arg22_1, arg23_1, arg24_1, arg25_1, arg26_1, arg27_1, arg28_1, arg29_1, arg30_1, arg31_1, arg32_1, arg33_1, arg34_1, arg35_1, arg36_1, arg37_1, arg38_1, arg39_1, arg40_1, arg41_1, arg42_1, arg43_1, arg44_1, arg45_1, arg46_1, arg47_1, arg48_1, arg49_1, arg50_1, arg51_1, arg52_1, arg53_1, arg54_1, arg55_1, arg56_1, arg57_1, arg58_1, arg59_1, arg60_1, arg61_1, arg62_1, arg63_1, arg64_1, arg65_1, arg66_1, arg67_1, arg68_1, arg69_1, arg70_1, arg71_1, arg72_1, arg73_1, arg74_1, arg75_1, arg76_1, arg77_1, arg78_1, arg79_1, arg80_1, arg81_1, arg82_1, arg83_1, arg84_1, arg85_1, arg86_1, arg87_1, arg88_1, arg89_1, arg90_1, arg91_1, arg92_1, arg93_1, arg94_1, arg95_1, arg96_1, arg97_1, arg98_1, arg99_1, arg100_1, arg101_1, arg102_1, arg103_1, arg104_1, arg105_1, arg106_1, arg107_1, arg108_1, arg109_1, arg110_1, arg111_1, arg112_1, arg113_1, arg114_1, arg115_1, arg116_1, arg117_1, arg118_1, arg119_1, arg120_1, arg121_1, arg122_1, arg123_1, arg124_1, arg125_1, arg126_1, arg127_1, arg128_1, arg129_1, arg130_1, arg131_1, arg132_1, arg133_1, arg134_1, arg135_1, arg136_1, arg137_1, arg138_1, arg139_1, arg140_1, arg141_1, arg142_1, arg143_1, arg144_1, arg145_1, arg146_1, arg147_1, arg148_1, arg149_1, arg150_1, arg151_1, arg152_1, arg153_1, arg154_1, arg155_1, arg156_1, arg157_1, arg158_1, arg159_1, arg160_1, arg161_1, arg162_1, arg163_1, arg164_1, arg165_1, arg166_1, arg167_1, arg168_1, arg169_1, arg170_1, arg171_1, arg172_1, arg173_1, arg174_1, arg175_1, arg176_1, arg177_1, arg178_1, arg179_1, arg180_1, arg181_1, arg182_1, arg183_1, arg184_1, arg185_1, arg186_1, arg187_1, arg188_1, arg189_1, arg190_1, arg191_1, arg192_1, arg193_1, arg194_1, arg195_1, arg196_1, arg197_1, arg198_1, arg199_1, arg200_1, arg201_1, arg202_1, arg203_1, arg204_1, arg205_1, arg206_1, arg207_1, arg208_1, arg209_1, arg210_1, arg211_1, arg212_1, arg213_1, arg214_1, arg215_1, arg216_1, arg217_1, arg218_1, arg219_1, arg220_1, arg221_1, arg222_1, arg223_1, arg224_1, arg225_1, arg226_1, arg227_1, arg228_1, arg229_1, arg230_1, arg231_1, arg232_1, arg233_1, arg234_1, arg235_1, arg236_1, arg237_1, arg238_1, arg239_1, arg240_1, arg241_1, arg242_1, arg243_1, arg244_1, arg245_1, arg246_1, arg247_1, arg248_1, arg249_1, arg250_1, arg251_1, arg252_1, arg253_1, arg254_1, arg255_1, arg256_1, arg257_1, arg258_1, arg259_1, arg260_1, arg261_1, arg262_1, arg263_1, arg264_1, arg265_1, arg266_1, arg267_1, arg268_1, arg269_1, arg270_1, arg271_1, arg272_1, arg273_1, arg274_1, arg275_1, arg276_1, arg277_1, arg278_1, arg279_1, arg280_1, arg281_1, arg282_1, arg283_1, arg284_1, arg285_1, arg286_1, arg287_1, arg288_1, arg289_1, arg290_1, arg291_1, arg292_1, arg293_1, arg294_1, arg295_1, arg296_1, arg297_1, arg298_1, arg299_1, arg300_1, arg301_1, arg302_1, arg303_1, arg304_1, arg305_1, arg306_1, arg307_1, arg308_1, arg309_1, arg310_1, arg311_1, arg312_1, arg313_1, arg314_1, arg315_1, arg316_1, arg317_1, arg318_1, arg319_1, arg320_1, arg321_1, arg322_1, arg323_1, arg324_1, arg325_1, arg326_1, arg327_1, arg328_1, arg329_1, arg330_1, arg331_1, arg332_1, arg333_1, arg334_1, arg335_1, arg336_1, arg337_1, arg338_1, arg339_1, arg340_1, arg341_1, arg342_1, arg343_1, arg344_1, arg345_1, arg346_1, arg347_1, arg348_1, arg349_1, arg350_1, arg351_1, arg352_1, arg353_1, arg354_1, arg355_1, arg356_1, arg357_1, arg358_1, arg359_1, arg360_1, arg361_1, arg362_1, arg363_1, arg364_1, arg365_1, arg366_1, arg367_1, arg368_1, arg369_1, arg370_1, arg371_1, arg372_1, arg373_1, arg374_1, arg375_1, arg376_1, arg377_1, arg378_1, arg379_1, arg380_1, arg381_1, arg382_1, arg383_1, arg384_1, arg385_1, arg386_1, arg387_1, arg388_1, arg389_1, arg390_1, arg391_1, arg392_1, arg393_1, arg394_1, arg395_1, arg396_1, arg397_1 = args
        args.clear()
        partition0_args = [arg1_1, arg2_1, arg5_1, arg7_1, arg6_1, arg9_1, arg8_1, arg0_1, arg4_1, arg12_1, arg11_1, arg10_1, arg13_1, arg3_1, arg14_1, arg15_1, arg16_1, arg17_1, arg18_1, arg19_1, arg21_1, arg20_1, arg23_1, arg22_1, arg26_1, arg25_1, arg24_1, arg27_1, arg28_1, arg29_1, arg30_1, arg31_1, arg32_1, arg33_1, arg35_1, arg34_1, arg37_1, arg36_1, arg40_1, arg39_1, arg38_1, arg41_1, arg42_1, arg43_1, arg44_1, arg45_1, arg46_1, arg47_1, arg49_1, arg48_1, arg51_1, arg50_1, arg54_1, arg53_1, arg52_1, arg55_1, arg56_1, arg57_1, arg58_1, arg59_1, arg60_1, arg61_1, arg63_1, arg62_1, arg65_1, arg64_1, arg68_1, arg67_1, arg66_1, arg69_1, arg70_1, arg71_1, arg72_1, arg73_1, arg74_1, arg75_1, arg77_1, arg76_1, arg79_1, arg78_1, arg82_1, arg81_1, arg80_1, arg83_1, arg84_1, arg85_1, arg86_1, arg87_1, arg88_1, arg89_1, arg91_1, arg90_1, arg93_1, arg92_1, arg96_1, arg95_1, arg94_1, arg97_1, arg98_1, arg99_1, arg100_1, arg101_1, arg102_1, arg103_1, arg105_1, arg104_1, arg107_1, arg106_1, arg110_1, arg109_1, arg108_1, arg111_1, arg112_1, arg113_1, arg114_1, arg115_1, arg116_1, arg117_1, arg119_1, arg118_1, arg121_1, arg120_1, arg124_1, arg123_1, arg122_1, arg125_1, arg126_1, arg127_1, arg128_1, arg129_1, arg130_1, arg131_1, arg133_1, arg132_1, arg135_1, arg134_1, arg138_1, arg137_1, arg136_1, arg139_1, arg140_1, arg141_1, arg142_1, arg143_1, arg144_1, arg145_1, arg147_1, arg146_1, arg149_1, arg148_1, arg152_1, arg151_1, arg150_1, arg153_1, arg154_1, arg155_1, arg156_1, arg157_1, arg158_1, arg159_1, arg161_1, arg160_1, arg163_1, arg162_1, arg166_1, arg165_1, arg164_1, arg167_1, arg168_1, arg169_1, arg170_1, arg171_1, arg172_1, arg173_1, arg175_1, arg174_1, arg177_1, arg176_1, arg180_1, arg179_1, arg178_1, arg181_1, arg182_1, arg183_1, arg184_1, arg185_1, arg186_1, arg187_1, arg189_1, arg188_1, arg191_1, arg190_1, arg194_1, arg193_1, arg192_1, arg195_1, arg196_1, arg197_1, arg198_1, arg199_1, arg200_1, arg201_1, arg203_1, arg202_1, arg205_1, arg204_1, arg208_1, arg207_1, arg206_1, arg209_1, arg210_1, arg211_1, arg212_1, arg213_1, arg214_1, arg215_1, arg217_1, arg216_1, arg219_1, arg218_1, arg222_1, arg221_1, arg220_1, arg223_1, arg224_1, arg225_1, arg226_1, arg227_1, arg228_1, arg229_1, arg231_1, arg230_1, arg233_1, arg232_1, arg236_1, arg235_1, arg234_1, arg237_1, arg238_1, arg239_1, arg240_1, arg241_1, arg242_1, arg243_1, arg245_1, arg244_1, arg247_1, arg246_1, arg250_1, arg249_1, arg248_1, arg251_1, arg252_1, arg253_1, arg254_1, arg255_1, arg256_1, arg257_1, arg259_1, arg258_1, arg261_1, arg260_1, arg264_1, arg263_1, arg262_1, arg265_1, arg266_1, arg267_1, arg268_1, arg269_1, arg270_1, arg271_1, arg273_1, arg272_1, arg275_1, arg274_1, arg278_1, arg277_1, arg276_1, arg279_1, arg280_1, arg281_1, arg282_1, arg283_1, arg284_1, arg285_1, arg287_1, arg286_1, arg289_1, arg288_1, arg292_1, arg291_1, arg290_1, arg293_1, arg294_1, arg295_1, arg296_1, arg297_1, arg298_1, arg299_1, arg301_1, arg300_1, arg303_1, arg302_1, arg306_1, arg305_1, arg304_1, arg307_1, arg308_1, arg309_1, arg310_1, arg311_1, arg312_1, arg313_1, arg315_1, arg314_1, arg317_1, arg316_1, arg320_1, arg319_1, arg318_1, arg321_1, arg322_1, arg323_1, arg324_1, arg325_1, arg326_1, arg327_1, arg329_1, arg328_1, arg331_1, arg330_1, arg334_1, arg333_1, arg332_1, arg335_1, arg336_1, arg337_1, arg338_1, arg339_1, arg340_1, arg341_1, arg343_1, arg342_1, arg345_1, arg344_1, arg348_1, arg347_1, arg346_1, arg349_1, arg350_1, arg351_1, arg352_1, arg353_1, arg354_1, arg355_1, arg357_1, arg356_1, arg359_1, arg358_1, arg362_1, arg361_1, arg360_1, arg363_1, arg364_1, arg365_1, arg366_1, arg367_1, arg368_1, arg369_1, arg371_1, arg370_1, arg373_1, arg372_1, arg376_1, arg375_1, arg374_1, arg377_1, arg378_1, arg379_1, arg380_1, arg381_1, arg382_1, arg383_1, arg385_1, arg384_1, arg387_1, arg386_1, arg390_1, arg389_1, arg388_1, arg391_1, arg392_1, arg393_1, arg394_1, arg395_1, arg396_1, arg397_1]
        del arg1_1, arg2_1, arg5_1, arg7_1, arg6_1, arg9_1, arg8_1, arg0_1, arg4_1, arg12_1, arg11_1, arg10_1, arg13_1, arg3_1, arg14_1, arg15_1, arg16_1, arg17_1, arg18_1, arg19_1, arg21_1, arg20_1, arg23_1, arg22_1, arg26_1, arg25_1, arg24_1, arg27_1, arg28_1, arg29_1, arg30_1, arg31_1, arg32_1, arg33_1, arg35_1, arg34_1, arg37_1, arg36_1, arg40_1, arg39_1, arg38_1, arg41_1, arg42_1, arg43_1, arg44_1, arg45_1, arg46_1, arg47_1, arg49_1, arg48_1, arg51_1, arg50_1, arg54_1, arg53_1, arg52_1, arg55_1, arg56_1, arg57_1, arg58_1, arg59_1, arg60_1, arg61_1, arg63_1, arg62_1, arg65_1, arg64_1, arg68_1, arg67_1, arg66_1, arg69_1, arg70_1, arg71_1, arg72_1, arg73_1, arg74_1, arg75_1, arg77_1, arg76_1, arg79_1, arg78_1, arg82_1, arg81_1, arg80_1, arg83_1, arg84_1, arg85_1, arg86_1, arg87_1, arg88_1, arg89_1, arg91_1, arg90_1, arg93_1, arg92_1, arg96_1, arg95_1, arg94_1, arg97_1, arg98_1, arg99_1, arg100_1, arg101_1, arg102_1, arg103_1, arg105_1, arg104_1, arg107_1, arg106_1, arg110_1, arg109_1, arg108_1, arg111_1, arg112_1, arg113_1, arg114_1, arg115_1, arg116_1, arg117_1, arg119_1, arg118_1, arg121_1, arg120_1, arg124_1, arg123_1, arg122_1, arg125_1, arg126_1, arg127_1, arg128_1, arg129_1, arg130_1, arg131_1, arg133_1, arg132_1, arg135_1, arg134_1, arg138_1, arg137_1, arg136_1, arg139_1, arg140_1, arg141_1, arg142_1, arg143_1, arg144_1, arg145_1, arg147_1, arg146_1, arg149_1, arg148_1, arg152_1, arg151_1, arg150_1, arg153_1, arg154_1, arg155_1, arg156_1, arg157_1, arg158_1, arg159_1, arg161_1, arg160_1, arg163_1, arg162_1, arg166_1, arg165_1, arg164_1, arg167_1, arg168_1, arg169_1, arg170_1, arg171_1, arg172_1, arg173_1, arg175_1, arg174_1, arg177_1, arg176_1, arg180_1, arg179_1, arg178_1, arg181_1, arg182_1, arg183_1, arg184_1, arg185_1, arg186_1, arg187_1, arg189_1, arg188_1, arg191_1, arg190_1, arg194_1, arg193_1, arg192_1, arg195_1, arg196_1, arg197_1, arg198_1, arg199_1, arg200_1, arg201_1, arg203_1, arg202_1, arg205_1, arg204_1, arg208_1, arg207_1, arg206_1, arg209_1, arg210_1, arg211_1, arg212_1, arg213_1, arg214_1, arg215_1, arg217_1, arg216_1, arg219_1, arg218_1, arg222_1, arg221_1, arg220_1, arg223_1, arg224_1, arg225_1, arg226_1, arg227_1, arg228_1, arg229_1, arg231_1, arg230_1, arg233_1, arg232_1, arg236_1, arg235_1, arg234_1, arg237_1, arg238_1, arg239_1, arg240_1, arg241_1, arg242_1, arg243_1, arg245_1, arg244_1, arg247_1, arg246_1, arg250_1, arg249_1, arg248_1, arg251_1, arg252_1, arg253_1, arg254_1, arg255_1, arg256_1, arg257_1, arg259_1, arg258_1, arg261_1, arg260_1, arg264_1, arg263_1, arg262_1, arg265_1, arg266_1, arg267_1, arg268_1, arg269_1, arg270_1, arg271_1, arg273_1, arg272_1, arg275_1, arg274_1, arg278_1, arg277_1, arg276_1, arg279_1, arg280_1, arg281_1, arg282_1, arg283_1, arg284_1, arg285_1, arg287_1, arg286_1, arg289_1, arg288_1, arg292_1, arg291_1, arg290_1, arg293_1, arg294_1, arg295_1, arg296_1, arg297_1, arg298_1, arg299_1, arg301_1, arg300_1, arg303_1, arg302_1, arg306_1, arg305_1, arg304_1, arg307_1, arg308_1, arg309_1, arg310_1, arg311_1, arg312_1, arg313_1, arg315_1, arg314_1, arg317_1, arg316_1, arg320_1, arg319_1, arg318_1, arg321_1, arg322_1, arg323_1, arg324_1, arg325_1, arg326_1, arg327_1, arg329_1, arg328_1, arg331_1, arg330_1, arg334_1, arg333_1, arg332_1, arg335_1, arg336_1, arg337_1, arg338_1, arg339_1, arg340_1, arg341_1, arg343_1, arg342_1, arg345_1, arg344_1, arg348_1, arg347_1, arg346_1, arg349_1, arg350_1, arg351_1, arg352_1, arg353_1, arg354_1, arg355_1, arg357_1, arg356_1, arg359_1, arg358_1, arg362_1, arg361_1, arg360_1, arg363_1, arg364_1, arg365_1, arg366_1, arg367_1, arg368_1, arg369_1, arg371_1, arg370_1, arg373_1, arg372_1, arg376_1, arg375_1, arg374_1, arg377_1, arg378_1, arg379_1, arg380_1, arg381_1, arg382_1, arg383_1, arg385_1, arg384_1, arg387_1, arg386_1, arg390_1, arg389_1, arg388_1, arg391_1, arg392_1, arg393_1, arg394_1, arg395_1, arg396_1, arg397_1
        (buf632, buf633) = self.partitions[0](partition0_args)
        del partition0_args
        return (buf632, reinterpret_tensor(buf633, (1, 1), (1, 1), 0), )

runner = Runner(partitions=[partition_0,])
call = runner.call
recursively_apply_fns = runner.recursively_apply_fns


def get_args():
    from torch._dynamo.testing import rand_strided
    arg0_1 = rand_strided((1, ), (1, ), device='cuda:0', dtype=torch.int64)
    arg1_1 = rand_strided((1, 1), (1, 1), device='cuda:0', dtype=torch.int64)
    arg2_1 = rand_strided((151936, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg3_1 = rand_strided((1, 1, 1, 192), (192, 192, 192, 1), device='cuda:0', dtype=torch.float16)
    arg4_1 = rand_strided((64, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg5_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg6_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg7_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg8_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg9_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg10_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg11_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg12_1 = rand_strided((1, 2, 192, 128), (49152, 24576, 128, 1), device='cuda:0', dtype=torch.float16)
    arg13_1 = rand_strided((1, 2, 192, 128), (49152, 24576, 128, 1), device='cuda:0', dtype=torch.float16)
    arg14_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg15_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg16_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg17_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg18_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float16)
    arg19_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg20_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg21_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg22_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg23_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg24_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg25_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg26_1 = rand_strided((1, 2, 192, 128), (49152, 24576, 128, 1), device='cuda:0', dtype=torch.float16)
    arg27_1 = rand_strided((1, 2, 192, 128), (49152, 24576, 128, 1), device='cuda:0', dtype=torch.float16)
    arg28_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg29_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg30_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg31_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg32_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float16)
    arg33_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg34_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg35_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg36_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg37_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg38_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg39_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg40_1 = rand_strided((1, 2, 192, 128), (49152, 24576, 128, 1), device='cuda:0', dtype=torch.float16)
    arg41_1 = rand_strided((1, 2, 192, 128), (49152, 24576, 128, 1), device='cuda:0', dtype=torch.float16)
    arg42_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg43_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg44_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg45_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg46_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float16)
    arg47_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg48_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg49_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg50_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg51_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg52_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg53_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg54_1 = rand_strided((1, 2, 192, 128), (49152, 24576, 128, 1), device='cuda:0', dtype=torch.float16)
    arg55_1 = rand_strided((1, 2, 192, 128), (49152, 24576, 128, 1), device='cuda:0', dtype=torch.float16)
    arg56_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg57_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg58_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg59_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg60_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float16)
    arg61_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg62_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg63_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg64_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg65_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg66_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg67_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg68_1 = rand_strided((1, 2, 192, 128), (49152, 24576, 128, 1), device='cuda:0', dtype=torch.float16)
    arg69_1 = rand_strided((1, 2, 192, 128), (49152, 24576, 128, 1), device='cuda:0', dtype=torch.float16)
    arg70_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg71_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg72_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg73_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg74_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float16)
    arg75_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg76_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg77_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg78_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg79_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg80_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg81_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg82_1 = rand_strided((1, 2, 192, 128), (49152, 24576, 128, 1), device='cuda:0', dtype=torch.float16)
    arg83_1 = rand_strided((1, 2, 192, 128), (49152, 24576, 128, 1), device='cuda:0', dtype=torch.float16)
    arg84_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg85_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg86_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg87_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg88_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float16)
    arg89_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg90_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg91_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg92_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg93_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg94_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg95_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg96_1 = rand_strided((1, 2, 192, 128), (49152, 24576, 128, 1), device='cuda:0', dtype=torch.float16)
    arg97_1 = rand_strided((1, 2, 192, 128), (49152, 24576, 128, 1), device='cuda:0', dtype=torch.float16)
    arg98_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg99_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg100_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg101_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg102_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float16)
    arg103_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg104_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg105_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg106_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg107_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg108_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg109_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg110_1 = rand_strided((1, 2, 192, 128), (49152, 24576, 128, 1), device='cuda:0', dtype=torch.float16)
    arg111_1 = rand_strided((1, 2, 192, 128), (49152, 24576, 128, 1), device='cuda:0', dtype=torch.float16)
    arg112_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg113_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg114_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg115_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg116_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float16)
    arg117_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg118_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg119_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg120_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg121_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg122_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg123_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg124_1 = rand_strided((1, 2, 192, 128), (49152, 24576, 128, 1), device='cuda:0', dtype=torch.float16)
    arg125_1 = rand_strided((1, 2, 192, 128), (49152, 24576, 128, 1), device='cuda:0', dtype=torch.float16)
    arg126_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg127_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg128_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg129_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg130_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float16)
    arg131_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg132_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg133_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg134_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg135_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg136_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg137_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg138_1 = rand_strided((1, 2, 192, 128), (49152, 24576, 128, 1), device='cuda:0', dtype=torch.float16)
    arg139_1 = rand_strided((1, 2, 192, 128), (49152, 24576, 128, 1), device='cuda:0', dtype=torch.float16)
    arg140_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg141_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg142_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg143_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg144_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float16)
    arg145_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg146_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg147_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg148_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg149_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg150_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg151_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg152_1 = rand_strided((1, 2, 192, 128), (49152, 24576, 128, 1), device='cuda:0', dtype=torch.float16)
    arg153_1 = rand_strided((1, 2, 192, 128), (49152, 24576, 128, 1), device='cuda:0', dtype=torch.float16)
    arg154_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg155_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg156_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg157_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg158_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float16)
    arg159_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg160_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg161_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg162_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg163_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg164_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg165_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg166_1 = rand_strided((1, 2, 192, 128), (49152, 24576, 128, 1), device='cuda:0', dtype=torch.float16)
    arg167_1 = rand_strided((1, 2, 192, 128), (49152, 24576, 128, 1), device='cuda:0', dtype=torch.float16)
    arg168_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg169_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg170_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg171_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg172_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float16)
    arg173_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg174_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg175_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg176_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg177_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg178_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg179_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg180_1 = rand_strided((1, 2, 192, 128), (49152, 24576, 128, 1), device='cuda:0', dtype=torch.float16)
    arg181_1 = rand_strided((1, 2, 192, 128), (49152, 24576, 128, 1), device='cuda:0', dtype=torch.float16)
    arg182_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg183_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg184_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg185_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg186_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float16)
    arg187_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg188_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg189_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg190_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg191_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg192_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg193_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg194_1 = rand_strided((1, 2, 192, 128), (49152, 24576, 128, 1), device='cuda:0', dtype=torch.float16)
    arg195_1 = rand_strided((1, 2, 192, 128), (49152, 24576, 128, 1), device='cuda:0', dtype=torch.float16)
    arg196_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg197_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg198_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg199_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg200_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float16)
    arg201_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg202_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg203_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg204_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg205_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg206_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg207_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg208_1 = rand_strided((1, 2, 192, 128), (49152, 24576, 128, 1), device='cuda:0', dtype=torch.float16)
    arg209_1 = rand_strided((1, 2, 192, 128), (49152, 24576, 128, 1), device='cuda:0', dtype=torch.float16)
    arg210_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg211_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg212_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg213_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg214_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float16)
    arg215_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg216_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg217_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg218_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg219_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg220_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg221_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg222_1 = rand_strided((1, 2, 192, 128), (49152, 24576, 128, 1), device='cuda:0', dtype=torch.float16)
    arg223_1 = rand_strided((1, 2, 192, 128), (49152, 24576, 128, 1), device='cuda:0', dtype=torch.float16)
    arg224_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg225_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg226_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg227_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg228_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float16)
    arg229_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg230_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg231_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg232_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg233_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg234_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg235_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg236_1 = rand_strided((1, 2, 192, 128), (49152, 24576, 128, 1), device='cuda:0', dtype=torch.float16)
    arg237_1 = rand_strided((1, 2, 192, 128), (49152, 24576, 128, 1), device='cuda:0', dtype=torch.float16)
    arg238_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg239_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg240_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg241_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg242_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float16)
    arg243_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg244_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg245_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg246_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg247_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg248_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg249_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg250_1 = rand_strided((1, 2, 192, 128), (49152, 24576, 128, 1), device='cuda:0', dtype=torch.float16)
    arg251_1 = rand_strided((1, 2, 192, 128), (49152, 24576, 128, 1), device='cuda:0', dtype=torch.float16)
    arg252_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg253_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg254_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg255_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg256_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float16)
    arg257_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg258_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg259_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg260_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg261_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg262_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg263_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg264_1 = rand_strided((1, 2, 192, 128), (49152, 24576, 128, 1), device='cuda:0', dtype=torch.float16)
    arg265_1 = rand_strided((1, 2, 192, 128), (49152, 24576, 128, 1), device='cuda:0', dtype=torch.float16)
    arg266_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg267_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg268_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg269_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg270_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float16)
    arg271_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg272_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg273_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg274_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg275_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg276_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg277_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg278_1 = rand_strided((1, 2, 192, 128), (49152, 24576, 128, 1), device='cuda:0', dtype=torch.float16)
    arg279_1 = rand_strided((1, 2, 192, 128), (49152, 24576, 128, 1), device='cuda:0', dtype=torch.float16)
    arg280_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg281_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg282_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg283_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg284_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float16)
    arg285_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg286_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg287_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg288_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg289_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg290_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg291_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg292_1 = rand_strided((1, 2, 192, 128), (49152, 24576, 128, 1), device='cuda:0', dtype=torch.float16)
    arg293_1 = rand_strided((1, 2, 192, 128), (49152, 24576, 128, 1), device='cuda:0', dtype=torch.float16)
    arg294_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg295_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg296_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg297_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg298_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float16)
    arg299_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg300_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg301_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg302_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg303_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg304_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg305_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg306_1 = rand_strided((1, 2, 192, 128), (49152, 24576, 128, 1), device='cuda:0', dtype=torch.float16)
    arg307_1 = rand_strided((1, 2, 192, 128), (49152, 24576, 128, 1), device='cuda:0', dtype=torch.float16)
    arg308_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg309_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg310_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg311_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg312_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float16)
    arg313_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg314_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg315_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg316_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg317_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg318_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg319_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg320_1 = rand_strided((1, 2, 192, 128), (49152, 24576, 128, 1), device='cuda:0', dtype=torch.float16)
    arg321_1 = rand_strided((1, 2, 192, 128), (49152, 24576, 128, 1), device='cuda:0', dtype=torch.float16)
    arg322_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg323_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg324_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg325_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg326_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float16)
    arg327_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg328_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg329_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg330_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg331_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg332_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg333_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg334_1 = rand_strided((1, 2, 192, 128), (49152, 24576, 128, 1), device='cuda:0', dtype=torch.float16)
    arg335_1 = rand_strided((1, 2, 192, 128), (49152, 24576, 128, 1), device='cuda:0', dtype=torch.float16)
    arg336_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg337_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg338_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg339_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg340_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float16)
    arg341_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg342_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg343_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg344_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg345_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg346_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg347_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg348_1 = rand_strided((1, 2, 192, 128), (49152, 24576, 128, 1), device='cuda:0', dtype=torch.float16)
    arg349_1 = rand_strided((1, 2, 192, 128), (49152, 24576, 128, 1), device='cuda:0', dtype=torch.float16)
    arg350_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg351_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg352_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg353_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg354_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float16)
    arg355_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg356_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg357_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg358_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg359_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg360_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg361_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg362_1 = rand_strided((1, 2, 192, 128), (49152, 24576, 128, 1), device='cuda:0', dtype=torch.float16)
    arg363_1 = rand_strided((1, 2, 192, 128), (49152, 24576, 128, 1), device='cuda:0', dtype=torch.float16)
    arg364_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg365_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg366_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg367_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg368_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float16)
    arg369_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg370_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg371_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg372_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg373_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg374_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg375_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg376_1 = rand_strided((1, 2, 192, 128), (49152, 24576, 128, 1), device='cuda:0', dtype=torch.float16)
    arg377_1 = rand_strided((1, 2, 192, 128), (49152, 24576, 128, 1), device='cuda:0', dtype=torch.float16)
    arg378_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg379_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg380_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg381_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg382_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float16)
    arg383_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg384_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg385_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg386_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg387_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg388_1 = rand_strided((256, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg389_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg390_1 = rand_strided((1, 2, 192, 128), (49152, 24576, 128, 1), device='cuda:0', dtype=torch.float16)
    arg391_1 = rand_strided((1, 2, 192, 128), (49152, 24576, 128, 1), device='cuda:0', dtype=torch.float16)
    arg392_1 = rand_strided((1536, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg393_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float16)
    arg394_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg395_1 = rand_strided((8960, 1536), (1536, 1), device='cuda:0', dtype=torch.float16)
    arg396_1 = rand_strided((1536, 8960), (8960, 1), device='cuda:0', dtype=torch.float16)
    arg397_1 = rand_strided((1536, ), (1, ), device='cuda:0', dtype=torch.float16)
    return [arg0_1, arg1_1, arg2_1, arg3_1, arg4_1, arg5_1, arg6_1, arg7_1, arg8_1, arg9_1, arg10_1, arg11_1, arg12_1, arg13_1, arg14_1, arg15_1, arg16_1, arg17_1, arg18_1, arg19_1, arg20_1, arg21_1, arg22_1, arg23_1, arg24_1, arg25_1, arg26_1, arg27_1, arg28_1, arg29_1, arg30_1, arg31_1, arg32_1, arg33_1, arg34_1, arg35_1, arg36_1, arg37_1, arg38_1, arg39_1, arg40_1, arg41_1, arg42_1, arg43_1, arg44_1, arg45_1, arg46_1, arg47_1, arg48_1, arg49_1, arg50_1, arg51_1, arg52_1, arg53_1, arg54_1, arg55_1, arg56_1, arg57_1, arg58_1, arg59_1, arg60_1, arg61_1, arg62_1, arg63_1, arg64_1, arg65_1, arg66_1, arg67_1, arg68_1, arg69_1, arg70_1, arg71_1, arg72_1, arg73_1, arg74_1, arg75_1, arg76_1, arg77_1, arg78_1, arg79_1, arg80_1, arg81_1, arg82_1, arg83_1, arg84_1, arg85_1, arg86_1, arg87_1, arg88_1, arg89_1, arg90_1, arg91_1, arg92_1, arg93_1, arg94_1, arg95_1, arg96_1, arg97_1, arg98_1, arg99_1, arg100_1, arg101_1, arg102_1, arg103_1, arg104_1, arg105_1, arg106_1, arg107_1, arg108_1, arg109_1, arg110_1, arg111_1, arg112_1, arg113_1, arg114_1, arg115_1, arg116_1, arg117_1, arg118_1, arg119_1, arg120_1, arg121_1, arg122_1, arg123_1, arg124_1, arg125_1, arg126_1, arg127_1, arg128_1, arg129_1, arg130_1, arg131_1, arg132_1, arg133_1, arg134_1, arg135_1, arg136_1, arg137_1, arg138_1, arg139_1, arg140_1, arg141_1, arg142_1, arg143_1, arg144_1, arg145_1, arg146_1, arg147_1, arg148_1, arg149_1, arg150_1, arg151_1, arg152_1, arg153_1, arg154_1, arg155_1, arg156_1, arg157_1, arg158_1, arg159_1, arg160_1, arg161_1, arg162_1, arg163_1, arg164_1, arg165_1, arg166_1, arg167_1, arg168_1, arg169_1, arg170_1, arg171_1, arg172_1, arg173_1, arg174_1, arg175_1, arg176_1, arg177_1, arg178_1, arg179_1, arg180_1, arg181_1, arg182_1, arg183_1, arg184_1, arg185_1, arg186_1, arg187_1, arg188_1, arg189_1, arg190_1, arg191_1, arg192_1, arg193_1, arg194_1, arg195_1, arg196_1, arg197_1, arg198_1, arg199_1, arg200_1, arg201_1, arg202_1, arg203_1, arg204_1, arg205_1, arg206_1, arg207_1, arg208_1, arg209_1, arg210_1, arg211_1, arg212_1, arg213_1, arg214_1, arg215_1, arg216_1, arg217_1, arg218_1, arg219_1, arg220_1, arg221_1, arg222_1, arg223_1, arg224_1, arg225_1, arg226_1, arg227_1, arg228_1, arg229_1, arg230_1, arg231_1, arg232_1, arg233_1, arg234_1, arg235_1, arg236_1, arg237_1, arg238_1, arg239_1, arg240_1, arg241_1, arg242_1, arg243_1, arg244_1, arg245_1, arg246_1, arg247_1, arg248_1, arg249_1, arg250_1, arg251_1, arg252_1, arg253_1, arg254_1, arg255_1, arg256_1, arg257_1, arg258_1, arg259_1, arg260_1, arg261_1, arg262_1, arg263_1, arg264_1, arg265_1, arg266_1, arg267_1, arg268_1, arg269_1, arg270_1, arg271_1, arg272_1, arg273_1, arg274_1, arg275_1, arg276_1, arg277_1, arg278_1, arg279_1, arg280_1, arg281_1, arg282_1, arg283_1, arg284_1, arg285_1, arg286_1, arg287_1, arg288_1, arg289_1, arg290_1, arg291_1, arg292_1, arg293_1, arg294_1, arg295_1, arg296_1, arg297_1, arg298_1, arg299_1, arg300_1, arg301_1, arg302_1, arg303_1, arg304_1, arg305_1, arg306_1, arg307_1, arg308_1, arg309_1, arg310_1, arg311_1, arg312_1, arg313_1, arg314_1, arg315_1, arg316_1, arg317_1, arg318_1, arg319_1, arg320_1, arg321_1, arg322_1, arg323_1, arg324_1, arg325_1, arg326_1, arg327_1, arg328_1, arg329_1, arg330_1, arg331_1, arg332_1, arg333_1, arg334_1, arg335_1, arg336_1, arg337_1, arg338_1, arg339_1, arg340_1, arg341_1, arg342_1, arg343_1, arg344_1, arg345_1, arg346_1, arg347_1, arg348_1, arg349_1, arg350_1, arg351_1, arg352_1, arg353_1, arg354_1, arg355_1, arg356_1, arg357_1, arg358_1, arg359_1, arg360_1, arg361_1, arg362_1, arg363_1, arg364_1, arg365_1, arg366_1, arg367_1, arg368_1, arg369_1, arg370_1, arg371_1, arg372_1, arg373_1, arg374_1, arg375_1, arg376_1, arg377_1, arg378_1, arg379_1, arg380_1, arg381_1, arg382_1, arg383_1, arg384_1, arg385_1, arg386_1, arg387_1, arg388_1, arg389_1, arg390_1, arg391_1, arg392_1, arg393_1, arg394_1, arg395_1, arg396_1, arg397_1]


def benchmark_compiled_module(args, times=10, repeat=10):
    from torch._inductor.utils import print_performance
    fn = lambda: call(list(args))
    return print_performance(fn, times=times, repeat=repeat, device='cuda')


if __name__ == "__main__":
    from torch._inductor.wrapper_benchmark import compiled_module_main
    args = get_args()
    compiled_module_main('None', lambda times, repeat: benchmark_compiled_module(args, times=times, repeat=repeat))
