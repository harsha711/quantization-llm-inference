#!/usr/bin/env bash
# Resume only the relevant checks after the documented slow unfiltered attempt.
set -euo pipefail
source "$PROJECT_ROOT/scripts/e009/env_arc.sh"
[[ $(cat "$R/memcheck.exit") == 0 ]]
[[ -e "$R/racecheck-unfiltered-attempt1.exit" ]]
[[ $(cat "$R/racecheck-unfiltered-attempt1.exit") != 0 ]]
[[ $(cat "$R/racecheck-dump-attempt2.exit") == 99 ]]
[[ $(cat "$R/dump-control-off.exit") == 0 ]]
[[ $(cat "$R/dump-control-on.exit") == 99 ]]
cycle_base
run racecheck compute-sanitizer --tool racecheck --error-exitcode 99 \
 --kernel-name kns=e005_marlin --kernel-name kns=dequant_w4a16_kernel \
 "${base[@]}" --out "$R/racecheck.jsonl" --counts 4 --warmup 0 --iters 0
run synccheck compute-sanitizer --tool synccheck --error-exitcode 99 \
 "${base[@]}" --out "$R/synccheck.jsonl" --counts 4 --warmup 0 --iters 0
touch "$R/VALIDATION_PASSED"
